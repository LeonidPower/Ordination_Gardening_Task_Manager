<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['hash_del'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $hash = validate($_POST['hash_del']);
    }
    else{
        include "../commons/customer.php?.php";
        exit();
    }

    if(empty($hash)){
        header("Location: ../src/customer.php?error=Customer not found");
        exit();
    }else{ 
        $sql= "DELETE FROM customer WHERE hash =?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $hash);
        $stmt->execute();
        header("Location: ../src/customer.php?success=Customer deleted");
    }


    $conn->close();
?>