// // Date Field
// document.getElementById('inputInvoiceDate').valueAsDate = new Date();

// //Datatables
// $(document).ready(function () {
//     var t = $('#inputServiceTable').DataTable({
//         columnDefs: [
//             {
//                 searchable: false,
//                 orderable: false,
//                 targets: 0,
//             },
//         ],
//         lengthChange:false,
//         pageLength: 5,
//         ordering:false,
//         searching: false
//     });
 
//     t.on('order.dt search.dt', function () {
//         let i = 1;
 
//         t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
//             this.data(i++);
//         });
//     }).draw();

//     var counter = 2;
//     $('#addRow').on( 'click', function () {
//         t.row.add( [
//             '',
//             '<input class="form-control" type="text" name="item-name[' + counter +']" id="inputItemName' + counter + '" required/>',
//             '<input class="form-control" type="text" name="item-description[' + counter +']" id="inputDescription' + counter + '" required/>',
//             '<input class="form-control" type="number" name="item-quantity[' + counter +']" id="inputQuantity' + counter + '" min="0" value="1" style="width: 67px;" required/>',
//             '<input class="form-control service-price" type="number" name="item-unit-price[' + counter +']" id="inputUnitPrice' + counter + '" " min="0" value="0.00" style="width: 70px;" required/><div class="input-icon input-icon-left"><i>€</i></div>',
//             '<button type="button" class="removeRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt"></i></button>'
//         ] ).draw( false );
//         counter++;
//     });
 
// $('#inputServiceTable tbody').on( 'click', '.removeRow', function () {
//         t.row( $(this).parents('tr')).remove().draw();
//     });
// });

// $(document).ready(function () {
//     var t2 = $('#inputStockTable').DataTable({
//         columnDefs: [
//             {
//                 searchable: false,
//                 orderable: false,
//                 targets: 0,
//             },
//         ],
//         lengthChange:false,
//         pageLength: 5,
//         ordering:false,
//         searching: false
//     });
 
//     t2.on('order.dt search.dt', function () {
//         let i = 1;
 
//         t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
//             this.data(i++);
//         });
//     }).draw();

//     var counter = 2;
//     $('#addStockRow').on( 'click', function () {
//         t2.row.add( [
//             '',
//             '<input class="form-control" type="text" name="item-stock-name[' + counter +']" id="inputStockItemName' + counter + '" required/>',
//             '<input class="form-control" type="number" name="item-stock-quantity[' + counter +']" id="inputStockQuantity' + counter + '" min="0" value="1" style="width: 67px;" required/>',
//             '<input class="form-control stock-price" type="number" name="item-stock-unit-price[' + counter +']" id="inputStockUnitPrice' + counter + '" " min="0" value="0.00" style="width: 70px;" required/><div class="input-icon input-icon-left"><i>€</i></div>',
//             '<button type="button" class="removeStockRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt"></i></button>'
//         ] ).draw( false );
//         counter++;
//     } );

//     var table = $('#example').DataTable();
 
// $('#inputStockTable tbody').on( 'click', '.removeStockRow', function () {
//         t2.row( $(this).parents('tr')).remove().draw();
//     });
// });



// const resTotal = document.getElementById("total");
// const inputDiscount = document.getElementById("inputInvoiceDiscount");
// const inputVat = document.getElementById("inputInvoiceVat");

// var total = 0;
// $(this).on('input', function () {

//     var serviceTotal = 0 ;
//     var stockTotal = 0 ;
//     $('#inputServiceTable').DataTable().rows().every(function() {
//         const data = this.data();
//         const row = this.node(); 
//         const quantity_service = $(row).find('input[name^="item-quantity"]');
//         const unitPrice_service = $(row).find('input[name^="item-unit-price"]');
//         $(quantity_service).on("input", function() {
//         if (this.value.length > 3) {
//             this.value = this.value.slice(0, 3);
//             }
//         });
//         $(unitPrice_service).on("input", function() {
//             if (this.value.length > 5) {
//                 this.value = this.value.slice(0, 5);
//                 }
//         });
//         serviceTotal = ($(quantity_service).val() * $(unitPrice_service).val()) + serviceTotal;
//         console.log(serviceTotal);
//     });
//     $('#inputStockTable').DataTable().rows().every(function() {
//         const data = this.data();
//         const row = this.node();
//         const quantity_stock = $(row).find('input[name^="item-stock-quantity"]');
//         const unitPrice_stock = $(row).find('input[name^="item-stock-unit-price"]');

//         $(quantity_stock).on("input", function() {
//             if (this.value.length > 3) {
//                 this.value = this.value.slice(0, 3);
//                 }
//             });
//         $(unitPrice_stock).on("input", function() {
//             if (this.value.length > 5) {
//                 this.value = this.value.slice(0, 5);
//                 }
//         });

//         stockTotal = ($(quantity_stock).val() * $(unitPrice_stock).val()) + stockTotal;
//     });

//     total = serviceTotal + stockTotal;

//     var discount = total * (inputDiscount.value / 100);
//     total = total - discount;
//     var vat = total * (inputVat.value / 100);
//     total = total + vat;
//     resTotal.innerHTML = "Total: €" + total;
//     const totalField = document.getElementById("invoice-total");
//     totalField.value = total.toString();
// });


// document.getElementById("inputInvoiceVat").addEventListener("input", function() {
//     if (this.value.length > 3) {
//         this.value = this.value.slice(0, 3);
//     }
//     if (this.value > 100){
//         this.value = 100;
//     }
// });
// document.getElementById("inputInvoiceDiscount").addEventListener("input", function() {
//     if (this.value.length > 3) {
//         this.value = this.value.slice(0, 3);
//     }
//     if (this.value > 100){
//         this.value = 100;
//     }
// });

// document.getElementById("inputIsValidFor").addEventListener("input", function() {
//     if (this.value.length > 3) {
//         this.value = this.value.slice(0, 3);
//     }
//     if (this.value > 365){
//         this.value = 365;
//     }
// });

function removeRequired(){ 
    $('#inputPhoneNumber').removeAttr('required');
    $('#inputEmail').removeAttr('required');
    $('#inputName').removeAttr('required');
    $('#inputSurname').removeAttr('required');
}
function addRequired(){ 
    $('#inputName').prop('required',true);
    $('#inputPhoneNumber').prop('required',true);
    $('#inputEmail').prop('required',true);
    $('#inputSurname').prop('required',true);
}
var new_customer = $('#new-customer').hide();
var existing_customer = $('#existing-customer').hide();
removeRequired();

$('#customer-options').change(()=>{ 
    var option = $('#customer-options').find('option:selected').val();
    if (option === 'Existing Customer'){ 
        new_customer.hide();
        removeRequired();
        existing_customer.show();
        
    }else if(option === 'New Customer'){ 
        existing_customer.hide();
        addRequired();
        new_customer.show();
    }
});


new TomSelect('#select-item',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});


$(document).ready(function () {

    var t = $('#inputServiceTable').DataTable({
        columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
        lengthChange:false,
        pageLength: 5,
        ordering:false,
        searching: false
    });
 
    t.on('order.dt search.dt', function () {
        let i = 1;
 
        t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();

    var counter = 2 ;
    $('#addRow').on( 'click', function () {
        t.row.add( [
            '<input class="form-control" type="text" name="service-name[' + counter +']" id="inputServiceName' + counter + '" required/>',
            '<input class="form-control" type="text" name="service-description[' + counter +']" id="inputServiceDescription' + counter + '"/>',
            '<input class="form-control service-quantity" data-index="'+counter+'" type="number" name="service-quantity[' + counter +']" id="inputServiceQuantity' + counter + '" min="0" value="0" style="width: 67px;"/>',
            '<input class="form-control service-price" data-index="'+counter+'" type="number" name="service-unit-price[' + counter +']" id="inputServicePrice' + counter + '" " min="0"  step="1.0" value="0.00" style="width: 70px;" required/>',
            '<p  class="me-5 h5" name="service-total-price" id="serviceTotal' + counter + '"></p>',
            '<button type="button" class="removeRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ]).draw( false );
        counter++;
    });
 
    $('#inputServiceTable tbody').on( 'click', '.removeRow', function () {
        t.row( $(this).parents('tr')).remove().draw();
    });
});

$(document).ready(function () {
    var t2 = $('#inputStockTable').DataTable({
        columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
        lengthChange:false,
        pageLength: 5,
        ordering:false,
        searching: false
    });
 
    t2.on('order.dt search.dt', function () {
        let i = 1;
 
        t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();

    var counter = 2;
    $('#addStockRow').on( 'click', function () {
        t2.row.add( [
            `<div class="d-flex justify-content-center">
                <button class="btn btn-primary add-item" type="button" value="`+ counter +`" name="item-stock-name[` + counter + `]" id="inputStockItemName` + counter + `" data-bs-toggle="modal" data-bs-target="#stockModal" required>
                    <input type="hidden" id="itemId` + counter + `" name="item-stock-id[` + counter + `] required"/>
                    Select item
                </button>
            </div>`,
            '<p  class="w-auto border text-center mt-2 h5" name="item-name"  id="itemName' + counter + '"></p>',
            '<input class="form-control stock-quantity" form-control" type="number" data-index="'+counter+'" name="item-stock-quantity[' + counter +']" id="inputStockQuantity' + counter + '" min="0" value="1" style="width: 67px;" required/>',
            '<p  class="text-center h5" name="item-price" id="itemPrice' + counter + '"></p>',
            '<p  class="me-5 h5" name="item-total-price" id="itemTotal' + counter + '"></p>',
            '<button type="button" class="removeStockRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ] ).draw( false );
        counter++;
    } );

    $('#inputStockTable tbody').on( 'click', '.removeStockRow', function () {
        t2.row( $(this).parents('tr')).remove().draw();
    });
});

var total = 0;
var serviceTotal = 0 ;
var stockTotal = 0;
var add_stock = 0;
var total_combined = 0;

$('#combinedTotal').html('Total (€): ' + total_combined);
function calculate_service_total(){ 
    serviceTotal = 0 ;
    $('#inputServiceTable').DataTable().rows().every(function() {
        const row = this.node(); 
        const quantity_service = $(row).find('input[name^="service-quantity"]');
        const unitPrice_service = $(row).find('input[name^="service-unit-price"]');
        serviceTotal = (parseInt($(quantity_service).val()) * parseFloat($(unitPrice_service).val())) + serviceTotal;
    });
    return serviceTotal;
}

function calculate_stock_total(){ 
    stockTotal = 0 ;
    $('#inputStockTable').DataTable().rows().every(function() {
        const row = this.node();
        const quantity_stock_val = $(row).find('input[name^="item-stock-quantity"]');
        const unitPrice_stock = $(row).find('p[name^="item-price"]');
        stockTotal = $(quantity_stock_val).val() * parseFloat($(unitPrice_stock).html()) + stockTotal;
    });
    return stockTotal;
}
function calculate_combined_total() {
    total_combined = calculate_stock_total() + calculate_service_total();
    $('#invoice-total').val(total_combined);
    console.log(total_combined);
    $('#combinedTotal').html('Total (€): ' + total_combined);
    return total_combined;
}

$(document).on('input', '.service-quantity', function () {
    var quantity = $(this).val();
    console.log(quantity);
    var index = $(this).attr('data-index');
    serviceTotal = quantity * $('#inputServicePrice'+index).val();
    var total = $("#serviceTotal"+index).val(serviceTotal);
    $(total).html(serviceTotal);
    calculate_combined_total();
});

$(document).on('input', '.service-price', function () {
    var unit_price = $(this).val();
    var index = $(this).attr('data-index');
    console.log(index);
    serviceTotal = unit_price * $('#inputServiceQuantity'+index).val();
    var total = $("#serviceTotal"+index).val(serviceTotal);
    $(total).html(serviceTotal);
    calculate_combined_total();
});

var index = 0;
$(document).on('click', '.add-item', function () {
    index = $(this).val();
});

$(document).on('input', '.stock-quantity', function () {
    var quantity = $(this).val();
    var index = $(this).attr('data-index');
    itemTotal = quantity * $('#itemPrice'+index).html();
    var total = $("#itemTotal"+index).val(itemTotal);
    $(total).html(itemTotal);
    calculate_combined_total();
});

$('#addItem').on('click', function () {

    var item = $('#select-item').find(":selected");
    var itemID = $(item).val();
    var itemName = $(item).attr('data-i_name');
    var itemPrice = $(item).attr('data-i_price');

    $('#itemId'+index).val(itemID);
    $('#itemName'+index).html(itemName);
    $('#itemPrice'+index).html(itemPrice);
    var quantity = $('#inputStockQuantity'+index).val();
    itemTotal = quantity * itemPrice;
    $("#itemTotal"+index).html(itemTotal);
    calculate_combined_total();
});


$('#create_invoice_button').on('click', function () {
    var service = [];
    var services = [];
    $('#inputServiceTable').DataTable().rows().every(function() {
        const row = this.node();
        const service_name = $(row).find('input[name^="service-name"]');
        const service_description = $(row).find('input[name^="service-description"]');
        const service_quantity = $(row).find('input[name^="service-quantity"]');
        const service_price = $(row).find('input[name^="service-unit-price"]');
        service = {'name' : $(service_name).val(), 'description' : $(service_description).val(), 'quantity' : $(service_quantity).val(), 'price' : $(service_price).val()};
        services.push(service);
    });
    var service_data = {'services' : services};

    var item_data = [];
    var stock = [];
    $('#inputStockTable').DataTable().rows().every(function() {
        const row = this.node();
        const item_id = $(row).find('input[name^="item-stock-id"]');
        const quantity_stock_val = $(row).find('input[name^="item-stock-quantity"]');
        item_data = {'item_id' : $(item_id).val(), 'quantity' : $(quantity_stock_val).val()};
        stock.push(item_data);
    });
    var stock_data = {'stock' : stock};

    var data_json = {service_data, stock_data};
    $('#tablesData').val(JSON.stringify(data_json));
});
