<!DOCTYPE html>
<html lang="en">

<head>
    <link href="../assets/css/stock.css" rel="stylesheet" />
    <link href="../assets/datatables/datatables.css" rel="stylesheet" />
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
    <script src="../assets/js/scripts.js"></script>
    <title>Stock - Ordinatio Manager</title>
</head>
<?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->

<body>
    <div id="layoutSidenav_content">
        <div class="container-fluid px-2 mt-5 ms-4">
            <h1><i class="bi bi-box-seam me-2"></i>Stock</h1>
            <?php 
                if (isset($_GET['error'])){
                echo '<div class="p-error mb-2 ms-5"><span>' . $_GET['error'] . '</span>
                    <button class="close-btn">&times;</button>
                </div>';
                }
                elseif (isset($_GET['success'])){
                    echo '<div class="p-success mb-2 ms-5"><span>' . $_GET['success'] . '</span>
                        <button class="close-btn">&times;</button>
                    </div>';
                }
            ?>
            <div class="card border rounded-2 border-10 ms-5 border-olive" style="width: 93%;">
                <div class="card-body" style="display : flex;align-items : center;">
                    <?php
                            require_once '../src/db_connect.php';
                            
                            $sql_customer = "SELECT * FROM stock;";
                            $result = mysqli_query($conn, $sql_customer);
                            
                            if (mysqli_num_rows($result) > 0) {                                        
                                while($row = mysqli_fetch_assoc($result)){
                                    $id = $row['item_id'];
                                    $name = $row['name'];
                                    $quantity = $row['quantity'];
                                    $volume = $row['volume'];
                                    $width = $row['width'];
                                    $height = $row['height'];
                                    $size = $row['size'];
                                    $price = $row['price'];
                                    $image = $row['image'];

                                    
                                    echo "<a data-i_id='$id' data-i_name='$name' data-i_quantity ='$quantity' 
                                    data-i_volume='$volume' data-i_width='$width' data-i_height='$height' data-i_size='$size'
                                    data-i_price='$price' data-i_image='$image' class='stock-item me-2' data-bs-toggle='modal' data-bs-target='#edit_item'>";
                                    echo "<img src='$image'alt='image of $name' style='width: 100%; height: 75%;'>";
                                    echo "<div style='margin-left: 5px;'>";
                                            echo "<p id='item-name-text' class='text-start h6'>Name: $name</p>";
                                            echo "<p class='text-start h6'>Price:€$price</p>";
                                            echo "<p class='text-start h6'>Quantity: $quantity</p>";
                                    echo "</div>";
                                    echo "</a>"; 
                                }  
                            }
                            else {
                                echo "
                                    <p class='text-start h5 mt-2'>No items in stock</p>
                                    ";
                            }
                        ?>
                </div>
                <?php if ($_SESSION['position']['create_stock'] === '1' || $_SESSION['is_admin'] ==='1' ){ ?>
                <div class="modal fade" id="edit_item" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content"  style="padding: 15px;">
                            <div class="modal-header">
                                <h4 class="modal-title"><i class="bi bi-box-seam"></i> Edit Item</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form class="ms-3 mt-3 me-3 mb-3" id="register_form" method="POST" action="update_item.php"
                                enctype="multipart/form-data" novalidate>
                                <input name="product_id_edit" id="inputID_edit" hidden required />
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" name="product_name_edit"
                                                id="inputProductName_edit" type="text" placeholder="Enter product name"
                                                required />
                                            <label for="inputProductName">Product Name<span class="required-field"> *</span></label>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-floating">
                                            <input class="form-control" name="height_edit" id="inputHeight_edit"
                                                type="number" min="0" placeholder="Enter product height" />
                                            <label for="inputHeight">Height</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-floating">
                                            <input class="form-control" name="width_edit" id="inputWidth_edit"
                                                type="number" min="0" placeholder="Enter product width" />
                                            <label for="inputWidth">Width</label>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-floating">
                                            <input class="form-control" name="size_edit" id="inputSize_edit"
                                                type="number" min="0" placeholder="Enter product size" />
                                            <label for="inputSize">Size</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input class="form-control" name="quantity_edit" id="inputQuantity_edit"
                                                type="number" placeholder="Enter product quantity" min="1" value="1" required />
                                            <label for="inputQuantity">Quantity<span class="required-field"> *</span></label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mbmd-0">
                                            <input class="form-control" name="volume_edit" id="inputVolume_edit"
                                                type="number" placeholder="Enter product Volume" min="0.0" value="0.0" />
                                            <label for="inputVolume">Volume</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input class="form-control" name="price_edit" id="inputPrice_edit"
                                                type="number" placeholder="Enter product price" min="0.0" value="0.0" required />
                                            <label for="inputPrice">Price<span class="required-field"> *</span></label>
                                        </div>
                                    </div>
                                    <div class="col-md-6" style="margin-top: -5px;">
                                        <label class="form-label" for="image_edit"></label>
                                        <input type="file" class="form-control" name="image_edit" accept=".jpeg, jpg, .png" />
                                    </div>
                                    <input name="image_path" id="inputImage_edit_path" hidden />
                                </div>
                                <div class="modal-footer mt-4">
                                    <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                            </form>
                            <button type="submit" id="delete_item_btn" class="btn btn-danger btns" data-bs-toggle="modal" data-bs-target="#delete-item-modal">Delete</button>
                        </div>
                    </div>
                </div>
                    <div id="delete-item-modal" class="modal fade" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><i class="bi bi-trash-fill"></i> Delete Stock Item</h4>
                                    <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                    <form class="d-inline ms-2" id="register_form" method="POST" action="../src/delete_item.php">
                                        <div class="modal-body">
                                            <input name="product_id_delete" id="inputID_delete" hidden required />
                                            <p class="h5">Deleting a stock item will permanently remove it from the inventory.</p>
                                        </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger btns">Delete</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!-- --------------------------------------- End --------------------------------------- -->
    <script src="../assets/datatables/datatables.js"></script>
    <script src="../assets/js/stock_edit.js"></script>
    <script src="../assets/js/validate-stock.js"></script>
</body>

</html>