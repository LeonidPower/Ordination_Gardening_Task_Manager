document.addEventListener('click', function (e) {
    if (e.target.classList.contains('close-btn')) {
        e.target.parentElement.style.display = 'none';
    }
});