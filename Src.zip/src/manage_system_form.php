<?php 
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['position_name']))
    {
    
        $position_name = validate($_POST['position_name']);

        if(empty($position_name)){ 
            header("Location: position.php?error=Position name cannot be empty");
            exit();
        }

        if($_POST['view_projects_range_hidden'] === '2'){ 
            $view_projects = 2;
        }
        elseif ($_POST['view_projects_range_hidden'] === '1'){ 
            $view_projects = 1;
        }else{
            $view_projects = 0;
        }

        if($_POST['view_tasks_range_hidden'] === '2'){ 
            $view_tasks = 2;
        }
        elseif ($_POST['view_tasks_range_hidden'] === '1'){ 
            $view_tasks= 1;
        }else{
            $view_tasks = 0;
        }
        
        if($_POST['create_tasks_range_hidden'] === '2'){ 
            $create_tasks = 2;
        }
        elseif ($_POST['create_tasks_range_hidden'] === '1'){ 
            $create_tasks = 1;
        }else{
            $create_tasks = 0;
        }

        $view_users = validate($_POST['view_users_hidden']) == '1' ? 1 : 0;
        $view_invoices = validate($_POST['view_invoices_hidden']) == '1' ? 1 : 0;
        $view_quotes = validate($_POST['view_quotes_hidden']) == '1' ? 1 : 0;
        $view_customers = validate($_POST['view_customers_hidden']) == '1' ? 1 : 0;
        $view_stock = validate($_POST['view_stock_hidden']) == '1' ? 1 : 0;

        $create_projects = validate($_POST['create_projects_hidden']) == '1' ? 1 : 0;  
        $create_users = validate($_POST['create_users_hidden']) == '1' ? 1 : 0;
        $create_invoices = validate($_POST['create_invoices_hidden']) == '1' ? 1 : 0;
        $create_quotes = validate($_POST['create_quotes_hidden']) == '1' ? 1 : 0;
        $create_customers = validate($_POST['create_customers_hidden']) == '1' ? 1 : 0;
        $create_stock = validate($_POST['create_stock_hidden']) == '1' ? 1 : 0;

        $is_admin = isset($_POST['admin']) ? 1 : 0;
        $is_project_manager = isset($_POST['project_manager']) ? 1 : 0;

        $stmt = $conn->prepare("SELECT * FROM position WHERE name=?");
        $stmt->bind_param("s", $position_name);
        $stmt->execute();
        $result = $stmt->get_result();

        if(empty($view_tasks) && $create_tasks){ 
            header('Location: manage_system.php?error=Viewing tasks is required to create tasks');
            exit();
        }

        if(empty($view_projects) && $create_projects){
            header('Location: manage_system.php?error=Viewing projects is required to create projects');
            exit();
        }

        if(empty($view_users) && $create_users){ 
            header('Location: manage_system.php?error=Viewing users is required to create users');
            exit();
        }

        if(empty($view_invoices) && $create_invoices){ 
            header('Location: manage_system.php?error=Viewing invoices is required to create invoices');
            exit();
        }

        if(empty($view_quotes) && $create_quotes){ 
            header('Location: manage_system.php?error=Viewing quotes is required to create quotes');
            exit();
        }

        if(empty($view_customers) && $create_customers){ 
            header('Location: manage_system.php?error=Viewing customers is required to create customers');
            exit();
        }

        if(empty($view_stock) && $create_stock){ 
            header('Location: manage_system.php?error=Viewing stock is required to create stock');
            exit();
        }


        if (!mysqli_num_rows($result))
        {
            $stmt = $conn->prepare("INSERT INTO position (name, project_manager) VALUES (?, ?)");
            $stmt->bind_param("ss", $position_name, $is_project_manager);
            $stmt->execute();
            $new_position_id = $stmt->insert_id;

      
            $stmt = $conn->prepare("INSERT INTO position_atributes (view_tasks, view_projects, view_users, view_invoices, view_quotes, view_customers, view_stock, create_tasks, create_projects, create_users, create_quotes, create_invoices, create_customers, create_stock, super_admin, position_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Bind the parameters
$stmt->bind_param("iiiiiiiiiiiiiiii", $view_tasks, $view_projects, $view_users, $view_invoices, $view_quotes, $view_customers, $view_stock, $create_tasks, $create_projects, $create_users, $create_quotes, $create_invoices, $create_customers, $create_stock, $is_admin, $new_position_id);
$stmt->execute();
$result = $stmt->get_result();


            header("Location: manage_system.php?success=Position created successfully");

        }else{ 
            header("Location: manage_system.php?error=Position name already used");
            exit();
        }

    }
    else{ 
        header("Location: manage_system.php?error=Position name is not set");
        exit();
    }
?>