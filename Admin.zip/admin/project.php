<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="../assets/css/project.css" rel="stylesheet" />
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
        <title>Projects - Ordinatio Manager</title>
    </head>
    <?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">    
                <h1 class="inline"><i class="bi bi-view-stacked"></i>Projects</h1>
                <?php 
                    if (isset($_GET['error'])){
                    echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                        <button class="close-btn mb-1">&times;</button>
                    </div>';
                    }
                    elseif (isset($_GET['success'])){
                        echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';
                    }
                 ?>
                <div class="table-size-1 mt-4">
                    <div class="row d-flex justify-items-center">
                        <div class="col-md-3">
                            <div class="form-check">
                                <input class="form-check-input" id="filter_by_status_active" name="filter_status_active" type="checkbox" value="1" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">
                                    Show Active Projects
                                </label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-check">
                                <input class="form-check-input" id="filter_by_status_finished" name="filter_status_finished" type="checkbox" value="1" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">
                                    Show Finished Projects
                                </label>
                            </div>
                        </div>
                    </div>
                    <p></p>
                    <table id="projects-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <?php if ($_SESSION['position']['create_projects'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                    echo '<th>Select</th>';
                                } ?>
                                <th>ID</th>
                                <th>Project Name</th>
                                <th>Location</th>
                                <th>Start Day</th>
                                <th>End Day</th>
                                <th>Customer</th>
                                <th>Status</th>
                                <th>Supervisors</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                require_once '../src/fetch_projects.php'; 

                                foreach ($projects as $p){

                                    echo " ";
                                    echo "<tr data-p_id='$p->project_id' data-p_name='$p->project_name' data-p_address='$p->project_address' 
                                              data-p_num='$p->project_number' data-p_city='$p->project_city' data-p_post='$p->project_post' 
                                              data-p_start_date='" . date("Y-m-d", $p->project_start_date) . "' data-p_end_date='" . date("Y-m-d", $p->project_end_date) . "' data-p_description='$p->project_description'
                                              data-p_customer='" . htmlspecialchars($p->customer->customer_hash) . "'>";
                                    if ($_SESSION['position']['create_projects'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                        echo "<td style='text-align: center;width:40px;'><input class='mt-1 form-check-input' name='project_select' type='radio' style='height:20px;width:20px'></td>";
                                    }
                                    echo "<td>" . htmlspecialchars($p->project_id) . "</td>";
                                    echo "<td>" . htmlspecialchars($p->project_name) . "</td>";
                                    echo "<td>" . htmlspecialchars($p->project_address) ." " . htmlspecialchars($p->project_number) ." Πόλη: " . htmlspecialchars($p->project_city) ."Τ.Κ: " . htmlspecialchars($p->project_post) . "</td>";
                                    echo "<td>" . htmlspecialchars(date('Y-m-d',$p->project_start_date)) . "</td>";
                                    echo "<td>" . htmlspecialchars(date('Y-m-d',$p->project_end_date)) . "</td>";
                                    
                                    $c_name = htmlspecialchars($p->customer->customer_name);
                                    $c_surname = htmlspecialchars($p->customer->customer_surname);
                                    $c_email = htmlspecialchars($p->customer->customer_email);
                                    $c_phone = htmlspecialchars($p->customer->customer_phone);
                                    $c_company = htmlspecialchars($p->customer->customer_company);
                                    $c_address = htmlspecialchars($p->customer->customer_address);
                    
                                    echo "<td><a value='' class='sup-color customers' data-c_name='$c_name' data-c_surname='$c_surname' data-c_email='$c_email' data-c_phone='$c_phone' data-c_company='$c_company' data-c_address='$c_address'
                                         data-bs-target='#customer_modal' data-bs-toggle='modal' style='padding:5pt; margin-left:2pt; background-color:rgba(255, 255, 255, 0);'>" . htmlspecialchars($p->customer->customer_name) ." ".  htmlspecialchars($p->customer->customer_surname) . "</td>";
                                    if($p->project_end_date >= strtotime(date("Y-m-d")) && !($p->project_status)){
                                        echo "<td data-p_status='$p->project_status' ><p hidden>1</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #1dff1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></i></td>";
                                    }
                                    else{ 
                                        echo "<td data-p_status='$p->project_status'><p hidden>0</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #ff1d1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></td>";
                                    }
                                    echo "<td>";
                                        foreach ($p->project_supervisors as $s){
                                            
                                            echo "<a data-p_supervisor='$s->supervisor_hash' style='padding:5pt; margin-left:2pt; background-color:rgba(255, 255, 255, 0);' >" . htmlspecialchars($s->supervisor_name) . " " . htmlspecialchars($s->supervisor_surname) . "</a>"; //clickable modal to open and close supervisor
                                        }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                                                                
                            ?>
                        </tbody>
                    </table>
                    <?php if ($_SESSION['position']['create_projects'] === '1' || $_SESSION['is_admin'] ==='1' ){ ?>
                    <button id="edit_project_btn" type="button" class="btn btn-primary btns" data-bs-toggle="modal" data-bs-target="#edit_project" disabled>Edit</button>
                    <button type="submit" id="delete_project_btn" class="btn btn-danger btns ms-2" data-bs-toggle="modal" data-bs-target="#delete-user-modal" disabled>Delete</button>
                    <div id="delete-user-modal" class="modal fade" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                    <h4 class="modal-title"><i class="bi bi-trash-fill"></i> Delete Project</h4>
                                <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="../src/delete_project.php" method="post" id="register_form">
                                <div class="modal-body">
                                <p class="h5">
                                    <input name="id_del" id="inputID_del" required hidden/>
                                    Deleting the project could affect associated data. This action cannot be undone.
                                </p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-danger btns">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                    <div id="customer_modal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title"><i class="bi bi-person-lines-fill inline"></i> Customer Details</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <div id="customer-details">
                                <p id="cname">Name: </p>
                                <p id="csurname">Surname:</p>
                                <p id="cemail">Email: </p>
                                <p id="cphone">Phone: </p>
                                <p id="ccompany">Company: </p>
                                <p id="caddress">Address: </p>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                    <div class="modal fade" id="edit_project" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content" style="padding: 15px;">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-view-stacked"></i> Edit project</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <br>
                                <form id="register_form" method="POST" action="update_project.php" novalidate>
                                    <div class="ms-3 me-3">
                                        <input name="project_id_edit" id="inputID_edit" required hidden/>
                                        <div id="select-customer">
                                            <p class="form-floating">Select Customer<span class="required-field"> *</span></p>
                                            <div class="form-floating mb-3 mbmd-0">
                                                
                                                <?php
                                                    require_once '../src/db_connect.php';
                                                    require_once '../src/objects.php';
                                                    
                                                    $sql_customer = "SELECT customer_id, name, surname, email, phone, address, hash FROM customer;";
                                                    $stmt = $conn->prepare($sql_customer);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();
                                                    $customer_info = array();
                                                    $i = 0;
                                                    
                                                    if ($result->num_rows > 0) {
                                                        echo '<div class="row mb-3">
                                                                <div class="col-md-6">
                                                                    <div class="form-floating mb-3 mb-md-0">
                                                                        <select class="form-control" id="select-customer-data" name="customer" autocomplete="off" placeholder="Customer" required>
                                                                        <option disabled></option></div></div></div>
                                                                ';
                                                        
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<option value="' . $row['hash'] . '" name="hash' .  '">' . $row['name'] . ' ' . $row['surname'] . '</option>';
                                                            $i++;
                                                        }
                                                        echo '</select>';
                                                    }
                                                    
                                                ?>
                                            </div>
                                        </div> 
                                        <div id="project">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="project-name" id="inputProjectName" type="text" placeholder="Name" required/>
                                                        <label for="inputProjectName">Project Name<span class="required-field"> *</span></label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <br>
                                                        <p>Project Supervisor<span class="required-field"> *</span></p>
                                                        <div class="form-floating mb-3 mbmd-0">
                                                            <?php
                                                                require_once '../src/db_connect.php';
                                                                require_once '../src/objects.php';

                                                                $sql_user = "SELECT user.name AS u_name, user.surname AS u_surname, user.email AS u_email, 
                                                                user.phone AS u_phone, user.address AS u_add, user.hash AS u_hash, project_manager as p_m
                                                                FROM user
                                                                JOIN position ON position.position_id = user.position_id_users;";
                                                
                                                $stmt = $conn->prepare($sql_user);
                                                $stmt->execute();
                                                $result = $stmt->get_result();
                                                
                                                if ($result->num_rows > 0) {
                                                    echo '<select style="width:200%" class="form-control h-100" id="select-supervisor" name="supervisor[]" multiple autocomplete="off" placeholder="Supervisor/s" multiple>';
                                                    
                                                    while ($row = $result->fetch_assoc()) {
                                                        if ($row['p_m']) {
                                                            echo '<option value="' . $row['u_hash'] . '" name="hash' .  '">' . $row['u_name'] .' '. $row['u_surname'] . '</option>';
                                                            $i++;
                                                        }
                                                    }
                                                    
                                                    echo '</select>';
                                                }
                                                  
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                             </div>
                                        </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 w-15">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="city" id="inputCity" type="text" placeholder="City"/>
                                                    <label for="inputCity">City</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 w-15">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="number" id="inputNumber" type="text" placeholder="Num"/>
                                                    <label for="inputNumber">Num</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 w-15">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="post-code" id="inputPost" type="text" placeholder="Post Code"/>
                                                    <label for="inputPost">Post Code</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-3">
                                                <div class="form-floating">
                                                    <input class="form-control" name="project_start_date" id="inputProjectStartDate" type="date" placeholder="Date" required>
                                                    <label for="inputProjectStartDate">Start Date<span class="required-field"> *</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-floating">
                                                    <input class="form-control" name="project_end_date" id="inputProjectEndDate" type="date" placeholder="Date">
                                                    <label for="inputProjectEndDate">End Date<span class="required-field"> *</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-check mt-2">
                                                    <label class="form-check-label ms-2 mt-2" for="inputStatus">Finished</label>
                                                    <input name="project_status" class="form-check-input" type="checkbox" id="inputStatus" style="height:30px; width:30px;">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-2">
                                            <div class="form-group mb-3">
                                                <textarea class="form-control" name="description" id="inputDescription" placeholder="Description" rows="7"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </main>
    </div>
<!-- --------------------------------------- End --------------------------------------- -->

        <script src="../assets/datatables/datatables.js"></script>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="../assets/js/project.js"></script>
        <script src="../assets/js/validate-project.js"></script>
        <script>
            $(document).ready(function() {
            $('.customers').click(function() {
                var c_name = $(this).data('c_name');
                $('#customer_modal').modal('show');
            });
            });
        </script>
    </body>
</html>
