<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    if (isset($_POST['customer']) && isset($_POST['supervisor']) && isset($_POST['project-name']) && isset($_POST['project_start_date']) && isset($_POST['project_end_date']) && isset($_POST['project_id_edit']))
    {
        $project_id = validate($_POST['project_id_edit']);
        $customer_hash = validate($_POST['customer']);
        $project_name = validate($_POST['project-name']);

        $project_start_date = validate($_POST['project_start_date']);
        $project_end_date =validate($_POST['project_end_date']);

        $supervisor  = $_POST['supervisor'];

        $project_address = isset($_POST['address']) ? validate($_POST['address']) : "";
        $project_city = isset($_POST['city']) ? validate($_POST['city']) : "";
        $project_address_num = isset($_POST['number']) ? validate($_POST['number']) : "";
        $project_postal =isset($_POST['post-code']) ? validate($_POST['post-code']) : "";
        $project_description =isset($_POST['description']) ? validate($_POST['description']) : "";

        $project_status = isset($_POST['project_status']) ? 1 : 0;

        $i = 0 ;
        $supervisors_id_array = array();
        $supervisors_array = array();

        $leonidas_sexuality = 0;
    }
    else
    {
        header("Location: project.php?error=Some mandatory fields are empty ");
        exit();
    }

    if(empty($project_id)){ 
        header("Location: project.php?error=Project cannot be empty");
        exit();   
    }else if(empty($project_name)){ 
        header("Location: project.php?error=Project name cannot be empty");
        exit();
    }else if(empty($customer_hash)){ 
        header("Location: project.php?error=Project name cannot be empty");
        exit();
    }else if(empty($project_start_date)){ 
        header("Location: project.php?error=Project start date cannot be empty");
        exit();
    }else if(empty($project_end_date)){
        header("Location: project.php?error=Project end date cannot be empty");
        exit();
    }else if(empty($supervisor)){
        header("Location: project.php?error=Supervisor cannot be empty");
        exit();
    }else{

        while(!empty($supervisor[$i])){
            array_push($supervisors_array , validate($supervisor[$i]));
            $i++;
        }

        // $supervisors_array_new = implode("','",$supervisors_array);

        $sql_find_customer = "SELECT customer_id FROM customer WHERE hash= ? LIMIT 1;";
        $stmt = $conn->prepare($sql_find_customer);

        // Bind parameter
        $stmt->bind_param("s", $customer_hash);

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $customer_id = $row['customer_id'];
        }
        else{
            header("Location: project.php??error=Customer couldn't be found");
            exit();
        }        

        $supervisors_array_new = implode("','",$supervisors_array);

        $array_params = implode(" , " , array_fill(0 , count($supervisors_array), "?"));

        $sql_find_supervisors = "SELECT name, surname, user_id FROM user WHERE hash IN ($array_params);";

        $stmt = $conn->prepare($sql_find_supervisors);


        $params = count($supervisors_array);
        $params = array_fill(0, $params, 's');
        $params = implode('', $params);

        $stmt->bind_param($params, ...$supervisors_array);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                array_push($supervisors_id_array, $row['user_id']);
            }
        }
        else{
            header("Location: project.php??error=Supervisor don't exist");
            exit();
        }

        echo " ";

        
        $sql_insert_new_project = "UPDATE project SET 
                                   name='$project_name', address='$project_address', number='$project_address_num', 
                                   city='$project_city', post_code='$project_postal', start_date='$project_start_date', 
                                   end_date='$project_end_date', description='$project_description', customer_id='$customer_id', 
                                   status='$project_status'
                                   WHERE project_id='$project_id';";
        $result = mysqli_query($conn, $sql_insert_new_project);

        
        // // //Add supervisors for the project
        $sql_delete_supervisors = "DELETE FROM project_supervisors WHERE project_id= ?;";
        $stmt = $conn->prepare($sql_delete_supervisors);

        // Bind parameter
        $stmt->bind_param("i", $project_id);

        $stmt->execute();

        foreach ($supervisors_id_array as $s_id){
            $sql_add_supervisors = "INSERT INTO project_supervisors (project_id, user_id) VALUES (?, ?);";
            $stmt = $conn->prepare($sql_add_supervisors);

            // Bind parameters
            $stmt->bind_param("ii", $project_id, $s_id);

            $stmt->execute();
        }

        header("Location: project.php?success=Project updated successfully");
        exit();
    }
?>

