<?php
    require_once '../admin/super_user_form.html';
    exit();  
?>