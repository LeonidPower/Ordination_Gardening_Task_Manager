<?php
require "db_connect.php";
require_once "objects.php";

$query_get_projects = "SELECT project.project_id AS p_id, project.name AS p_name, project.address AS p_add, project.number AS p_num, project.city AS p_city, 
                        project.post_code AS p_code, project.start_date AS p_s_date, project.end_date AS p_e_date, project.status AS p_status, project.description AS p_desc, 
                        project.customer_id AS c_id, customer.name AS c_name, customer.surname AS c_surname, customer.email AS c_email, customer.phone AS c_phone, 
                        customer.company AS c_comp, customer.address AS c_add, customer.hash as c_hash
                        FROM project
                        JOIN customer ON customer.customer_id = project.customer_id;";

$result = mysqli_query($conn, $query_get_projects);

$projects = array();
$project_obj = null;
$i= 0;

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)){

        $customer_obj = new Objects\Customer($row['c_id'], $row['c_name'], $row['c_surname'], $row['c_email'], $row['c_phone'],
                        $row['c_add'], $row['c_comp'], $row['c_hash']);
        
        $project_obj = new Objects\Project($row['p_id'], $row['p_name'], $row['p_add'], 
                        $row['p_num'], $row['p_city'], $row['p_code'], $row['p_s_date'],
                        $row['p_e_date'], $row['p_status'], $row['p_desc'],  $customer_obj);
        
        $project_id = $row['p_id'];


        $query_get_project_supervisors = "SELECT project_supervisors.user_id AS u_id, user.name AS u_name, user.surname AS u_surname, 
                                          user.phone AS u_phone, user.address AS u_add, user.email AS u_email, user.is_admin AS u_is_admin, 
                                          user.hash AS u_hash, user.position_id_users AS p_id, position.name AS p_name, position.project_manager AS p_is_project_manager
                                          FROM project_supervisors
                                          JOIN user ON user.user_id = project_supervisors.user_id
                                          JOIN position ON position.position_id = user.position_id_users
                                          WHERE project_id=?;";
        $stmt = $conn->prepare($query_get_project_supervisors);
        $stmt->bind_param("i", $project_id);
        $stmt->execute();
        $result_get_supervisors = $stmt->get_result();

        while ($row_sup = mysqli_fetch_assoc($result_get_supervisors)){
            
            $supervisor_obj = new Objects\Supervisor($row_sup['u_id'], $row_sup['u_name'], $row_sup['u_surname'], $row_sup['u_phone'], $row_sup['u_add'], $row_sup['u_email'], $row_sup['p_id'],
                                            $row_sup['p_name'], $row_sup['p_is_project_manager'], $row_sup['u_is_admin'], $row_sup['u_hash']);
            $project_obj->add_supervisor($supervisor_obj);

        }
        
        array_push($projects, $project_obj);
    }
}

?>