<?php
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    function validatephone($data)
    {  
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        if(strlen($data)>=8 && strlen($data)<=13){
            if(preg_match("/[a-z]/i", $data)){
                header("Location: customer.php?error=Invalid phone number");
                exit();
            }else{ 
                return $data;
            }
        }else{ 
            header("Location: customer.php?error=Invalid phone number");
            exit();
        }
    }
?>