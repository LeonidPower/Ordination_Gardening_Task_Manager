<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['password_confirm'])){   
        
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);
        $password = md5(validate($_POST['pass']));
        $password_confirm = md5(validate($_POST['password_confirm']));

        $admin = isset($_POST['admin']) ? true : false;
        $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";
        $address = isset($_POST['address']) ? validate($_POST['address']) : "";
        $position = isset($_POST['position']) ? validate($_POST['position']) : "";

    }
    else{
        include "../admin/user_form.php";
        exit();
    }

    if(empty($firstname)){ 
      header("Location: user_form_intermediate.php?error=Firstname is empty");
      exit();
    }
    elseif(empty($lastname)){ 
        header("Location: user_form_intermediate.php?error=Lastname is empty");
        exit();
    }
    elseif(empty($email)){ 
        header("Location: user_form_intermediate.php?error=Email is empty");
        exit();
    }
    elseif(empty($password)){ 
        header("Location: user_form_intermediate.php?error=Password is empty");
        exit();
    }
    elseif(empty($password_confirm)){ 
        header("Location: user_form_intermediate.php?error=Confirm password is empty");
        exit();
    }
    else{

    $sql_get_position_id = "SELECT position_id FROM position WHERE name=? LIMIT 1;";
    $stmt = $conn->prepare($sql_get_position_id);
    $stmt->bind_param("s", $position);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $position_id = $row['position_id'];


    $sql_check_email = "SELECT * FROM user WHERE email=?";
    $stmt = $conn->prepare($sql_check_email);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        if ($password === $password_confirm) {
            $sql_insert_user = "INSERT INTO user (name, surname, password, phone, address, email, position_id_users, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
            $stmt = $conn->prepare($sql_insert_user);
            $stmt->bind_param("ssssssii", $firstname, $lastname, $password, $phone, $address, $email, $position_id, $admin);
            $stmt->execute();

            $new_user_id = $stmt->insert_id;

            $user_hash = md5($new_user_id);
            $sql_insert_hash = "UPDATE user SET hash=? WHERE user_id=?;";
            $stmt = $conn->prepare($sql_insert_hash);
            $stmt->bind_param("si", $user_hash, $new_user_id);
            $stmt->execute();

            header("Location: user.php?success=New user created");
        } else {
            header("Location: user_form_intermediate.php?error=Passwords don't match");
            exit();
    }
} else {
    header("Location: user_form_intermediate.php?error=Email is already used");
    exit();
}

    }
?>