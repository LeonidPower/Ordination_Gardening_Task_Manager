<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name'])){   
        
        $firstname = $_POST['first_name'];
        $lastname = $_POST['last_name'];
        $hash = $_SESSION['user_hash'];

        $phone = isset($_POST['phone']) ? $_POST['phone'] : "";
        $address = isset($_POST['address']) ? $_POST['address'] : "";
    
    }
    else{
        include "../admin/user_settings.php";
        exit();
    }

   
    if(empty($firstname)){ 
      header("Location: user_settings.php?error=Firstname is empty");
      exit();
    }
    elseif(empty($lastname)){ 
        header("Location: user_settings.php?error=Lastname is empty");
        exit();
    }
    else{
        $sql = "UPDATE user 
         SET name = ?, surname = ?, phone = ?,
         address = ?
         WHERE hash = ?;";
        $stmt = $conn->prepare($sql);

        $stmt->bind_param("sssss", $firstname, $lastname, $phone, $address, $hash);
        $stmt->execute();

        require '../src/fetch_new_session.php';
        header("Location: user_settings.php?success=Information changed");
    }

    $conn->close();
?>