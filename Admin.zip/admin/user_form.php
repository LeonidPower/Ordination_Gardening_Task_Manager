<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register User - Ordinatio Manager</title>
        <link href="../assets/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>

    </head>
    <link rel="icon" type="image/png" href="../assets/img/title.svg">
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                        <a href="../src/user.php"><i class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                                        <p class="text-center font-weight-light display-5 d-block">Create New User</p>
                                        <img class="float-end" src="../assets/img/ordinatio_manager.svg" alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                                    </div>
                                    <div class="card-body">
                                        <form id="register_form" method="POST" action="user_form.php">
                                            <?php 
                                                if (isset($_GET['error'])){
                                                echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                                                    <button class="close-btn mb-1">&times;</button>
                                                </div>';
                                                }
                                                elseif (isset($_GET['success'])){
                                                    echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                                        <button class="close-btn mb-1">&times;</button>
                                                    </div>';
                                                }
                                            ?>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="first_name" id="inputFirstName" type="text" placeholder="Enter your first name" required/>
                                                        <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="last_name" id="inputLastName" type="text" placeholder="Enter your last name" required/>
                                                        <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" required/>
                                                <label for="inputEmail">Email Address <span class="required-field">*</span></label>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="pass" id="inputPassword" type="password" placeholder="Create a password" required/>
                                                        <label for="inputPassword">Password <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="password_confirm" id="inputPasswordConfirm" type="password" placeholder="Confirm password" required/>
                                                        <label for="inputPasswordConfirm">Confirm Password <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <input class="form-control" name="phone" id="inputPhoneNumber" type="tel" placeholder="Phone Number"/>
                                                        <label for="inputPhoneNumber">Phone Number</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                        <label for="inputAddress">Address</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <?php
                                                            require_once '../src/db_connect.php';
                                                            $sql = "SELECT name FROM position;";
                                                            $stmt = $conn->prepare($sql);
                                                            $stmt->execute();
                                                            $result = $stmt->get_result();
                                                            
                                                            if ($result->num_rows > 0) {
                                                                echo '<select class="" id="select-position" name="position" autocomplete="off" placeholder="Position" required>
                                                                        <option disabled selected value></option>';
                                                            
                                                                while ($row = $result->fetch_assoc()) {
                                                                    echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
                                                                }
                                                            
                                                                echo '</select>';
                                                            }

                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-check mb-3">
                                                        <input class="form-check-input" name="admin" id="inputIsAdmin" type="checkbox" value="0">
                                                        <label class="form-check-label" for="inputIsAdmin">Administrator account</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-4 mb-0">
                                                <button class="btn btn-primary btn-block" type="submit" id="register_button">Register</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="../assets/js/user_form.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="../assets/js/validate-form-users.js"></script>
    </body>
</html>
