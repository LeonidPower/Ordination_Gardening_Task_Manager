<?php
    require 'check_login.php';

    if($_SESSION['position']['create_invoices'] === '0' && !$_SESSION['is_admin'] === '1'){ 
        header('Location: dashboard.php');
        exit();
    }else{
        require_once 'fetch_invoice.php';
        require_once '../admin/edit_invoice_services.php';
        exit();
    }
?>