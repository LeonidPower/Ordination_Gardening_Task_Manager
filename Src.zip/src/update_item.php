<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['product_name_edit']) && isset($_POST['quantity_edit']) && isset($_POST['price_edit']) && isset($_POST['product_id_edit'])){

        $product_id = validate($_POST['product_id_edit']);
        $product_name = validate($_POST['product_name_edit']);
        $quantity = validate($_POST['quantity_edit']);
        $price = validate($_POST['price_edit']);
        $image_present = false;

        $image_path = isset($_POST['image_path']) ? validate($_POST['image_path']) : null;
        $volume = isset($_POST['volume_edit']) ? validate($_POST['volume_edit']) : null;

        if (isset($_FILES['image_edit']) && !empty($_FILES['image_edit']['name'])) { 
            if ($_FILES['image_edit']['error'] == UPLOAD_ERR_OK) {

                $image_name = basename($_FILES['image_edit']['name']);
                $extension = pathinfo($image_name, PATHINFO_EXTENSION);
                $unique_image_name = uniqid() . '.' . $extension;
                
                $upload_to = '../assets/stock_images/' . $unique_image_name;
                $image_present = true;

            } else {
                header("Location: stock.php?error=Image failed to upload");
                exit();
            }
        }

        if(isset($_POST['width_edit']) && isset($_POST['height_edit']) && isset($_POST['size_edit'])){ 
            $width = validate($_POST['width_edit']);
            $height = validate($_POST['height_edit']);
            $size = validate($_POST['size_edit']);
        }
        else{
            header("Location: stock.php?error=All dimension fields are required");
            exit();
        }
    }
    else{
        include "../admin/stock.php";
        exit();
    }

    if(empty($product_id)){ 
        header("Location: stock.php?error=Empty fields found");
        exit();
    }
    else if(empty($product_name)){ 
      header("Location: stock.php?error=Product name is empty");
      exit();
    }
    elseif(empty($quantity)){ 
        header("Location: stock.php?error=Quantity is empty");
        exit();
    }
    elseif(empty($price)){ 
        header("Location: stock.php?error=Price is empty");
        exit();
    }
    else{
        if ($image_present){ 
            move_uploaded_file($_FILES['image_edit']['tmp_name'], $upload_to);
        }else{
            $upload_to = $image_path;
        }
        $sql = "UPDATE stock SET name=?, quantity=?, volume=?, width=?, height=?, size=?, price=?, image=? WHERE item_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssi", $product_name, $quantity, $volume, $width, $height, $size, $price, $upload_to, $product_id);
        $stmt->execute();
        
        header("Location: stock.php?success=Item data updated");
        
    }
?> 