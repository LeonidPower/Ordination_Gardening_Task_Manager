<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Create Task - Ordinatio Manager</title>
      <link href="../assets/css/styles.css" rel="stylesheet" />
      <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

      <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
      <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
      <link rel="icon" type="image/png" href="../assets/img/title.svg">
      <script src="../assets/js/scripts.js"></script>
   </head>
   <body class="bg-primary">
      <main>
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-8">
                  <div class="card shadow-lg border-0 rounded-lg mt-5">
                     <div class="card-header">
                        <a href="task.php"><i class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                        <p class="text-center font-weight-light display-5 d-block">Create Task</p>
                        <div class="text-center me-1 mt-1">
                           <img class="float-end" src="../assets/img/ordinatio_manager.svg" alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                        </div>
                     </div>
                     <div class="card-body">
                        <form id="task_form" method="POST" action="task_form.php">
                           <?php 
                              if (isset($_GET['error'])){
                              echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                                 <button class="close-btn mb-3">&times;</button>
                              </div>';
                              }
                              elseif (isset($_GET['success'])){
                                 echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                    <button class="close-btn mb-3">&times;</button>
                                 </div>';
                              }
                           ?>
                           <div id="task">
                              <div class="row mb-3">
                                 <div class="col-md-6">
                                    <div class="form-floating mb-3 mbmd-0">                
                                       <?php
                                          require_once '../src/db_connect.php';
                                          require_once '../src/objects.php';
                                          
                                          $sql_customer = "SELECT * FROM project";
                                          $stmt = $conn->prepare($sql_customer);
                                          $stmt->execute();
                                          $result = $stmt->get_result();
                                          $customer_info = array();
                                          $i = 0;
                                          
                                          if ($result->num_rows > 0) {

                                             echo '<select style="width:100%;" id="select-project" name="project" autocomplete="off" placeholder="Select Project" required>
                                                      <option value="" selected disabled>Select Project</option>';
                                                   
                                                   while($row = $result->fetch_assoc()){
                                                      $start_date = $row['start_date'];
                                                      $end_date = $row['end_date'];
                                                      $project_id = $row['project_id'];
                                                      $formated_start_date2 = date("d/m/Y", strtotime($start_date));
                                                      $formated_end_date2 = date("d/m/Y", strtotime($end_date));

                                                      echo "<option data-p_start_date='$start_date' data-p_end_date='$end_date' value='$project_id'>" . $row['name'] . " (" . $formated_start_date2 ." to " . $formated_end_date2 .")" . "</option>";
                                                      $i++;
                                                   }
                                             echo '</select>';      
                                          }  
                                          ?>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                       <?php
                                          require_once '../src/db_connect.php';
                                          require_once '../src/objects.php';
                                          require_once '../src/check_login.php';
                                          
                                          $sql_user = "SELECT user.name AS u_name, user.surname AS u_surname, user.hash AS u_hash FROM user";
                                          $stmt = $conn->prepare($sql_user);
                                          $stmt->execute();
                                          $result = $stmt->get_result();
                                          
                                          if ($result->num_rows > 0) {
                                                echo '<select style="width:100%" class="form-control h-100" id="select-assignees" name="assignee[]" multiple autocomplete="off" placeholder="Assignee/s" multiple required>
                                                      <option value="" selected disabled>Select Assignees/s</option>';
                                                
                                                   while($row = $result->fetch_assoc()){
                                                      $u_hash = $row['u_hash'];

                                                      if($_SESSION['position']['create_tasks'] == 1){
                                                         if($_SESSION['user_hash'] == $u_hash){
                                                            echo "<option value='$u_hash'>" . $row['u_name'] .' '. $row['u_surname'] . "</option>";
                                                         }
                                                      }else{ 
                                                         echo "<option value='$u_hash'>" . $row['u_name'] .' '. $row['u_surname'] . "</option>";
                                                      }
                                                   }
                                             echo '</select>';      
                                          
                                          } 
                                          ?>
                                    </div>
                                 </div>
                              </div>
                              <div class="row mb-3">
                                 <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                       <input class="form-control" name="task-name" id="inputTaskName" type="text" placeholder="Task Name" required/>
                                       <label for="inputTaskName">Task Name<span class="required-field"> *</span></label>
                                    </div>
                                 </div>
                                 <div class="col-md-3">
                                    <div class="form-floating">
                                       <input class="form-control" name="task-start-date" id="inputTaskStartDate" type="datetime-local" placeholder="Start Date & Time" required>
                                       <label for="inputTaskStartDate">Start Date<span class="required-field"> *</span></label>
                                    </div>
                                 </div>
                                 <div class="col-md-3">
                                    <div class="form-floating">
                                       <input class="form-control" name="task-end-date" id="inputTaskEndDate" type="datetime-local" placeholder="End Date & Time" required>
                                       <label for="inputProjectEndDate">End Date<span class="required-field"> *</span></label>
                                    </div>
                                 </div>
                              </div>
                              <div class="row mb-3">
                                 <div class="form-group mb-3">
                                    <br>
                                    <textarea class="form-control" name="description" id="inputDescription" placeholder="Description" rows="7"></textarea>
                                 </div>
                              </div>
                              <div class="mt-2 mb-0">
                                 <button class="btn btn-primary btn-block" type="submit" id="create_quote_button">Create Task</button>
                              </div>
                           </div>
                        </form>
                     </div>     
                  </div>
               </div>
            </div>
         </div>

        <?php include '../commons/date_error_modals.html'; ?>
      </main>
      <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
     
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
      <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
      <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

      <script src="../assets/js/task_form.js"></script>
      <script src="../assets/js/task_form_selects.js"></script>
      <script src="../assets/js/validate-form-tasks.js"></script>
   </body>
</html>