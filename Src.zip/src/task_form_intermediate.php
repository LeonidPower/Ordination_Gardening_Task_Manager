<?php
    require 'check_login.php';

    if($_SESSION['position']['view_tasks'] === '0' && !$_SESSION['is_admin'] === '1'){ 
        header('Location: dashboard.php');
        exit();
    }else{ 
        require_once '../commons/task_form.php';
        exit();
    }  
?>