const table = document.getElementById("invoices-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_invoice_btn').removeAttr('disabled');
            $('#delete_invoice_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_invoice_btn').prop('disabled');
            $('#edit_invoice_btn').prop('disabled')
        }
    })
});


$('#edit_invoice_btn').click(()=>{

    if (checkedRow) {

        var row = checkedRow;
        var invoice_id = $(row).attr('data-q_id');

        var current_invoice = invoices.filter(function(invoice) {
            return invoice.invoice_id == invoice_id;
        });

        const invoice_name = current_invoice[0].invoice_name;
        const invoice_status = current_invoice[0].invoice_status;
        const invoice_date = current_invoice[0].invoice_date;
        const vat = current_invoice[0].invoice_vat;

        const discount = current_invoice[0].invoice_discount;
        const invoice_valid_for = current_invoice[0].invoice_valid_for;

        const customer_hash = current_invoice[0].customer;


        var calculate_services = 0 ; 
        current_invoice[0].invoice_services.forEach(service => {
            calculate_services  = calculate_services + parseInt(service.service_quantity) * parseFloat(service.service_price);
        });

        var calculate_stock = 0 ; 
        current_invoice[0].invoice_stock.forEach(stock_item => {
            calculate_stock  = calculate_stock + parseInt(stock_item.stock_quantity) * parseFloat(stock_item.stock_price);
        });

        var discount_amount = parseFloat(current_invoice[0].invoice_discount);
        var vat_amount = parseFloat(current_invoice[0].invoice_vat);

        var total = calculate_total(calculate_services, calculate_stock, discount_amount, vat_amount); 

        $('#inputID').val(invoice_id);
        $('#inputServicesTotal').val(calculate_services);
        $('#inputStockTotal').val(calculate_stock);
        $('#edit_tables').attr('href', 'edit_i_tables_intermediate.php?id=' + invoice_id);        
        $("#inputInvoiceName").val(invoice_name);
        $("#inputInvoiceDate").val(invoice_date);
        $("inputInvoiceStatus").val(invoice_status);
        $("#inputInvoiceVat").val(vat);
        $("#inputInvoiceDiscount").val(discount);
        $("#inputInvoiceValidFor").val(invoice_valid_for);
        $('#inputInvoiceTotal').val(total);
        $("#invoiceTotal").html('Total: €' + total);

        customer_select.setValue(customer_hash);
    }

});

function calculate_total(services, stock, discount, vat){ 
    total = 0 ; 
    subtotal = services + stock;

    discount_amount = subtotal * discount/100;

    vat_amount = (subtotal - discount_amount) * vat/100;

    total = (subtotal - discount_amount + vat_amount).toFixed(2);

    return total;
}
$('#delete_invoice_btn').click(()=>{ 
    var row = checkedRow;
    var invoice_id = $(row).attr('data-q_id');
    $("#inputID_del").val(invoice_id);
});

$('#inputInvoiceVat').change(()=>{
    var total_combined = 0 ; 
    var total = $("#invoiceTotal");

    var discount = $("#inputInvoiceDiscount").val();
    var vat = $("#inputInvoiceVat").val();

    var services_total = parseFloat($('#inputServicesTotal').val());
    var stock_total = parseFloat($('#inputStockTotal').val());

    var total_combined = calculate_total(services = services_total, stock = stock_total, discount = discount, vat = vat);
    $('#inputInvoiceTotal').val(total_combined);
    total.html('Total: €' + total_combined);
}); 

$('#inputInvoiceDiscount').change(()=>{

    var total_combined = 0 ; 
    var total = $("#invoiceTotal");

    var discount = $("#inputInvoiceDiscount").val();
    var vat = $("#inputInvoiceVat").val();

    var services_total = parseFloat($('#inputServicesTotal').val());
    var stock_total = parseFloat($('#inputStockTotal').val());

    var total_combined = calculate_total(services = services_total, stock = stock_total, discount = discount, vat = vat);
    $('#inputInvoiceTotal').val(total_combined);
    total.html('Total: €' + total_combined);
});

var customer_select = new TomSelect("#select-customer",{
    persist: true,
    createOnBlur: true,
    create: false,
    searchField: 'title',
});