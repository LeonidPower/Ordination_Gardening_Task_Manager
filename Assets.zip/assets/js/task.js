var tasks_table = $('#tasks-table').DataTable();
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
  return new bootstrap.Popover(popoverTriggerEl)
})

const table = document.getElementById("tasks-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_task_btn').removeAttr('disabled');
            $('#delete_task_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_task_btn').prop('disabled');
            $('#edit_task_btn').prop('disabled')
        }

    })
});

$('#edit_task_btn').click(function(){
    if (checkedRow) {
        const row = $(checkedRow);
        const Id = row.attr('data-t_id');
        const t_name = row.attr('data-t_name');
        const t_description = row.attr('data-t_description');
        const t_status = row.attr('data-t_status');
        const t_start_date = row.attr('data-t_s_d');
        const t_end_date = row.attr('data-t_e_d');
        const t_project = row.attr('data-t_project');

        $("#inputID_edit").val(Id);
        $("#inputTaskName").val(t_name);
        $("#inputDescription").val(t_description);
        $("#inputTaskStartDate").val(t_start_date);
        $("#inputTaskEndDate").val(t_end_date);
        
        project_select.setValue(t_project);

        if(t_status == 1){ 
            $("#inputStatus").prop('checked' ,true);

        }else{ 
            $("#inputStatus").prop('checked' ,false);
        }  

        var assignees_array = assignees.get(Id);
        console.log(assignees_array);


        $("#select-assignees").children('option').each(function(){ 
            if(assignees_array.includes($(this).val())){
                $(this).attr("selected" , true);
            }
            else{ 
                $(this).attr("selected" , false);
            }
        }); 
    }
});

$('#delete_task_btn').click(()=>{ 
    const row = $(checkedRow);
    const Id = row.attr('data-t_id');
    $("#inputID_del").val(Id);
    
});

var project_select = new TomSelect('#select-project-edit',{
    create: false,
    allowEmptyOption: false,
    sortField: {
        field: 'text',
        direction: 'asc'
    }
});

$('#filter_by_status_active').on('click', function() {
    var radioValue = $("input[name='filter_status_active']:checked").val();
    if(radioValue){
        $('#filter_by_status_finished').prop('disabled', true);
        tasks_table.columns( 6 )
        .search('1')
        .draw();
    }else{
        $('#filter_by_status_finished').prop('disabled', false);
        tasks_table.columns( 6 )
        .search('')
        .draw();
    }
});

$('#filter_by_status_finished').on('click', function() {
    var radioValue = $("input[name='filter_status_finished']:checked").val();
    if(radioValue){
        $('#filter_by_status_active').prop('disabled', true);
        tasks_table.columns( 6 )
        .search('0')
        .draw();
    }else{
        $('#filter_by_status_active').prop('disabled', false);
        tasks_table.columns( 6 )
        .search('')
        .draw();
    }
}); 



$('#select-project-edit').on('change', function() {
    project_start_date = project_dates.get(parseInt($(this).val()))[0];
    project_end_date = project_dates.get(parseInt($(this).val()))[1];
});

var start_date = flatpickr("#inputTaskStartDate", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    time_24hr: true,
});
var end_date = flatpickr("#inputTaskEndDate", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    time_24hr: true,
});
$("#inputTaskStartDate").css("background-color", "white");
$("#inputTaskEndDate").css("background-color", "white");

$("#inputTaskStartDate").on("change", function() {
	if (project_start_date == null) {
		start_date.close();
		start_date.setDate("");
		$("#project-not-selected").modal("show");
		start_date.setDate("");
		$("#inputTaskStartDate").addClass("is-invalid");
    }
	else{ 
		if(!($(this).val() >= project_start_date && $(this).val() <= project_end_date)){
			$("#project-date-after").modal("show");
			start_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
		if($('#inputTaskEndDate').val() != "" && !($(this).val() <= $('#inputTaskEndDate').val())){ 
			$("#task-start-date-after-end-date").modal("show");
			start_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
	}
});

$("#inputTaskEndDate").on("change", function() {
    if (project_end_date == null) {
		end_date.close();
		end_date.setDate("");
		$("#project-not-selected").modal("show");
		$("#inputTaskEndDate").addClass("is-invalid");
    }
	else{ 
		if(!($(this).val() >= project_start_date && $(this).val() <= project_end_date)){
			$("#project-date-before").modal("show");
			end_date.setDate("");
			$("#inputTaskEndDate").addClass("is-invalid");
		}
		if($('#inputTaskStartDate').val() != "" && !($(this).val() >= $('#inputTaskStartDate').val())){ 
			$("#task-end-date-before-start-date").modal("show");
			end_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
	}
});
