<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    if (isset($_POST['customer']) && isset($_POST['supervisor']) && isset($_POST['project-name']) && isset($_POST['project-start-date']) && isset($_POST['project-end-date']))
    {
        $customer_hash = validate($_POST['customer']);
        $project_name = validate($_POST['project-name']);
        $project_start_date = validate($_POST['project-start-date']);
        $project_end_date = validate($_POST['project-end-date']);


        $supervisor  = $_POST['supervisor'];

        $project_address = isset($_POST['address']) ? validate($_POST['address']) : "";
        $project_city = isset($_POST['city']) ? validate($_POST['city']) : "";
        $project_address_num = isset($_POST['number']) ? validate($_POST['number']) : "";
        $project_postal =isset($_POST['post-code']) ? validate($_POST['post-code']) : "0000-00-00";
        $project_description =isset($_POST['description']) ? validate($_POST['description']) : "";

        $i = 0 ;
        $supervisors_id_array = array();
        $supervisors_array = array();
    }
    else
    {
        include 'project_form_intermediate.php';
        exit();
    }
    

    if(empty($customer_hash)){ 
        header("Location: project_form_intermediate.php?error=Customer cannot be empty");
        exit();
    }
    else if(empty($project_name)){ 
        header("Location: project_form_intermediate.php?error=Project name cannot be empty");
        exit();
    }
    else if(empty($project_start_date)){ 
        header("Location: project_form_intermediate.php?error=Project start date cannot be empty");
        exit();
    }
    else if(empty($project_end_date)){ 
        header("Location: project_form_intermediate.php?error=Project end date cannot be empty");
        exit();
    }
    else if(empty($supervisor)){ 
        header("Location: project_form_intermediate.php?error=Supervisor cannot be empty");
        exit();
    }
    else{ 
        while(!empty($supervisor[$i])){
            array_push($supervisors_array , validate($supervisor[$i]));
            $i++;
        }

        $supervisors_array_new = implode("','",$supervisors_array);
        $sql_find_customer = "SELECT customer_id FROM customer WHERE hash = ? LIMIT 1;";
        $stmt = $conn->prepare($sql_find_customer);
        $stmt->bind_param("s", $customer_hash);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $customer_id = $row['customer_id'];
        } else {
            header("Location: project_form_intermediate.php?error=Customer couldn't be found");
            exit();
        }
        
        
        // // //We need to also check if the users position is set to be project manager!!!
        $sql_find_supervisors = "SELECT name, surname, user_id FROM user WHERE hash IN ('" . $supervisors_array_new . "') ;";
        $result = mysqli_query($conn, $sql_find_supervisors);
        if (mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result))
            {
                array_push($supervisors_id_array, $row['user_id']);
            }
        } else {
            header("Location: project_form_intermediate.php?error=Supervisor doesn't exist");
            exit();
        }

        // Create new project
        $sql_insert_new_project = "INSERT INTO project (name, address, number, city, post_code, start_date, end_date, description, customer_id, status)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0);";
        $stmt = $conn->prepare($sql_insert_new_project);
        $stmt->bind_param("ssssssssi", $project_name, $project_address, $project_address_num, $project_city, $project_postal, $project_start_date, $project_end_date, $project_description, $customer_id);
        $stmt->execute();
        $new_project_id = $stmt->insert_id;

        // Add supervisors for the project
        $sql_insert_supervisors = "INSERT INTO project_supervisors (project_id, user_id) VALUES (?, ?);";
        $stmt = $conn->prepare($sql_insert_supervisors);
        $stmt->bind_param("ii", $new_project_id, $s_id);

        foreach ($supervisors_id_array as $s_id) {
            $stmt->execute();
        }

        header("Location: project.php?success=Project created successfully");
        exit();

            }
?>