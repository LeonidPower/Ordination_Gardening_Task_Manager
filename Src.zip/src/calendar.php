<?php
    require 'check_login.php';
    require_once '../commons/calendar.php';
    exit();
?>