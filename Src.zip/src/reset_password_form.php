<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Reset Password - Ordinatio Admin</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="row justify-content-center">
                            <img src="../assets/img/logo.png" alt="Logo of the company"
                                style="width: 250px; height: 100px;">
                        </div>
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Reset Password</h3>
                                </div>
                                <div class="card-body">
                                    <div class="wrapper-main">
                                        <div class="wrapper-main">
                                            <section class="section-default">                   
                                                <?php
                                                    $selector = $_GET["selector"];
                                                    $validator = $_GET["validator"];
                                                    
                                                    if (empty($selector) || empty($validator)) {
                                                        echo "Could not validate your request!";
                                                    } else{
                                                        if(ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false){
                                                        echo '
                                                            <form action="../src/reset_password_include.php" method="post">
                                                                <input type ="hidden" name ="selector" value ="<?php echo  $selector ;?>  ">
                                                                <input type ="hidden" name ="validator" value ="<?php echo  $validator ;?>  ">
                                                                <input class="form-control mb-2"type ="password" name ="pwd" placeholder ="Enter a new password..">
                                                                <input class="form-control mb-2" type ="password" name ="pwd-repeat" placeholder ="Repeat new password..">
                                                                <button class="btn btn-primary float-end" type ="submit" name ="reset-password-submit">Reset password</button>
                                                            </form>';
                                                        }
                                                    }
                                                ?>
                                            </section>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>


