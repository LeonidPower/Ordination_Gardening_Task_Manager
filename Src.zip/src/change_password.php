<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['old_pass']) && isset($_POST['new_pass']) && isset($_POST['pass_confirm'])){   
        
        $old_password = md5(validate($_POST['old_pass']));
        $new_password = md5(validate($_POST['new_pass']));
        $confirm_password = md5(validate($_POST['pass_confirm']));
        $hash = validate($_SESSION['user_hash']);
    }
    else{
        include "../admin/user_settings.php";
        exit();
    }

    if(empty($old_password)){ 
      header("Location: user_settings.php?error=Old Password is empty");
      exit();
    }
    elseif(empty($new_password)){ 
        header("Location: user_settings.php?error=New Password is empty");
        exit();
    }
    elseif(empty($confirm_password)){ 
        header("Location: user_settings.php?error=Confirm Password is empty");
        exit();
    }
    else{
        echo $old_password;
        echo $_SESSION['password'];
        if($old_password === $_SESSION['password']){
            if($new_password === $confirm_password){ 
                $sql = "UPDATE user 
                SET password = ?
                WHERE hash = ?;";
                $stmt = $conn->prepare($sql);
                
                $stmt->bind_param("ss", $new_password, $hash);
                $stmt->execute();
                
                header("Location: user_settings.php?success=Password changed");
            }
            else{ 
                header("Location: user_settings.php?error=Passwords do not match");
                exit();
            }
        }  
        else{ 
            header("Location: user_settings.php?error=Old Password is incorrect");
            exit();
        }
    }
?>