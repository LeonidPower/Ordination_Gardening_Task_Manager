<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';


    $requiredFields = ['id_del'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $id = validate($_POST['id_del']);
    }
    else{
        include "../admin/invoice.php";
        exit();
    }

    if(empty($id)){
        header("Location: invoice.php?error=Invoice was not found");
        exit();
    }else{
        $sql= "DELETE FROM invoice WHERE invoice_id=?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $hash);
        $stmt->execute();

        header("Location: customer.php?success=Invoice deleted");
    }
    $conn->close();
?>