<?php
    require "db_connect.php";
    require "objects.php";

    $query = "SELECT customer.hash AS hash, customer.name AS c_name, customer.surname AS c_surname, customer.address AS c_add, invoice.total_price,
        invoice.invoice_id, invoice.name, invoice.date, invoice.status, invoice.vat, invoice.valid_for, invoice.discount
        FROM invoice
        JOIN customer ON customer.customer_id = invoice.customer_id;";
    
    $result = mysqli_query($conn, $query);
    $invoices = array();

    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)){

            $invoice_id = $row['invoice_id'];

            $invoice = new Objects\Invoice($row['invoice_id'], $row['name'], $row['status'], $row['date'], $row['total_price'], $row['vat'], $row['discount'], $row['valid_for'], $row['hash']);
            $invoice->get_customer_name($row['c_name'], $row['c_surname']);
            $invoice->get_customer_address($row['c_add']);
            array_push($invoices, $invoice);

            $query2 = "SELECT * FROM invoice_services WHERE invoice_id=?;";

            $stmt = $conn->prepare($query2);
            $stmt->bind_param("i", $invoice_id);
            $stmt->execute();
            $result2 = $stmt->get_result();

            if (mysqli_num_rows($result2) > 0) {
                while($row2 = mysqli_fetch_assoc($result2)){

                    $service = new Objects\Service($row2['service_id'], $row2['name'], $row2['description'], $row2['quantity'], $row2['volume'], $row2['price']);
                    $invoice->add_service($service);
                }
            }

            $query3 = "SELECT * FROM invoice_stock WHERE invoice_id=?;";
            
            $stmt = $conn->prepare($query3);
            $stmt->bind_param("i", $invoice_id);
            $stmt->execute();
            $result3 = $stmt->get_result();

            if(mysqli_num_rows($result3) > 0){
                while($row3 = mysqli_fetch_assoc($result3)){

                    $item_id = $row3['stock_item_id'];

                    $query4 = "SELECT * FROM stock WHERE item_id = '$item_id';";
                    $result4 = mysqli_query($conn, $query4);

                    while($row4 = mysqli_fetch_assoc($result4)){

                        $stock = new Objects\Stock($item_id, $row4['name'], $row3['quantity'], $row4['volume'], $row4['width'], $row4['height'], $row4['size'], $row4['price']);
                        $invoice->add_stock($stock);
                    }
                }
            }            
        }
    }
    $invoices_json = json_encode($invoices);
?>