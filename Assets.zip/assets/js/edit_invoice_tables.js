new TomSelect('#select-item',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});

var start_service_total = 0 ; 
var start_stock_total = 0;
var start_total = 0;
$(document).ready(function () {

    var t1 = $('#inputServiceTable').DataTable({
        columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
        lengthChange:false,
        pageLength: 5,
        ordering:false,
        searching: false
    });
 
    t1.on('order.dt search.dt', function () {
        let i = 1;
 
        t1.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();

    var current_invoice = invoice;
    counter = 0;
    current_invoice[0].invoice_services.forEach(function(service) {
        t1.row.add( [
            '<input class="form-control" type="text" value="'+ service.service_name + '" name="service-name[' + counter +']" id="inputServiceName' + counter + '" required/>',
            '<input class="form-control" type="text" value="'+ service.service_description + '" name="service-description[' + counter +']" id="inputServiceDescription' + counter + '"/>',
            '<input class="form-control service-quantity" data-index="'+counter+'" type="number" value="'+ service.service_quantity + '" name="service-quantity[' + counter +']" id="inputServiceQuantity' + counter + '" min="0" value="0" style="width: 67px;"/>',
            '<input class="form-control service-price" data-index="'+counter+'" value="'+ service.service_price + '" type="number" name="service-unit-price[' + counter +']" id="inputServicePrice' + counter + '" " min="0" step="1.0" value="0.00" style="width: 70px;" required/>',
            '<p  class="me-5 h5" name="service-total-price" id="serviceTotal' + counter + '"></p>',
            '<button type="button" class="removeRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ]).draw( false );
        counter++;
    });

    $('#addRow').on( 'click', function () {
        t1.row.add( [
            '<input class="form-control" type="text" name="service-name[' + counter +']" id="inputServiceName' + counter + '" required/>',
            '<input class="form-control" type="text" name="service-description[' + counter +']" id="inputServiceDescription' + counter + '" required/>',
            '<input class="form-control service-quantity" data-index="'+counter+'" type="number" name="service-quantity[' + counter +']" id="inputServiceQuantity' + counter + '" min="0" value="0" style="width: 67px;"/>',
            '<input class="form-control service-price" data-index="'+counter+'" type="number" name="service-unit-price[' + counter +']" id="inputServicePrice' + counter + '" " min="0"  step="1.0" value="0.00" style="width: 70px;" required/>',
            '<p  class="me-5 h5" name="service-total-price" id="serviceTotal' + counter + '"></p>',
            '<button type="button" class="removeRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ]).draw( false );
        counter++;
    });
 
    $('#inputServiceTable tbody').on( 'click', '.removeRow', function () {
        t1.row( $(this).parents('tr')).remove().draw();
    });

    t1.rows().every(function() {
        const data = this.data();
        const row = this.node(); 
        const quantity_service = $(row).find('input[name^="service-quantity"]');
        const unitPrice_service = $(row).find('input[name^="service-unit-price"]');
        start_service_total = $(quantity_service).val() * $(unitPrice_service).val();

        $(row).find('p[name^="service-total-price"]').text(start_service_total.toFixed(2));
    });
    start_total = parseFloat(start_service_total) + parseFloat(start_stock_total);
    $('#combinedTotal').html('Total (€): ' + start_total);
});

$(document).ready(function () {
    var t2 = $('#inputStockTable').DataTable({
        columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
        lengthChange:false,
        pageLength: 5,
        ordering:false,
        searching: false
    });
 
    t2.on('order.dt search.dt', function () {
        let i = 1;
 
        t2.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();
    var current_invoice = invoice;
    counter = 0;
    current_invoice[0].invoice_stock.forEach(function(stock) {
        var itemTotal = parseInt(stock.stock_quantity) * parseFloat(stock.stock_price);
        t2.row.add([
            `<div class="d-flex justify-content-center">
                <button class="btn btn-primary add-item" type="button" value="`+ counter +`" name="item-stock-name[` + counter + `]" id="inputStockItemName` + counter + `" data-bs-toggle="modal" data-bs-target="#stockModal" required>
                    <input type="hidden" value="` + stock.stock_id + `" id="itemId` + counter + `" name="item-stock-id[` + counter + `] required"/>
                    Select item
                </button>
            </div>`,
            '<p  class=" w-auto border text-center mt-2 h5" value='+ stock.stock_name +' name="item-name" id="itemName' + counter + '">'+ stock.stock_name +'</p>',
            '<input class="form-control stock-quantity"  value='+ stock.stock_quantity +' form-control" type="number" data-index="'+counter+'" name="item-stock-quantity[' + counter +']" id="inputStockQuantity' + counter + '" min="0" value="1" style="width: 67px;" required/>',
            '<p  class="text-center h5" value='+ stock.stock_price +' name="item-price" id="itemPrice' + counter + '">'+stock.stock_price+'</p>',
            '<p  class="me-5 h5" name="item-total-price" id="itemTotal' + counter + '">'+itemTotal+'</p>',
            '<button type="button" class="removeStockRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ] ).draw( false );
        counter++;
    });

    var counter = 2;
    $('#addStockRow').on( 'click', function () {
        t2.row.add( [
            `<div class="d-flex justify-content-center">
                <button class="btn btn-primary add-item" type="button" value="`+ counter +`" name="item-stock-name[` + counter + `]" id="inputStockItemName` + counter + `" data-bs-toggle="modal" data-bs-target="#stockModal" required>
                    <input type="hidden" id="itemId` + counter + `" name="item-stock-id[` + counter + `] required"/>
                    Select item
                </button>
            </div>`,
            '<p  class="w-auto border text-center mt-2 h5" name="item-name"  id="itemName' + counter + '"></p>',
            '<input class="form-control stock-quantity" form-control" type="number" data-index="'+counter+'" name="item-stock-quantity[' + counter +']" id="inputStockQuantity' + counter + '" min="0" value="1" style="width: 67px;" required/>',
            '<p  class="text-center h5" name="item-price" id="itemPrice' + counter + '"></p>',
            '<p  class="me-5 h5" name="item-total-price" id="itemTotal' + counter + '"></p>',
            '<button type="button" class="removeStockRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button>'
        ] ).draw( false );
        counter++;
    } );

    start_total = parseFloat(start_service_total) + parseFloat(start_stock_total);
    $('#combinedTotal').html('Total (€): ' + start_total);

    $('#inputStockTable tbody').on( 'click', '.removeStockRow', function () {
        t2.row( $(this).parents('tr')).remove().draw();
    });
});

var total = 0;
var serviceTotal = 0 ;
var stockTotal = 0;
var add_stock = 0;
var total_combined = 0;

$('#combinedTotal').html('Total (€): ' + total_combined);
function calculate_service_total(){ 
    serviceTotal = 0 ;
    $("#inputServiceTable").DataTable().rows().every(function() {
        const data = this.data();
        const row = this.node(); 
        const quantity_service = $(row).find('input[name^="service-quantity"]');
        const unitPrice_service = $(row).find('input[name^="service-unit-price"]');
        serviceTotal = ($(quantity_service).val() * $(unitPrice_service).val()) + serviceTotal;
    });
    return serviceTotal;
}

function calculate_stock_total(){ 
    stockTotal = 0 ;
    $('#inputStockTable').DataTable().rows().every(function() {
        const data = this.data();
        const row = this.node();
        const quantity_stock_val = $(row).find('input[name^="item-stock-quantity"]');
        const unitPrice_stock = $(row).find('p[name^="item-price"]');
        stockTotal = $(quantity_stock_val).val() * parseFloat($(unitPrice_stock).html()) + stockTotal;
    });
    return stockTotal;
}

function calculate_combined_total() {
    total_combined = calculate_stock_total() + calculate_service_total();
    $('#combinedTotal').html('Total (€): ' + total_combined);
    return total_combined;
}

$(document).on('input', '.service-quantity', function () {
    var quantity = $(this).val();
    var index = $(this).attr('data-index');
    serviceTotal = quantity * $('#inputServicePrice'+index).val();
    var total = $("#serviceTotal"+index).val(serviceTotal);
    $(total).html(serviceTotal);
    calculate_combined_total();
});

$(document).on('input', '.service-price', function () {
    var unit_price = $(this).val();
    var index = $(this).attr('data-index');
    serviceTotal = unit_price * $('#inputServiceQuantity'+index).val();
    var total = $("#serviceTotal"+index).val(serviceTotal);
    $(total).html(serviceTotal);
    calculate_combined_total();
});

var index = 0;
$(document).on('click', '.add-item', function () {
    index = $(this).val();
});

$(document).on('input', '.stock-quantity', function () {
    var quantity = $(this).val();
    var index = $(this).attr('data-index');
    itemTotal = quantity * $('#itemPrice'+index).html();
    var total = $("#itemTotal"+index).val(itemTotal);
    $(total).html(itemTotal);
    calculate_combined_total();
});

$('#addItem').on('click', function () {

    var item = $('#select-item').find(":selected");
    var itemID = $(item).val();
    var itemName = $(item).attr('data-i_name');
    var itemPrice = $(item).attr('data-i_price');

    $('#itemId'+index).val(itemID);
    $('#itemName'+index).html(itemName);
    $('#itemPrice'+index).html(itemPrice);
    $('#itemTotal'+index).html(itemPrice);
    index = 0 ;
    calculate_combined_total();
});

$('#updateServices').on('click', function () {
    
    var service = [];
    var services = [];
    $('#inputServiceTable').DataTable().rows().every(function() {
        const row = this.node();
        const service_name = $(row).find('input[name^="service-name"]');
        const service_description = $(row).find('input[name^="service-description"]');
        const service_quantity = $(row).find('input[name^="service-quantity"]');
        const service_price = $(row).find('input[name^="service-unit-price"]');
        service = {'name' : $(service_name).val(), 'description' : $(service_description).val(), 'quantity' : $(service_quantity).val(), 'price' : $(service_price).val()};
        services.push(service);
    });
    data_json = {'invoice_id' : invoice[0].invoice_id , 'services' : services};

    $('#servicesData').val(JSON.stringify(data_json));
});
$('#updateStock').on('click', function () {

    var item_data = [];
    var stock = [];
    $('#inputStockTable').DataTable().rows().every(function() {
        const row = this.node();
        const item_id = $(row).find('input[name^="item-stock-id"]');
        const quantity_stock_val = $(row).find('input[name^="item-stock-quantity"]');
        item_data = {'item_id' : $(item_id).val(), 'quantity' : $(quantity_stock_val).val()};
        stock.push(item_data);
    });
    data_json = {'invoice_id' : invoice[0].invoice_id , 'stock' : stock};
    $('#stockData').val(JSON.stringify(data_json));
});
