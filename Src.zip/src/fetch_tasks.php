<?php
require "db_connect.php";
require_once "objects.php";

$query_get_tasks = "SELECT task.task_id AS t_id, task.name AS t_name, task.start_date_time AS t_s_date_time, task.end_date_time AS t_e_date_time,
                        task.status AS t_status, task.description AS t_desc, task.project_id AS p_id, project.name AS p_name, project.start_date AS p_s_d, project.end_date AS p_e_d
                        FROM task
                        JOIN project ON project.project_id = task.project_id;";

$result = mysqli_query($conn, $query_get_tasks);

$tasks = array();
$task_obj = null;

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)){
        //Make tasks object
        
        $task_obj = new Objects\Task ($row['t_id'], $row['t_name'], $row['t_s_date_time'], $row['t_e_date_time'], 
                            $row['t_desc'], $row['t_status'], $row['p_id'], $row['p_name']);         
        $task_id = $row['t_id'];
        
        $query_get_task_assignees = "SELECT user.hash as u_hash FROM task_assignees 
                                    JOIN user ON user.user_id = task_assignees.assignee_id
                                    WHERE task_id='$task_id';";

        $result_get_assignees = mysqli_query($conn, $query_get_task_assignees);

        while ($row_usr = mysqli_fetch_assoc($result_get_assignees)){
            $task_obj->add_assignee($row_usr['u_hash']);
        }
        array_push($tasks, $task_obj);
    }
}

?>