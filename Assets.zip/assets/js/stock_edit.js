const MAX_LENGTH = 24; // Maximum length before adding ellipsis

const textContainer = $('#item-name-text');
const text = textContainer.text();

if (text.length > MAX_LENGTH) {
  textContainer.text(text.substring(0, MAX_LENGTH) + '...');
}



$('.stock-item').click(function(){
    const Id = $(this).attr('data-i_id');
    const i_name = $(this).attr('data-i_name');
    const i_quantity = $(this).attr('data-i_quantity');
    const i_volume = $(this).attr('data-i_volume');
    const i_width = $(this).attr('data-i_width');
    const i_height = $(this).attr('data-i_height');
    const i_size = $(this).attr('data-i_size');
    const i_price = $(this).attr('data-i_price');
    const i_image = $(this).attr('data-i_image');

    $("#inputID_edit").val(Id);
    $("#inputProductName_edit").val(i_name);
    $("#inputQuantity_edit").val(i_quantity);
    $("#inputVolume_edit").val(i_volume);
    $("#inputWidth_edit").val(i_width);
    $("#inputHeight_edit").val(i_height);
    $("#inputSize_edit").val(i_size);
    $("#inputPrice_edit").val(i_price);
    $("#inputImage_edit_path").val(i_image);
});

$('#delete_item_btn').click(()=>{
    $("#inputID_delete").val($("#inputID_edit").val());
});

$('#inputHeight_edit').on('change', function() {
    if($(this).val() != '' && $('#inputWidth_edit') != '' && $('#inputSize_edit') != ''){
        $(this).prop('required', true);
        $('#inputWidth_edit').prop('required', true);
        $('#inputSize_edit').prop('required', true);
    }else if(!$(this).val() && !$('#inputWidth_edit').val() && !$('#inputSize_edit').val()){
        $(this).removeAttr('required');
        $('#inputWidth_edit').removeAttr('required');
        $('#inputSize_edit').removeAttr('required');
    } 
});

$('#inputWidth_edit').on('change', function() {
    if($(this).val() != '' && $('#inputHeight_edit') != '' && $('#inputSize_edit') != ''){
        $(this).prop('required', true);
        $('#inputHeight_edit').prop('required', true);
        $('#inputSize_edit').prop('required', true);
    }else if(!$(this).val() && !$('#inputHeight_edit').val() && !$('#inputSize_edit').val()){
        $(this).removeAttr('required');
        $('#inputHeight_edit').removeAttr('required');
        $('#inputSize_edit').removeAttr('required');
    } 
});

$('#inputSize_edit').on('change', function() {
    if($(this).val() != '' && $('#inputHeight_edit') != '' && $('#inputWidth_edit') != ''){
        $(this).prop('required', true);
        $('#inputHeight_edit').prop('required', true);
        $('#inputWidth_edit').prop('required', true);
    }else if(!$(this).val() && !$('#inputHeight_edit').val() && !$('#inputWidth_edit').val()){
        $(this).removeAttr('required');
        $('#inputHeight_edit').removeAttr('required');
        $('#inputWidth_edit').removeAttr('required');
    } 
});