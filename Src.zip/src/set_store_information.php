<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    if (isset($_POST['store_address']) && isset($_POST['store_payble_to']))
    {
        $store_address = validate($_POST['store_address']);
        $store_payble_to = validate($_POST['store_payble_to']);
        $city = isset($_POST['store_city']) ? validate($_POST['store_city']) : '';
        $zip = isset($_POST['store_zip']) ? validate($_POST['store_zip']) : '';

    }else{ 
        include  "../commons/manage_system.php";
        exit();
    }

    if (empty($store_address)) {
        header("Location: manage_system.php?error=Store address is required");
        exit();
    }elseif (empty($store_payble_to)){
        header("Location: manage_system.php?error=Store payble to is required");
        exit();
    }
    else{ 
        $sql = "SELECT * FROM settings";
        $result = mysqli_query($conn, $sql);
        if($result && mysqli_num_rows($result) > 0){
            echo mysqli_num_rows($result);
            $sql = "DELETE FROM settings";
            mysqli_query($conn, $sql);
        }
        
        $sql = $conn->prepare ("INSERT INTO settings (address, city, zip, payableto)  VALUES (?, ?, ?, ?);");
        $sql->bind_param("ssss", $store_address, $city, $zip, $store_payble_to);
        $sql->execute();

        $sql->close();
        $conn->close();
        header("Location: manage_system.php?success=Store information updated");
    }

?>