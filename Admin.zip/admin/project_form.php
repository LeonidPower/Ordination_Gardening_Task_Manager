<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Create Project - Ordinatio Manager</title>
        <link href="../assets/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
    </head>
    <link rel="icon" type="image/png" href="../assets/img/title.svg">
    <body class="bg-primary">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                        <a href="../src/project.php"><i class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                                        <p class="text-center font-weight-light display-5 d-block">Create Project</p>
                                        <div class="text-center me-1 mt-1">
                                            <img class="float-end" src="../assets/img/ordinatio_manager.svg" alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <form id="quote_form" method="POST" action="project_form.php">
                                            <?php 
                                                if (isset($_GET['error'])){
                                                echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                                                    <button class="close-btn mb-1">&times;</button>
                                                </div>';
                                                }
                                                elseif (isset($_GET['success'])){
                                                    echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                                        <button class="close-btn mb-1">&times;</button>
                                                    </div>';
                                                }
                                            ?>
                                            <p class="">Select Customer<span class="required-field"> *</span></p>
                                            <div id="select-customer">
                                                <div class="form-floating mb-3 mbmd-0">                 
                                                    <?php
                                                    require_once '../src/db_connect.php';
                                                    require_once '../src/objects.php';
                                                    
                                                    $sql_customer = "SELECT customer_id, name, surname, email, phone, address, hash FROM customer;";
                                                    $stmt = $conn->prepare($sql_customer);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();
                                                    $customer_info = array();
                                                    $i = 0;
                                                    
                                                    if ($result->num_rows > 0) {
                                                        echo '<select style="width:48%;" id="select-customer-data" name="customer" autocomplete="off" placeholder="Select Customer" required>
                                                                <option value="" selected disabled>Select Customer<span class="required-field"> *</span></option>';
                                                    
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<option value="' . $row['hash'] . '" name="hash' .  '">' . $row['name'] . ' ' . $row['surname'] . '</option>';
                                                            $i++;
                                                        }
                                                        echo '</select>';
                                                    }
                                                    
                                                ?>
                                                </div>
                                            </div>
                                            <div id="project">
                                                <div class="row mb-3">
                                                    <div class="col-md-6">
                                                        <div class="form-floating mb-3 mb-md-0">
                                                            <input class="form-control" name="project-name" id="inputProjectName" type="text" required/>
                                                            <label for="inputProjectName">Project Name<span class="required-field"> *</span></label>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>Project Supervisor<span class="required-field"> *</span></p>
                                                            <div class="form-floating mb-3 mbmd-0">
                                                                <?php
                                                                require_once '../src/db_connect.php';
                                                                require_once '../src/objects.php';
    
                                                                $sql_user = "SELECT user.name AS u_name, user.surname AS u_surname, user.email AS u_email, 
                                                                user.phone AS u_phone, user.address AS u_add, user.hash AS u_hash, project_manager as p_m
                                                                FROM user
                                                                JOIN position ON position.position_id = user.position_id_users;";
                                                                
                                            $stmt = $conn->prepare($sql_user);
                                            $stmt->execute();
                                            $result = $stmt->get_result();
                                            
                                            if ($result->num_rows > 0) {
                                                echo '<select style="width:200%" class="form-control h-100" id="select-supervisor" name="supervisor[]" multiple autocomplete="off" placeholder="Select Supervisor/s" multiple required>
                                                        <option value="" selected disabled>Select Supervisor/s</option>';
                                            
                                                while ($row = $result->fetch_assoc()) {
                                                    if ($row['p_m']) {
                                                        echo '<option value="' . $row['u_hash'] . '" name="hash' .  '">' . $row['u_name'] .' '. $row['u_surname'] . '</option>';
                                                        $i++;
                                                    }
                                                }
                                                echo '</select>';
                                            }   
                                             
                                                            ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                        <label for="inputAddress">Address</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="city" id="inputCity" type="text" placeholder="City"/>
                                                        <label for="inputCity">City</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 w-25">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="number" id="inputNumber" type="text" placeholder="Num"/>
                                                        <label for="inputNumber">Num</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 w-25">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="post-code" id="inputPost" type="text" placeholder="Post Code"/>
                                                        <label for="inputPost">Post Code</label>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-2">
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="project-start-date" id="inputProjectStartDate" type="date" placeholder="Date" required>
                                                        <label for="inputProjectStartDate">Start Date <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="project-end-date" id="inputProjectEndDate" type="date" placeholder="Date" required>
                                                        <label for="inputProjectEndDate">End Date<span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="form-group mb-3">
                                                    <textarea class="form-control" name="description" id="inputDescription" placeholder="Description" rows="7"></textarea>
                                                </div>
                                            </div>
                                            <div class="mt-4 mb-0">
                                                <button class="btn btn-primary btn-block w-15" type="submit" id="create_quote_button" >Create Project</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include '../commons/date_error_modals.html'; ?>
                </main>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>


        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

        <script src="../assets/js/project_form.js"></script>
        <script src="../assets/js/validate-form-project.js"></script>
    </body>
</html>