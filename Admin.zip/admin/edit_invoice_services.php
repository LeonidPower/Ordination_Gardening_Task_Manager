<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Create Invoice - Ordinatio Manager</title>
        <link href="../assets/css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <link href="../assets/css/edit_invoice_tables.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
        <link rel="icon" type="image/png" href="../assets/img/title.svg">
    </head>
    <body class="bg-primary background-style">
        <div class="container card" style=" margin-top: 3rem; padding: 2rem;">
            <div class="row justify-content-center">
                <a href="invoice.php"><i class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>            
                <script>
                    var invoice = '<?php echo $invoice_json; ?>';
                    invoice = JSON.parse(invoice);
                </script>
                <form method="POST" action="update_invoice_services.php" novalidate>
                    <?php 
                        if (isset($_GET['error'])){
                        echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';
                        }
                        elseif (isset($_GET['success'])){
                            echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                <button class="close-btn mb-1">&times;</button>
                            </div>';
                        }
                    ?>
                    <h2 class="text-center">Services</h2>
                    <i class="bi bi-plus-square-fill fa-2xl md-3" id="addRow" type="button" style="float:right; margin-bottom: 1rem;"></i>
                    <table name="service-table" id="inputServiceTable" class="display border table-bg" style="width:100%">
                        <thead>
                            <tr>
                                <th class="w-25">Service Name</th>
                                <th class="w-25">Description</th>
                                <th class="w-25">Quantity</th>
                                <th class="w-25">Unit Price (<i>€</i>)</th>
                                <th class="w-25">Total (<i>€</i>)</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <input type="hidden" id="servicesData" name="services_data">
                    <button id="updateServices" class="btn btn-primary" data-bs-dismiss="modal">Update Services</button>
                </form>
                <form method="POST" action="update_invoice_stock.php" novalidate>
                    <br>
                    <h2 class="text-center">Stock</h2>
                    <i id="addStockRow" class="bi bi-plus-square-fill fa-2xl md-3" type="button" style="float:right; margin-bottom: 1rem;"></i>
                    <table name="stock-table" id="inputStockTable" class="display border table-bg" style="width:100%">
                        <thead>
                            <tr>
                                <th class="w-25"></th>
                                <th class="w-25 text-center">Item Name</th>
                                <th class="">Quantity</th>
                                <th class="w-25 text-center">Price (<i>€</i>)</th>
                                <th class="w-25">Total (<i>€</i>)</th>
                                <th class="w-100"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <input type="hidden" id="stockData" name="stock_data">
                    <button id="updateStock" type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Stock</button>
                    <div class="modal fade" id="stockModal" tabindex="-1" aria-labelledby="stockModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="stockModalLabel">Select Stock</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            <?php
                                require '../src/db_connect.php';
                                
                                $sql = "SELECT item_id, name, price FROM stock;";
                                $result = mysqli_query($conn, $sql);

                                echo '<select class="form-control" id="select-item" name="product" autocomplete="off" placeholder="Product" required>
                                            <option disabled selected value></option>';

                                if (mysqli_num_rows($result) > 0) {
                                        while($row = mysqli_fetch_assoc($result)){

                                                    $item_id = $row['item_id'];
                                                    $item_name = $row['name'];
                                                    $item_price = $row['price']; 
                                                    
                                                    echo "<option data-i_name='$item_name' data-i_price='$item_price' value='$item_id'>" . $item_name . "</option>";
                                                }

                                    echo '</select>';      
                                }
                                
                                $conn->close();
                            ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button id="addItem" type="button" class="btn btn-primary" data-bs-dismiss="modal">Add item</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="row-md-2">
                <div class="d-flex justify-content-end me-5">
                    <p class="me-5 h4" id="combinedTotal">Total (<i>€</i>): </p>
                </div>
            </div>
        </div>
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="../assets/datatables/datatables.js"></script>
        <script src="../assets/js/edit_invoice_tables.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    </body>
</html>
