$('#inputProductName_edit').on('input', function() {
    if ($(this).val().length > 20) {
        $(this).val($(this).val().slice(0, 20)); // Truncate input to 10 characters
    }
})

$('#inputHeight_edit').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputWidth_edit').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputSize_edit').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputQuantity_edit').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /^\d+$/;
    if (!numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\D/g, '')); // Remove non-digit characters
    }
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})

$('#inputVolume_edit').on('input', function() {
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})

$('#inputPrice_edit').on('input', function() {
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})


