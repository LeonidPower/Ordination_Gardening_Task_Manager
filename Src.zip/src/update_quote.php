<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    $requiredFields = ['quote-id', 'quote-name', 'quote-date', 'quote-vat', 'customer', 'quote-total'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $quote_id    =   validate($_POST['quote-id']);
        $q_name      =   validate($_POST['quote-name']);
        $q_date      =   validate($_POST['quote-date']);
        $q_vat       =   validate($_POST['quote-vat']);
        $q_customer  =   validate($_POST['customer']);
        $q_total     =   validate($_POST['quote-total']);
        
        $q_valid_for =   validate($_POST['quote-valid-for']);

        $q_status    =   empty($_POST['quote-status']) ? 1 : 0;
        $q_discount  =   validate($_POST['quote-discount']);
    }
    else {
        include "../admin/quote.php";
        exit();
    }
    
    $errorMessages = [];

    if(empty($quote_id)) {
        $errorMessages[] = "Quote ID";
    }
    
    if (empty($q_name)) {
        $errorMessages[] = "Name";
    }
    
    if(empty($q_date)) {
        $errorMessages[] = "Date";
    }
    
    if(empty($q_vat)) {
        $errorMessages[] = "VAT";
    }
    
    if(empty($q_customer)) {
        $errorMessages[] = "Customer";
    }

    if(empty($q_total)) {
        $errorMessages[] = "Total";
    }

    if (!empty($errorMessages)) {
        echo "here";
        $errorMessage = implode(", ", $errorMessages) . " is empty";
        header("Location: ../src/quote.php?error=$errorMessage");
        exit();
    }else{

        $sql_get_customer_id = "SELECT customer_id FROM customer WHERE hash=?;";

        $stmt = $conn->prepare($sql_get_customer_id);
        $stmt->bind_param("s", $q_customer);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        $row = mysqli_fetch_assoc($result);

        $q_customer = $row['customer_id'];

        $sql_update_quote = "UPDATE
                                quote
                            SET
                                customer_id = ?,
                                NAME = ?,
                                status = ?,
                                date = ?,
                                total_price = ?,
                                vat = ?,
                                discount = ?,
                                valid_for = ?
                            WHERE
                                quote_id = ?;";

        $stmt = $conn->prepare($sql_update_quote);
        $stmt->bind_param("isissddsi", $q_customer, $q_name, $q_status, $q_date, $q_total, $q_vat, $q_discount, $q_valid_for, $quote_id);
        $stmt->execute();

        header("Location: quote.php?success=Quote updated successfully");
        
    }    
?>
