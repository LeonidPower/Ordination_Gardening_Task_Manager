$("#inputAddress").val(address);
$("#inputCity").val(city);
$('#inputZip').val(zip);
$('#inputPaybleTo').val(payble_to);


  $('#AdminUser').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewProjectsRange').val(2).prop('disabled', true);
        $('#ViewProjectsRangeHidden').val(2);

        $('#CreateTasksRange').val(2).prop('disabled', true);
        $('#CreateTasksRangeHidden').val(2);

        $('#ViewTasksRange').val(2).prop('disabled', true);
        $('#ViewTasksRangeHidden').val(2);

        $('#CreateProjects').prop('checked', true);
        $('#CreateProjects').prop('disabled', true);
        $('#CreateProjectsHidden').val(1);

        $('#CreateUsers').prop('checked', true);
        $('#CreateUsers').prop('disabled', true);
        $('#CreateUsersHidden').val(1);

        $('#CreateInvoices').prop('checked', true);
        $('#CreateInvoices').prop('disabled', true);
        $('#CreateInvoicesHidden').val(1);

        $('#CreateQuotes').prop('checked', true);
        $('#CreateQuotes').prop('disabled', true);
        $('#CreateQuotesHidden').val(1);

        $('#CreateCustomers').prop('checked', true);
        $('#CreateCustomers').prop('disabled', true);
        $('#CreateCustomersHidden').val(1);

        $('#CreateStock').prop('checked', true);
        $('#CreateStock').prop('disabled', true);
        $('#CreateStockHidden').val(1);
        
        $('#ViewUsers').prop('checked', true);
        $('#ViewUsers').prop('disabled', true);
        $('#ViewUsersHidden').val(1);

        $('#ViewInvoices').prop('checked', true);
        $('#ViewInvoices').prop('disabled', true);
        $('#ViewInvoicesHidden').val(1);

        $('#ViewQuotes').prop('checked', true);
        $('#ViewQuotes').prop('disabled', true);
        $('#ViewQuotesHidden').val(1);

        $('#ViewCustomers').prop('checked', true);
        $('#ViewCustomers').prop('disabled', true);
        $('#ViewCustomersHidden').val(1);

        $('#ViewStock').prop('checked', true);
        $('#ViewStock').prop('disabled', true);
        $('#ViewStockHidden').val(1);
   
    } else {
        $('#ViewProjectsRange').val(0).prop('disabled', false);
        $('#ViewProjectsRangeHidden').val(0);

        $('#CreateTasksRange').val(0).prop('disabled', false);
        $('#CreateTasksRangeHidden').val(0);
        
        $('#ViewTasksRange').val(0).prop('disabled', false);
        $('#ViewTasksRangeHidden').val(0);

        $('#CreateProjects').prop('checked', false);
        $('#CreateProjects').prop('disabled', false);
        $('#CreateProjectsHidden').val(0);

        $('#CreateUsers').prop('checked', false);
        $('#CreateUsers').prop('disabled', false);
        $('#CreateUsersHidden').val(0);

        $('#CreateInvoices').prop('checked', false);
        $('#CreateInvoices').prop('disabled', false);
        $('#CreateInvoicesHidden').val(0);

        $('#CreateQuotes').prop('checked', false);
        $('#CreateQuotes').prop('disabled', false);
        $('#CreateQuotesHidden').val(0);

        $('#CreateCustomers').prop('checked', false);
        $('#CreateCustomers').prop('disabled', false);
        $('#CreateCustomersHidden').val(0);

        $('#CreateStock').prop('checked', false);
        $('#CreateStock').prop('disabled', false);
        $('#CreateStockHidden').val(0);

        $('#ViewUsers').prop('checked', false);
        $('#ViewUsers').prop('disabled', false);
        $('#ViewUsersHidden').val(0);

        $('#ViewInvoices').prop('checked', false);
        $('#ViewInvoices').prop('disabled', false);
        $('#ViewInvoicesHidden').val(0);

        $('#ViewQuotes').prop('checked', false);
        $('#ViewQuotes').prop('disabled', false);
        $('#ViewQuotesHidden').val(0);

        $('#ViewCustomers').prop('checked', false);
        $('#ViewCustomers').prop('disabled', false);
        $('#ViewCustomersHidden').val(0);

        $('#ViewStock').prop('checked', false);
        $('#ViewStock').prop('disabled', false);
        $('#ViewStockHidden').val(0);

    }

  } );

$('#CreateUsers').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewUsers').prop('checked', true);
        $('#ViewUsers').prop('disabled', true);
        $('#ViewUsersHidden').val(1);
        $('#CreateUsersHidden').val(1);
    } else {
        $('#ViewUsers').prop('checked', false);
        $('#ViewUsers').prop('disabled', false);
        $('#ViewUsersHidden').val(0);
        $('#CreateUsersHidden').val(0);
    }
    });
$('#CreateInvoices').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewInvoices').prop('checked', true);
        $('#ViewInvoices').prop('disabled', true);
        $('#ViewInvoicesHidden').val(1);
        $('#CreateInvoicesHidden').val(1);
    } else {
        $('#ViewInvoices').prop('checked', false);
        $('#ViewInvoices').prop('disabled', false);
        $('#ViewInvoicesHidden').val(0);
        $('#CreateInvoicesHidden').val(0);
    }
    });
$('#CreateQuotes').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewQuotes').prop('checked', true);
        $('#ViewQuotes').prop('disabled', true);
        $('#ViewQuotesHidden').val(1);
        $('#CreateQuotesHidden').val(1);
    } else {
        $('#ViewQuotes').prop('checked', false);
        $('#ViewQuotes').prop('disabled', false);
        $('#ViewQuotesHidden').val(0);
        $('#CreateQuotesHidden').val(0);
    }
    });
$('#CreateCustomers').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewCustomers').prop('checked', true);
        $('#ViewCustomers').prop('disabled', true);
        $('#ViewCustomersHidden').val(1);
        $('#CreateCustomersHidden').val(1);
    } else {
        $('#ViewCustomers').prop('checked', false);
        $('#ViewCustomers').prop('disabled', false);
        $('#ViewCustomersHidden').val(0);
        $('#CreateCustomersHidden').val(0)
    }
    });
$('#CreateStock').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewStock').prop('checked', true);
        $('#ViewStock').prop('disabled', true);
        $('#ViewStockHidden').val(1);
        $('#CreateStockHidden').val(1);
    } else {
        $('#ViewStock').prop('checked', false);
        $('#ViewStock').prop('disabled', false);
        $('#ViewStockHidden').val(0);
        $('#CreateStockHidden').val(0);
    }
    });

$('#CreateProjects').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewProjectsRange').val(2).prop('disabled', true);
        $('#ViewProjectsRangeHidden').val(2);
        $('#CreateProjectsHidden').val(1);
    } else {
        $('#ViewProjectsRange').val(0).prop('disabled', false);
        $('#ViewProjectsRangeHidden').val(0);
        $('#CreateProjectsHidden').val(0);
    }
});

$('#CreateTasksRange').on('change', function() {
    if ($(this).val() == 2) {
        $('#ViewTasksRange').val(2).prop('disabled', true);
        $('#ViewTasksRangeHidden').val(2);
        $('#CreateTasksRangeHidden').val(2);
    } else if ($(this).val() == 1) {
        $('#ViewTasksRange').val(1).prop('disabled', true);
        $('#ViewTasksRangeHidden').val(1);
        $('#CreateTasksRangeHidden').val(1);
    }
    else {
        $('#ViewTasksRange').val(0).prop('disabled', true);
        $('#ViewTasksRangeHidden').val(0);
        $('#CreateTasksRangeHidden').val(0);
    }
});

$('#ViewProjectsRange').on('change', function() {
    $('#ViewProjectsRangeHidden').val($(this).val());
});

$('#ViewTasksRange').on('change', function() {
    $('#ViewTasksRangeHidden').val($(this).val());
});

$('ViewUsers').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewUsersHidden').val(1);
    }else{
        $('#ViewUsersHidden').val(0);
    }
});

$('#ViewInvoices').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewInvoicesHidden').val(1);
    }else{
        $('#ViewInvoicesHidden').val(0);
    }
});

$('#ViewQuotes').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewQuotesHidden').val(1);
    }else{ 
        $('#ViewQuotesHidden').val(0);
    }
});

$('#ViewCustomers').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewCustomersHidden').val(1);
    }else{
        $('#ViewCustomersHidden').val(0);
    }
});

$('#ViewStock').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewStockHidden').val(1);
    }else{
        $('#ViewStockHidden').val(0);
    }
});

$('#ProjectManager').on('change', function() {
    if ($(this).is(':checked')) {
        $('#ViewProjectsRange').val(2).prop('disabled', true);
        $('#ViewProjectsRangeHidden').val(2);

        $('#CreateTasksRange').val(2).prop('disabled', true);
        $('#CreateTasksRangeHidden').val(2);

        $('#ViewTasksRange').val(2).prop('disabled', true);
        $('#ViewTasksRangeHidden').val(2);

        $('#CreateProjects').prop('checked', true);
        $('#CreateProjects').prop('disabled', true);    
        $('#CreateProjectsHidden').val(1);
  
        
        $('#CreateUsers').prop('checked', true);
        $('#CreateUsers').prop('disabled', true);
        $('#CreateUsersHidden').val(1);

        $('#ViewUsers').prop('checked', true);
        $('#ViewUsers').prop('disabled', true);
        $('#ViewUsersHidden').val(1);

        $('#CreateCustomers').prop('checked', true);
        $('#CreateCustomers').prop('disabled', true);
        $('#CreateCustomersHidden').val(1);

        $('#ViewCustomers').prop('checked', true);
        $('#ViewCustomers').prop('disabled', true);
        $('#ViewCustomersHidden').val(1);

    }
    else {
        $('#ViewProjectsRange').val(0).prop('disabled', false);
        $('#ViewProjectsRangeHidden').val(0);

        $('#ViewTasksRange').val(0).prop('disabled', false);
        $('#ViewTasksRangeHidden').val(0);

        $('#CreateTasksRange').val(0).prop('disabled', false);
        $('#CreateTasksRangeHidden').val(0);

        $('#CreateProjects').prop('checked', false);
        $('#CreateProjects').prop('disabled', false);
        $('#CreateProjectsHidden').val(0);

        $('#CreateUsers').prop('checked', false);
        $('#CreateUsers').prop('disabled', false);
        $('#CreateUsersHidden').val(0);

        $('#CreateCustomers').prop('checked', false);
        $('#CreateCustomers').prop('disabled', false);
        $('#CreateCustomersHidden').val(0);

        $('#ViewUsers').prop('checked', false);
        $('#ViewUsers').prop('disabled', false);
        $('#ViewUsersHidden').val(0);

        $('#ViewCustomers').prop('checked', false);
        $('#ViewCustomers').prop('disabled', false);
        $('#ViewCustomersHidden').val(0);
    }
    });
    
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
  return new bootstrap.Popover(popoverTriggerEl)
})
var popover = new bootstrap.Popover(document.querySelector('.popover-dismiss'), {
    trigger: 'focus'
  })



