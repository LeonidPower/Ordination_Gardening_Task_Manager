<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Create Invoice - Ordinatio Manager</title>
        <link href="../assets/css/styles.css" rel="stylesheet" />
        <link href="../assets/css/invoice_form.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>        
        <link rel="icon" type="image/png" href="../assets/img/title.svg">
        <script src="../assets/js/scripts.js"></script>
    </head>
    <body class="bg-primary background-style">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                        <a href="invoice.php"><i class="mt-1 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                                        <p class="text-center font-weight-light display-5 d-block">Create Invoice</p>
                                        <img class="float-end" src="../assets/img/ordinatio_manager.svg" alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                                    </div>
                                    <div class="card-body">
                                        <form id="invoice_form" method="POST" action="invoice_form.php">
                                            <?php 
                                                if (isset($_GET['error'])){
                                                echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                                                    <button class="close-btn mb-1">&times;</button>
                                                </div>';
                                                }
                                                elseif (isset($_GET['success'])){
                                                    echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                                        <button class="close-btn mb-1">&times;</button>
                                                    </div>';
                                                }
                                            ?>
                                            <div class="row mb-6">
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="invoice-name" id="inputInvoiceName" type="text" placeholder="Title" required>
                                                        <label for="inputInvoiceName">Invoice Name<span class="required-field"> *</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <?php
                                                    require_once '../src/db_connect.php';
                                                    require_once '../src/objects.php';
                                                    $sql = "SELECT address, city, zip, payableto FROM settings";
                                                    $result = mysqli_query($conn, $sql);
                                            
                                            
                                                    $row = mysqli_fetch_assoc($result);
                                                    $c_ordaddress = isset($row['address']) ? $row['address'] : '';
                                                    $c_payableto = isset($row['payableto']) ? $row['payableto'] : '';
                                                    $c_ordcity = isset($row['city']) ? $row['city'] : '';
                                                    $c_ordzip = isset($row['zip']) ? $row['zip'] : '';
                                            
                                                    echo " <script> var ordaddress = '$c_ordaddress';</script> ";
                                                    echo " <script> var payableto = '$c_payableto';</script> ";
                                                    echo " <script> var ordcity = '$c_ordcity';</script> ";
                                                    echo " <script> var ordzip = '$c_ordzip';</script> ";
                                                    ?>
                                            
                                                    <select name="customer-options" id="customer-options" class="form-select mb-3" style="width:100%;" required>    
                                                        <option disabled selected value>Select an option</option>
                                                        <option id="existing" value="Existing Customer">Existing Customer</option>
                                                        <option id="new" value="New Customer">New Customer</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 offset-md-6" id="existing-customer">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <?php
                                                        require_once '../src/db_connect.php';
                                                        require_once '../src/objects.php';
                                                        $sql = "SELECT customer_id, name, surname, email, phone, company, address, hash FROM customer;";
                                                        $result = mysqli_query($conn, $sql);
                                                        $customer_info = array();
                                            
                                                        if (mysqli_num_rows($result) > 0) {
                                                            echo '<select style="width:100%;" id="select-customer" name="customer" autocomplete="off" placeholder="Customer">
                                                                    <option disabled selected value></option>';
                                                            while($row = mysqli_fetch_assoc($result)){
                                            
                                                                $c_name = $row['name'];
                                                                $c_surname = $row['surname'];
                                                                $c_email = $row['email']; 
                                                                $c_phone = $row['phone'];
                                                                $c_company = $row['company'];
                                                                $c_address = $row['address'];
                                                                $c_hash = $row['hash'];
                                                                
                                                                echo "<option data-c_name='$c_name' data-c_surname = '$c_surname' data-c_email = '$c_email' 
                                                                        data-c_phone = '$c_phone' data-c_company = '$c_company' data-c_address = '$c_address'
                                                                        value='$c_hash' >" . $c_name ." ". $c_surname . "</option>";
                                                            }
                                            
                                                            echo '</select>';      
                                                        }  
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>                                       
                                            <div id="new-customer">
                                                <div class="row mb-3">
                                                    <div class="col-md-6">
                                                        <div class="form-floating mb-3 mb-md-0">
                                                            <input class="form-control" name="name" id="inputName" type="text" placeholder="Name" required/>
                                                            <label for="inputFullName">Name<span class="required-field"> *</span></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-floating mb-3 mb-md-0">
                                                            <input class="form-control" name="surname" id="inputSurname" type="text" placeholder="Surname" required/>
                                                            <label for="inputFullName">Surname<span class="required-field"> *</span></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="form-floating">
                                                            <input class="form-control" name="company_name" id="inputCompanyName" type="text" placeholder="Company Name"/>
                                                            <label for="inputCompanyName">Company Name</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="form-floating mb-3 mbmd-0">
                                                            <input class="form-control" name="phone" id="inputPhoneNumber" type="tel" placeholder="Phone Number" required/>
                                                            <label for="inputPhoneNumber">Phone Number<span class="required-field"> *</span></label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" required/>
                                                    <label for="inputEmail">Email Address<span class="required-field"> *</span></label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                    <label for="inputEmail">Address</label>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="invoice-date" id="inputInvoiceDate" type="date" placeholder="Date" required>
                                                        <label for="inputInvoiceName">Date<span class="required-field"> *</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="invoice-valid-for" id="inputIsValidFor" type="number" placeholder="Valid For:" value="14" min="1" max="365" maxlength="3" oninput="this.value = Math.abs(this.value)" required>
                                                        <div class="input-icon input-icon-right">
                                                            <i>days</i>
                                                        </div>
                                                        <label for="inputIsValidFor">Valid For<span class="required-field"> *</span></label>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="col-md-4">
                                                        <div class="form-floating">
                                                            <input type="hidden" name="invoice-total" id="invoice-total">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <i id="addRow" class="bi bi-plus-square-fill fa-2xl mt-3" type="button" style="margin-bottom: 1rem;"></i>
                                                <table name="service-table" id="inputServiceTable" class="display border" style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Item Name</th>
                                                            <th>Description</th>
                                                            <th>Quantity</th>
                                                            <th>Unit Price</th>
                                                            <th>Total</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td><input class="form-control" type="text"  name="service-name[1]" id="inputServiceName1" required/></td>
                                                            <td><input class="form-control" type="text" name="service-description[1]" id="inputServiceDescription1"/></td>
                                                            <td><input class="form-control service-quantity" data-index="1" type="number" name="service-quantity[1]" id="inputServiceQuantity1" min="0" value="0" style="width: 67px;"/></td>
                                                            <td><input class="form-control service-price" data-index="1" type="number" name="service-unit-price[1]" id="inputServicePrice1" min="0" step="1.0" value="0.00" style="width: 80px;" required/></td>
                                                            <td><p class="me-5 h5" name="service-total-price" id="serviceTotal1"></p></td>
                                                            <td><button type="button" class="removeRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div class="modal fade" id="stockModal" tabindex="-1" aria-labelledby="stockModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="stockModalLabel"><i class="bi bi-box-seam me-2"></i>Select item from Stock</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                        <?php
                                                            require_once '../src/db_connect.php';
                                                            
                                                            $sql = "SELECT item_id, name, price FROM stock;";
                                                            $result = mysqli_query($conn, $sql);
                            
                                                            if (mysqli_num_rows($result) > 0) {
                                                                echo '<select  class="form-control" id="select-item" name="product" autocomplete="off" placeholder="Product" required>
                                                                        <option disabled selected value></option>';
                                                                    while($row = mysqli_fetch_assoc($result)){
                            
                                                                        $item_id = $row['item_id'];
                                                                        $item_name = $row['name'];
                                                                        $item_price = $row['price']; 
                                                                        
                                                                        echo "<option data-i_name='$item_name' data-i_price='$item_price' value='$item_id'>" . $item_name . "</option>";
                                                                    }
                            
                                                                echo '</select>';      
                                                            }  
                                                        ?>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button id="addItem" type="button" class="btn btn-primary" data-bs-dismiss="modal">Add item</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <i id="addStockRow" class="bi bi-plus-square-fill fa-2xl mt-3" type="button" style="margin-bottom: 1rem;"></i>
                                                <table name="stock-table" id="inputStockTable" class="display border" style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th></th>
                                                            <th>Item Name</th>
                                                            <th>Quantity</th>
                                                            <th>Unit Price</th>
                                                            <th>Total</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex justify-content-center">
                                                                    <button class="btn btn-primary add-item" type="button" value="1" name="item-stock-name[1]" id="inputStockItemName1" data-bs-toggle="modal" data-bs-target="#stockModal" required>
                                                                        <input type="hidden" id="itemId1" name="item-stock-id[1]" required/>
                                                                        Select item
                                                                    </button>
                                                                </div>
                                                            </td>
                                                            <td><p class="w-auto border text-center mt-2 h5" name="item-name" id="itemName1"></p></td>
                                                            <td><input class="stock-quantity form-control" type="number" data-index="1" name="item-stock-quantity[1]" id="inputStockQuantity1"  type="number" min="1" value="1" style="width: 67px;"  oninput="this.value = Math.abs(this.value)" required></td>
                                                            <td><p class="text-center h5" name="item-price" id="itemPrice1"></p></td>
                                                            <td><p class="me-5 h5" name="item-total-price" id="itemTotal1"></p></td>
                                                            <td><button type="button" class="removeStockRow" style="background-color: transparent; border: none;" ><i class="fas fa-trash-alt fa-xl"></i></button></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="row mb-2 mt-5">
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="invoice-vat" id="inputInvoiceVat" type="number" min="0" value="0" placeholder="VAT" oninput="this.value = Math.abs(this.value)" required>
                                                        <label for="inputInvoiceVat">Vat</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="invoice-discount" id="inputInvoiceDiscount" type="number" min="0" value="0" placeholder="Discount" oninput="this.value = Math.abs(this.value)" required>
                                                        <label for="inputInvoiceDiscount">Discount</label>
                                                    </div>
                                                </div>
                                                <div class="row-md-6s">
                                                    <div class="d-flex justify-content-end me-6">
                                                        <p class="me-5 h4" id="combinedTotal">Total (<i>€</i>): </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-5 mb-0">
                                                <button class="btn btn-primary btn-block w-auto" type="submit" id="create_invoice_button" style="float:right;">Create Invoice</button>
                                            </div>
                                            <input type="hidden" id="tablesData" name="table_data">
                                        </form>
                                        <div class="mt-5 mb-0">
                                            <button class="btn btn-primary btn-block w-auto" type="button" id="export_invoice_button">Preview</button>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="card-footer text-center py-3">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <script src="../assets/datatables/datatables.js"></script>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="../assets/js/invoice_form.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script type="module" src="../assets/js/export-invoice.js"></script>
        <script>
            new TomSelect("#select-customer",{
                persist: true,
                createOnBlur: true,
                create: false,
                searchField: 'title',
            });
        </script>
        
    </body>
</html>
