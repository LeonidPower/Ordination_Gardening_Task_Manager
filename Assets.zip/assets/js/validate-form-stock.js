$('#inputProductName').on('input', function() {
    if ($(this).val().length > 20) {
        $(this).val($(this).val().slice(0, 20)); // Truncate input to 10 characters
    }
})

$('#inputHeight').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputWidth').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputSize').on('input', function() {
    if ($(this).val().length > 5) {
        $(this).val($(this).val().slice(0, 5)); // Truncate input to 10 characters
    }
})

$('#inputQuantity').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /^\d+$/;
    if (!numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\D/g, '')); // Remove non-digit characters
    }
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})

$('#inputVolume').on('input', function() {
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})

$('#inputPrice').on('input', function() {
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})


