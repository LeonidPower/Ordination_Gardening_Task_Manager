import "../FileSaver.js/src/FileSaver.js";
import "../jsPDF/jspdf.js" ; 

function buildTableBodyServices(data, columns) {

    var body = [];
    var col_qty = {text: 'Qty', fontSize: 12, bold:true};
    var col_description = {text: 'Name', fontSize: 12, bold:true};
    var col_unit_price = {text: 'Price', fontSize: 12, bold:true};
    var col_amount = {text: 'Amount', fontSize: 12, bold:true};
    var styled_columns = [col_qty, col_description, col_unit_price, col_amount];

    body.push(styled_columns);

    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            console.log(row[column]);
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });
    return body;
}

function makeTableServices(data, columns) {
    return {
        table: {
            heights: 25,
            widths: [50, 285, 70, 75],
            headerRows: 1,
            body: buildTableBodyServices(data, columns)
        },
        margin: [0,110,0,0],

    };
}

function buildTableBodyStock(data, columns) {

    var body = [];
    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });
    console.log(body);
    return body;
}

function makeTableStock(data, columns) {
    return {
        table: {
            heights: 25,
            widths: [50, 285, 70, 75],
            headerRows: 1,
            body: buildTableBodyStock(data, columns)
        },
        margin: [0,-1,0,0],

    };
}

const form = document.getElementById('invoice_form');
const export_invoice = document.getElementById('export_invoice_button');
export_invoice.addEventListener('click' , () => { 

    var cityzip = ordcity + ", " + ordzip;

    if ($('#customer-options').val() == 'New Customer'){ 
        const name = $('#inputName').val();
        const surname = $('#inputSurname').val();
        var fullName = name + " " + surname;
        var companyName = $('#inputCompanyName').val();
        const email = $('#inputEmail').val();
        var address = $('#inputAddress').val();
    }else if ($('#customer-options').val() == 'Existing Customer'){

        const name = $('#select-customer option:selected').attr('data-c_name');
        const surname = $('#select-customer option:selected').attr('data-c_surname');
        var fullName = name + " " + surname;
        var companyName = $('#select-customer option:selected').attr('data-c_company');
        var address = $('#select-customer option:selected').attr('data-c_address');
    }

    const invoiceName = form.elements['invoice-name'].value;
    const invoiceDate = form.elements['invoice-date'].value;
    const invoiceValidFor = form.elements['invoice-valid-for'].value;
    const vat = form.elements[`invoice-vat`].value;
    const discount = form.elements[`invoice-discount`].value;
    var subTotal = 0;

    var tableDataServices = [];
    var tableDataStock = [];

    var currentPage = 0;

    var table = $('#inputServiceTable').DataTable();

    while (currentPage < table.page.info().pages) {
    table.page(currentPage).draw(false);

    $('#inputServiceTable tbody tr').each(function(row, tr) {
        tableDataServices.push({
            "qty": $(tr).find('td:eq(2) input').val(),
            "description": $(tr).find('td:eq(0) input').val(),
            "unit-price": $(tr).find('td:eq(3) input').val(),
            "amount": parseInt($(tr).find('td:eq(2) input').val()) * parseFloat($(tr).find('td:eq(3) input').val())
        });
    });
    currentPage++;
    }


    currentPage = 0;
    var table2 = $('#inputStockTable').DataTable();

    while (currentPage < table2.page.info().pages) {
    table2.page(currentPage).draw(false);

    $('#inputStockTable tbody tr').each(function(row, tr) {
        tableDataStock.push({
            "qty": $(tr).find('td:eq(2) input').val(),
            "name": $(tr).find('td:eq(1) p').html(),
            "unit-price": $(tr).find('td:eq(3) p').html(),
            "amount": parseInt($(tr).find('td:eq(2) input').val()) * parseFloat($(tr).find('td:eq(3) p').html())
        });
        console.log($(tr).find('td:eq(3) p').html());
    });
        currentPage++;
    }

   
    var subTotal = 0; 
    tableDataServices.forEach(function(row) {
        subTotal += row.qty * row["unit-price"];
    });

    tableDataStock.forEach(function(row) {
            subTotal += row.qty * row["unit-price"];
    });

    var discAmount = subTotal * discount/100;
    //discAmount =  discAmount.toFixed(2).toString();

    var vatAmount = (subTotal - discAmount) * vat/100;
   /// vatAmount = vatAmount.toFixed(2).toString();

    var total = subTotal - discAmount + vatAmount;
    //total = total.toFixed(2).toString();


    var docDefinition = {
        content: [
            {
                columns: [
                    {
                        width: 450,
                        text: 'Ordinatio Gardening',
                        style: 'header',
                        fontSize: 24,
                        bold: true,
                    },
                    {
                        width: 100,
                        text: 'Invoice',
                        style: 'header',
                        fontSize: 24,
                        bold: true,
                    },
                ],
            },
            { text: ordaddress, margin: [1,10,0,0] },
            { text: cityzip, margin: [1,0,0,0] },
            {
                columns: [
                    {
                        width: 300,
                        text: 'Bill to:',
                        fontSize: 15,
                        bold: true,
                    },
                    {
                        width: 80,
                        text: 'Invoice Date',
                        fontSize: 15,
                        bold: true,
                    },
                    {
                        text: invoiceDate,
                        fontSize: 12,
                        margin: [20,3,0,0],
                    },
                ],
                margin: [0,80,0,0],
            },
            {
                columns: [
                    {
                        text: fullName.toString(),
                        fontSize: 12,
                    },
                ],
                margin: [0,8,0,0],
            },
            {
                columns: [
                    {
                        text: address.toString(),
                        fontSize: 12,
                    },
                ],
            },
            makeTableServices(tableDataServices, ['qty', 'description', 'unit-price', 'amount']),  
            makeTableStock(tableDataStock, ['qty', 'name', 'unit-price', 'amount']),              
            { 
                table :{ 
                    heights: 25,
                    widths: [70, 75],
                    body:[
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Subtotal',
                            },
                            { 
                                text: subTotal,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Discount '+ discount + '%',
                            },
                            { 
                                text: discAmount,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Vat '+ vat + '%',
                            },
                            { 
                                text: vatAmount,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Total',
                            },
                            { 
                                text: '€' + total,
                            }
                        ],
                    ],
                },
                margin: [353,-1,0,0],
            },
            {
                bold: true,
                fontSize: 15,
                margin: [0,180,0,0],
                text: 'Terms and conditions',
            },
            {
                margin: [0,10,0,0],
                fontSize: 12,
                text: 'Payment is due within ' + invoiceValidFor + ' days',
            },
            {
                fontSize: 12,
                text: 'Please make checks payable to ' + payableto,
            },

        ]
    };
    pdfMake.createPdf(docDefinition).open();
});

