<?php

namespace Objects;

class Project{
    public $project_id;
    public $project_name;
    public $project_address;
    public $project_number;
    public $project_city;
    public $project_post;
    public $project_start_date;
    public $project_end_date;
    public $project_status;
    public $project_description;

    public $customer;
    public $project_supervisors = array();

    function __construct($p_id, $p_name, $p_add, $p_num, $p_city, $p_post, $p_s_date, $p_e_date, $p_status, $p_desc, $cust) {
        $this->project_id = $p_id;
        $this->project_name = $p_name;
        $this->project_address = $p_add;
        $this->project_number = $p_num;
        $this->project_city = $p_city;
        $this->project_post = $p_post;
        $this->project_start_date = strtotime($p_s_date); 
        $this->project_end_date = strtotime($p_e_date); 
        $this->project_status = $p_status;
        $this->project_description = $p_desc; 
        $this->customer = $cust; 
    }

    function add_supervisor($supervisor){ 
        array_push($this->project_supervisors, $supervisor);
    }

}

class User{
    public $user_name;
    public $user_surname;
    public $user_email;
    public $user_phone;
    public $user_address;
    public $user_hash;

    function __construct($u_name, $u_surname, $u_email, $u_phone, $u_address, $u_hash) {
        $this->user_name = $u_name;
        $this->user_surname = $u_surname;
        $this->user_email = $u_email;
        $this->user_phone = $u_phone;
        $this->user_address = $u_address;
        $this->user_hash = $u_hash; 
    }
}

class Supervisor{

    public $supervisor_id;
    public $supervisor_name;
    public $supervisor_surname;
    public $supervisor_phone;
    public $supervisor_address;
    public $supervisor_email;
    public $supervisor_position_id;
    public $supervisor_position_name;
    public $supervisor_is_project_manager;
    public $supervisor_is_admin;
    public $supervisor_hash;

    public $position;

    function __construct($s_id, $s_name, $s_surname, $s_phone, $s_address, $s_email, $s_p_id, $p_name, $is_p_m, $s_is_admin, $s_hash) {
        $this->supervisor_id = $s_id;
        $this->supervisor_name = $s_name;
        $this->supervisor_surname = $s_surname;
        $this->supervisor_phone = $s_phone;
        $this->supervisor_address = $s_address;
        $this->supervisor_email = $s_email;
        $this->supervisor_position_id = $s_p_id;
        $this->supervisor_position_name = $p_name;
        $this->supervisor_is_project_manager = $is_p_m;
        $this->supervisor_is_admin = $s_is_admin;
        $this->supervisor_hash = $s_hash;

    }

    // function set_position($pos_name, $is_project_manager){ 
    //     $position = [
    //                 'position_id' => $this->supervisor_position_id_users,
    //                 'position_name' => $pos_name,
    //                 'is_project_manager' => $is_project_manager,
    //     ];
    // }
}

class Customer{
    public $customer_id;
    public $customer_name;
    public $customer_surname;
    public $customer_email;
    public $customer_phone;
    public $customer_company;
    public $customer_address;
    public $customer_hash;

    function __construct($c_id, $c_name, $c_surname, $c_email, $c_phone, $c_address, $c_comp, $c_hash) {
        $this->customer_id = $c_id;
        $this->customer_name = $c_name;
        $this->customer_surname = $c_surname;
        $this->customer_email = $c_email;
        $this->customer_phone = $c_phone;
        $this->customer_address = $c_address;
        $this->customer_company = $c_comp;
        $this->customer_hash = $c_hash; 
    }
}

class Task{
    public $task_id;
    public $task_name;
    public $task_start_date;
    public $task_end_date;
    public $task_description;
    public $task_status;
    public $task_project_id;
    public $task_project_name;
    public $task_assignees = array(); 

    function __construct($t_id, $t_name, $t_s_date, $t_e_date, $t_desc, $t_status, $t_p_id, $t_p_name) {
        $this->task_id = $t_id;
        $this->task_name = $t_name;
        $this->task_start_date = $t_s_date;
        $this->task_end_date = $t_e_date;
        $this->task_description = $t_desc;
        $this->task_status = $t_status;
        $this->task_project_id = $t_p_id;
        $this->task_project_name = $t_p_name;
    }

    function add_assignee($assignee){ 
        array_push($this->task_assignees, $assignee);
    }
}

class Quote{
    public $quote_id;
    public $quote_name;
    public $quote_status;
    public $quote_date;
    public $quote_total_price;
    public $quote_vat;
    public $quote_discount;
    public $quote_valid_for;
    public $customer;
    public $customer_name;
    public $customer_address;

    public $quote_services = array();
    public $quote_stock = array();

    function __construct($q_id, $q_name, $q_status, $q_date, $q_total_price, $q_vat, $q_discount, $q_valid_for, $cust) {
        $this->quote_id = $q_id;
        $this->quote_name = $q_name;
        $this->quote_status = $q_status;
        $this->quote_date = $q_date;
        $this->quote_total_price = $q_total_price;
        $this->quote_vat = $q_vat;
        $this->quote_discount = $q_discount;
        $this->quote_valid_for = $q_valid_for;
        $this->customer = $cust;
    }

    function add_service($service){ 
        array_push($this->quote_services, $service);
    }

    function add_stock($stock){ 
        array_push($this->quote_stock, $stock);
    }
    function get_customer_name($cust_first_name, $cust_last_name){ 
        $this->customer_name = $cust_first_name . " " . $cust_last_name;
        return $this->customer_name;
    }

    function get_customer_address($cust_address){ 
        $this->customer_address = $cust_address;
        return $this->customer_address;
    }
}

class Invoice{
    public $invoice_id;
    public $invoice_name;
    public $invoice_status;
    public $invoice_date;
    public $invoice_total_price;
    public $invoice_vat;
    public $invoice_discount;
    public $invoice_valid_for;
    public $customer;
    public $customer_name;
    public $customer_address;

    public $invoice_services = array();
    public $invoice_stock = array();

    function __construct($q_id, $q_name, $q_status, $q_date, $q_total_price, $q_vat, $q_discount, $q_valid_for, $cust) {
        $this->invoice_id = $q_id;
        $this->invoice_name = $q_name;
        $this->invoice_status = $q_status;
        $this->invoice_date = $q_date;
        $this->invoice_total_price = $q_total_price;
        $this->invoice_vat = $q_vat;
        $this->invoice_discount = $q_discount;
        $this->invoice_valid_for = $q_valid_for;
        $this->customer = $cust;
    }

    function add_service($service){ 
        array_push($this->invoice_services, $service);
    }

    function add_stock($stock){ 
        array_push($this->invoice_stock, $stock);
    }
    function get_customer_name($cust_first_name, $cust_last_name){ 
        $this->customer_name = $cust_first_name . " " . $cust_last_name;
        return $this->customer_name;
    }

    function get_customer_address($cust_address){ 
        $this->customer_address = $cust_address;
        return $this->customer_address;
    }
}

class Service{
    public $service_id;
    public $service_name;
    public $service_description;
    public $service_quantity;
    public $service_volume;
    public $service_price; 

    function __construct($s_id, $s_name, $s_desc, $s_quantity, $s_volume, $s_price) {
        $this->service_id = $s_id;
        $this->service_name = $s_name;
        $this->service_description = $s_desc;
        $this->service_quantity = $s_quantity;
        $this->service_volume = $s_volume;
        $this->service_price = $s_price;
    }
}

class Stock{ 
    public $stock_id;
    public $stock_name;
    public $stock_quantity;
    public $stock_volume;
    public $stock_width;
    public $stock_height;
    public $stock_size;
    public $stock_price;

    function __construct($s_id, $s_name, $s_quantity, $s_volume, $s_width, $s_height, $s_size, $s_price) {
        $this->stock_id = $s_id;
        $this->stock_name = $s_name;
        $this->stock_quantity = $s_quantity;
        $this->stock_volume = $s_volume;
        $this->stock_width = $s_width;
        $this->stock_height = $s_height;
        $this->stock_size = $s_size;
        $this->stock_price = $s_price;
    }
}

?>