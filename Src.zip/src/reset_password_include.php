<?php

require 'db_connect.php';

    if (isset($_POST["reset-password-submit"]) ){                                                                  
        $selector = $_POST["selector"];
        $validator = $_POST["validator"];
        $password = $_POST["pwd"];
        $passwordRepeat = $_POST["pwd-repeat"];
    
        if (empty($password) || empty($passwordRepeat)) {
            header('Location: ../commons/reset_password_error.php?password or password repeat empty');
            exit();
        }else if($password != $passwordRepeat ){
            header("Location: ../commons/reset_password_error.php?passwords don't match");
            exit();
        }
        
        $currentDate = date("U");
        
        $sql = "SELECT * FROM resetpassword WHERE Selector = ? AND Expires >= ?";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt, $sql)){
            header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
            exit();
        } else{
                mysqli_stmt_bind_param($stmt, "ss", $selector, $currentDate);
                mysqli_stmt_execute($stmt);

                $result = mysqli_stmt_get_result($stmt);
                if(!$row = mysqli_fetch_assoc($result)){
                    header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                    exit();
                } else{
                    $tokenBin=$validator;               
                    if(trim($tokenBin) == trim($row["Token"])){
                        $tokenCheck=true;
                    }else{
                        $tokenCheck=false;
                    }

                    if($tokenCheck == false){
                        header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                    } else if($tokenCheck == true){
                        $tokenEmail = $row['Email'];
                        $sql = "SELECT * FROM user WHERE email=?;";
                        $stmt = mysqli_stmt_init($conn);
                        if(!mysqli_stmt_prepare($stmt, $sql)){
                            header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                            exit();
                        } else{
                            mysqli_stmt_bind_param($stmt,"s", $tokenEmail);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);
                            if(!$row = mysqli_fetch_assoc($result )){
                                header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                                exit();
                            } else{
                                $sql= "UPDATE user SET password=? WHERE email=?";
                                $stmt = mysqli_stmt_init($conn);
                                if(!mysqli_stmt_prepare($stmt, $sql)){
                                    header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                                    exit();
                                } else{
                                    $newPwdHash = $passwordRepeat;
                                    mysqli_stmt_bind_param($stmt,"ss", $newPwdHash, $tokenEmail);
                                    mysqli_stmt_execute($stmt);
                                    
                                    $sql= "DELETE FROM  resetpassword WHERE Email =?";
                                    $stmt = mysqli_stmt_init($conn);
                                    if(!mysqli_stmt_prepare($stmt, $sql)){
                                        header('Location: ../commons/reset_password_error_reset.php'); // change this to the according error (internal server error) later
                                        exit();
                                    } else{
                                        mysqli_stmt_bind_param($stmt,"s", $tokenEmail);
                                        mysqli_stmt_execute($stmt);
                                        echo "<script> alert('Your password has been changed successfully.You are being redirected to the log in page press OK to continue');</script>";
                                        header ('Location: login.php');
                                }
                            }
                        }
                    }
                }
            }
        } 
    }else{
        header('Location: ../commons/reset_password_error.php');
    }
?>