const table = document.getElementById("users-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_user_btn').removeAttr('disabled');
            $('#delete_user_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_user_btn').prop('disabled');
            $('#edit_user_btn').prop('disabled')
        }

    })
});

$('#edit_user_btn').click(()=>{ 
    if (checkedRow) {

        const row = $(checkedRow);
        const u_hash = row.attr('data-u_hash');
        const u_name = row.attr('data-u_name');
        const u_surname = row.attr('data-u_surname');
        const u_email = row.attr('data-u_email');
        const u_phone = row.attr('data-u_phone');
        const u_address = row.attr('data-u_address');
        const u_position = row.attr('data-u_position');
        const u_is_admin = row.attr('data-u_is_admin');

        if(u_is_admin  == 1){ 
            $("#inputIsAdmin").prop('checked', true);
        }
        else{ 
          $("#inputIsAdmin").prop('checked', false);
        }

        position_select.setValue(u_position);

        $("#hashID_edit").val(u_hash);
        $("#inputFirstName").val(u_name);
        $("#inputLastName").val(u_surname);
        $("#inputEmail").val(u_email);
        $("#inputPhoneNumber").val(u_phone);
        $("#inputAddress").val(u_address);

    }
});

$('#delete_user_btn').click(()=>{
    const row = $(checkedRow);
    const u_hash = row.attr('data-u_hash');

    $("#hashID_del").val(u_hash);
});



var position_select = new TomSelect('#select-position',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});
