<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
</head>
<link rel="icon" type="image/png" href="../assets/img/title.svg">

<body class="sb-nav-fixed" style="overflow-x: hidden;">
    <nav class="sb-topnav navbar navbar-expand navbar-dark top-nav-color">
        <a class="navbar-brand ps-lg-1" href="../src/dashboard.php">
            <img src="../assets/img/ordinatio_manager_logo.svg" alt="ordinatio manager logo" height="40" width="40"
                style="padding-left: 10px;">
            <p class="d-inline mt-3">Ordinatio Manager</p>
        </a>
        <div class="container-fluid align-list-right">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle mt-1" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false"><i class="fas fa-user fa-fw fa-xl"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <form method="POST" action="fetch_session.php">
                            <li><button class="dropdown-item text-center h5 mt-2 mb-2" type='submit'>Restart Session</button></li>
                        </form>
                        <li><a class="dropdown-item text-center h5 mt-2 mb-2" href="../src/user_settings.php">Settings</a></li>
                        <li>
                            <hr class="dropdown-divider" />
                        </li>
                        <li>
                            <form class="dropdown-item text-center h5" name="logout" action="../src/logout.php"
                                method="POST">
                                <button class="log-out-btn" type="submit">Logout</button>
                            </form>
                        </li>
                    </ul>
                </li>
                <div class="ms-auto">
                    <div class="small">Logged in as:
                        <?php echo ucfirst($_SESSION['name']); ?>
                    </div>
                    <?php
                        if ($_SESSION['is_admin'] === '1' ){ 
                            echo "<p class='text-light'>Role: Admin</p>";
                        }
                        else{ 
                            echo "<p class='text-light'>Role: User</p>";
                        }
                    ?>
                </div>
            </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-color" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav mt-3">
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_projects'] === '1' || $_SESSION['position']['view_projects'] === '2' || $_SESSION['position']['create_projects'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseProjects" aria-expanded="false" aria-controls="collapseProjects">
                                        <div class="sb-nav-link-icon"><i class="bi bi-view-stacked"></i></div>
                                            Projects
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseProjects" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_projects'] === '1' || $_SESSION['position']['view_projects'] === '2' || $_SESSION['position']['create_projects'] === '1'){      
                                            echo '<a class="nav-link" href="project.php">View All Projects</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_projects'] === '1'){      
                                            echo '<a class="nav-link" href="project_form_intermediate.php">Create New Project</a></a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_tasks'] === '1' || $_SESSION['position']['view_tasks'] === '2' || $_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTasks" aria-expanded="false" aria-controls="collapseTasks">
                                        <div class="sb-nav-link-icon"><i class="bi bi-check-all"></i></div>
                                            Tasks
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseTasks" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_tasks'] === '1' || $_SESSION['position']['view_tasks'] === '2' || $_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2'){      
                                            echo '<a class="nav-link" href="task.php">View All Tasks</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2'){      
                                            echo ' <a class="nav-link" href="task_form_intermediate.php">Create New Task</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_users'] === '1' || $_SESSION['position']['create_users'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUsers" aria-expanded="false" aria-controls="collapseUsers">
                                        <div class="sb-nav-link-icon"><i class="bi bi-people-fill"></i></div>
                                            Users
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseUsers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_users'] === '1' || $_SESSION['position']['create_users'] === '1'){      
                                            echo '<a class="nav-link" href="user.php">View All Users</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_users'] === '1'){      
                                            echo '<a class="nav-link" href="user_form_intermediate.php">Create New User</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_invoices'] === '1' || $_SESSION['position']['create_invoices'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseInvoices" aria-expanded="false" aria-controls="collapseProjects">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-file-invoice"></i></div>
                                            Invoices
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseInvoices" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_invoices'] === '1' || $_SESSION['position']['create_invoices'] === '1'){      
                                            echo '<a class="nav-link" href="invoice.php">View All Invoices</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_invoices'] === '1'){      
                                            echo '<a class="nav-link" href="invoice_form_intermediate.php">Create New Invoices</a></a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_quotes'] === '1' || $_SESSION['position']['create_quotes'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                        <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                            Quotes
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                      </a>
                                    <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_quotes'] === '1' || $_SESSION['position']['create_quotes'] === '1'){      
                                            echo '<a class="nav-link" href="quote.php">View All quotes</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_quotes'] === '1'){      
                                            echo ' <a class="nav-link" href="quote_form_intermediate.php">Create a Quote</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_customers'] === '1' || $_SESSION['position']['create_customers'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCustomers" aria-expanded="false" aria-controls="collaplseCustomers">
                                        <div class="sb-nav-link-icon"><i class="bi bi-person-lines-fill"></i></div>
                                            Customers
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseCustomers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_customers'] === '1' || $_SESSION['position']['create_customers'] === '1'){      
                                            echo ' <a class="nav-link" href="customer.php">View All Customers</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_customers'] === '1'){      
                                            echo '<a class="nav-link" href="customer_form_intermediate.php">Create New Customer</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_stock'] === '1' || $_SESSION['position']['create_stock'] === '1'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseStock" aria-expanded="false" aria-controls="collaplseStock">
                                     <div class="sb-nav-link-icon"><i class="bi bi-box-seam"></i></div>
                                        Stock
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseStock" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['view_stock'] === '1' || $_SESSION['position']['create_stock'] === '1'){      
                                            echo ' <a class="nav-link" href="stock.php">View Stock</a>';
                                        }
                                        if ( $_SESSION['is_admin'] === '1' || $_SESSION['position']['create_stock'] === '1'){      
                                            echo '<a class="nav-link" href="stock_form_intermediate.php">Add new item</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <a class="nav-link" href="calendar.php" aria-expanded="false">
                            <div class="sb-nav-link-icon"><i class="bi bi-calendar4-week"></i></div>
                            Calendar
                        </a>
                        <?php 
                            if ($_SESSION['is_admin'] === '1' ){ 
                                echo'<a class="nav-link" href="../src/manage_system.php"  aria-expanded="false"> <div class="sb-nav-link-icon"><i class="fa-solid fa-sliders"></i></div> Manage System</a>';
                            }
                        ?>
                    </div>
            </nav>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
        <script src="https://unpkg.com/htmx.org@1.9.0" integrity="sha384-aOxz9UdWG0yBiyrTwPeMibmaoq07/d3a96GCbb9x60f3mOt5zwkjdbcHFnKH8qls" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>

</html>