
$('.project-card').click(function(){       
    const p_name = $(this).attr('data-p_name');
    const p_add = $(this).attr('data-p_add');
    const p_s_date = $(this).attr('data-p_s_date');
    const p_e_date= $(this).attr('data-p_e_date');
    const c_name= $(this).attr('data-c_name');
    const c_phone= $(this).attr('data-c_phone');
    
    console.log(p_name);
    $("#pname").html("<span style='font-weight: bold;'>Project Name: </span>"+p_name);
    $("#location").html("<span style='font-weight: bold;'>Location: </span>"+p_add);
    $("#startday").html("<span style='font-weight: bold;'>Start Day: </span>"+p_s_date);
    $("#endday").html("<span style='font-weight: bold;'>End Day: </span>"+p_e_date);
    $("#customer").html("<span style='font-weight: bold;'>Customer Name: </span>"+c_name);
    $("#cphone").html("<span style='font-weight: bold;'>Customer Phone Number: </span>"+c_phone);  
});
 