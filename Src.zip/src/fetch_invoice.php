<?php
    require "db_connect.php";
    require "objects.php";

    $requiredFields = ['id'];

    if (count(array_intersect($requiredFields, array_keys($_GET))) === count($requiredFields)) {
        $invoice_id = $_GET['id'];
    }

    if(empty($invoice_id)) {
        header("Location: ../src/invoice.php?error=Invoice not found");
        exit();
    }else{
    
        $query = "SELECT customer.hash AS hash, customer.name AS c_name, customer.surname AS c_surname, customer.address AS c_add, invoice.total_price,
                invoice.name, invoice.date, invoice.status, invoice.vat, invoice.valid_for, invoice.discount
            FROM invoice
            JOIN customer ON customer.customer_id = invoice.customer_id 
            WHERE invoice.invoice_id=? LIMIT 1;";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $invoice_id);
        $stmt->execute();

        $result = $stmt->get_result();

        $invoices = array();
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            $invoice = new Objects\Invoice($invoice_id, $row['name'], $row['status'], $row['date'], $row['total_price'], $row['vat'], $row['discount'], $row['valid_for'], $row['hash']);
            $invoice->get_customer_name($row['c_name'], $row['c_surname']);
            $invoice->get_customer_address($row['c_add']);
            array_push($invoices, $invoice);

            $query2 = "SELECT * FROM invoice_services WHERE invoice_id=?;";

            $stmt = $conn->prepare($query2);
            $stmt->bind_param("i", $invoice_id);
            $stmt->execute();
            $result2 = $stmt->get_result();

            if (mysqli_num_rows($result2) > 0) {
                while($row2 = mysqli_fetch_assoc($result2)){
                    $service = new Objects\Service($row2['service_id'], $row2['name'], $row2['description'], $row2['quantity'], $row2['volume'], $row2['price']);
                    $invoice->add_service($service);
                }
            }

            $query3 = "SELECT invoice_stock.stock_item_id AS s_id, invoice_stock.quantity AS s_quantity, stock.price AS s_price, stock.name AS s_name, stock.volume AS s_volume, stock.width AS s_width, stock.height AS s_height, stock.size AS s_size
                FROM invoice_stock
                JOIN stock ON stock.item_id = invoice_stock.stock_item_id
                WHERE invoice_stock.invoice_id=?;";

            $stmt = $conn->prepare($query3);
            $stmt->bind_param("i", $invoice_id);
            $stmt->execute();
            $result3 = $stmt->get_result();

            if(mysqli_num_rows($result3) > 0){
                while($row3 = mysqli_fetch_assoc($result3)){
                    $stock = new Objects\Stock($row3['s_id'], $row3['s_name'], $row3['s_quantity'], $row3['s_volume'], $row3['s_width'], $row3['s_height'], $row3['s_size'], $row3['s_price']);
                    $invoice->add_stock($stock);
                }
            }
        }
        $invoice_json = json_encode($invoices); 

    }
    $conn->close();
?>