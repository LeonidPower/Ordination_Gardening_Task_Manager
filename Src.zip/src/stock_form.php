<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['product_name']) && isset($_POST['quantity']) && isset($_POST['price'])){   
        
        $product_name = validate($_POST['product_name']);
        $quantity = validate($_POST['quantity']);
        $price = validate($_POST['price']);
        $image_present = false;

        $volume = isset($_POST['volume']) ? validate($_POST['volume']) : null;
        
        if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {  
            if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
                
                $image_name = basename($_FILES['image']['name']);
                $extension = pathinfo($image_name, PATHINFO_EXTENSION);
                $unique_image_name = uniqid() . '.' . $extension;
                
                $upload_to = '../assets/stock_images/' . $unique_image_name;
                $image_present = true;

            } else {
                header("Location: stock_form.php?error=Image failed to upload");
                exit();
            }
        }

        if(isset($_POST['width']) && isset($_POST['height']) && isset($_POST['size'])){ 
            $width = validate($_POST['width']);
            $height = validate($_POST['height']);
            $size = validate($_POST['size']);
        }
        else{
            header("Location: stock_form.php?error=All dimension fields are required");
            exit();
        }
    }
    else{
        include "../admin/stock_form.php";
        exit();
    }

    if(empty($product_name)){ 
      header("Location: stock_form.php?error=Product_name is empty");
      exit();
    }
    elseif(empty($quantity)){ 
        header("Location: stock_form.php?error=Quantity is empty");
        exit();
    }
    elseif(empty($price)){ 
        header("Location: stock_form.php?error=Price is empty");
        exit();
    }
    else{
        if ($image_present){ 
            move_uploaded_file($_FILES['image']['tmp_name'], $upload_to);
        }else{
            $upload_to = $image_path;
            echo $upload_to;
        }
            $price_round = round($price, 2);
            $sql = "INSERT INTO stock (name, quantity, volume, width, height, size, price, image) 
            VALUES ('$product_name','$quantity', '$volume','$width','$height','$size', '$price_round','$upload_to');";

            $result = mysqli_query($conn, $sql); #we might need this later

            header("Location: stock.php?success=Item added successfully");
        }
?> 