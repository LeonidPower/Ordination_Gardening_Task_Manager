<?php
    session_start();
    if(!isset($_SESSION['loggedin'])){
        $responce = array('status' => 'failed');
        header("Location: login.php");
        session_destroy();
    }
    else{
        $responce = array('status' => 'success' , 'user_id' => $_SESSION['user_id']);
        return;
    }
    exit();
?>