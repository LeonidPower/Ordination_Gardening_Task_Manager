// //Tom Selects
new TomSelect('#select-customer-data',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});


new TomSelect('#select-supervisor',{
	create: false,
	maxItems: 10,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});

var start_date = flatpickr("#inputProjectStartDate", {
    dateFormat: "Y-m-d",
    time_24hr: true,
});
var end_date = flatpickr("#inputProjectEndDate", {
    dateFormat: "Y-m-d",
    time_24hr: true,
});
$("#inputProjectStartDate").css("background-color", "white");
$("#inputProjectEndDate").css("background-color", "white");


$("#inputProjectStartDate").on("change", function() {
	if(($(this).val() >= $("#inputProjectEndDate").val()) && $("#inputProjectEndDate").val() != ""){
		$("#project-start-date-after-end-date").modal("show");
		start_date.setDate("");
		$("#inputTaskStartDate").addClass("is-invalid");
	}	
});
$("#inputProjectEndDate").on("change", function() {
	if(($(this).val() <= $("#inputProjectStartDate").val()) && $("#inputProjectStartDate").val() != ""){
		$("#project-end-date-before-start-date").modal("show");
		end_date.setDate("");
		$("#inputTaskEndDate").addClass("is-invalid");
	}	
});