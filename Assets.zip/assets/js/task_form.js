// Date Field
var project_start_date = null;
var project_end_date = null;

$('#select-project').on('change', function() {
    project_start_date = $(this).find(':selected').data('p_start_date');
    project_end_date = $(this).find(':selected').data('p_end_date');
});

var start_date = flatpickr("#inputTaskStartDate", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    time_24hr: true,
});
var end_date = flatpickr("#inputTaskEndDate", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    time_24hr: true,
});
$("#inputTaskStartDate").css("background-color", "white");
$("#inputTaskEndDate").css("background-color", "white");

$("#inputTaskStartDate").on("change", function() {
	if (project_start_date == null) {
		start_date.close();
		start_date.setDate("");
		$("#project-not-selected").modal("show");
		start_date.setDate("");
		$("#inputTaskStartDate").addClass("is-invalid");
    }
	else{ 
		if(!($(this).val() >= project_start_date && $(this).val() <= project_end_date)){
			$("#project-date-after").modal("show");
			start_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
		if($('#inputTaskEndDate').val() != "" && !($(this).val() <= $('#inputTaskEndDate').val())){ 
			$("#task-start-date-after-end-date").modal("show");
			start_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
	}
});

$("#inputTaskEndDate").on("change", function() {
    if (project_end_date == null) {
		end_date.close();
		end_date.setDate("");
		$("#project-not-selected").modal("show");
		$("#inputTaskEndDate").addClass("is-invalid");
    }
	else{ 
		if(!($(this).val() >= project_start_date && $(this).val() <= project_end_date)){
			$("#project-date-before").modal("show");
			end_date.setDate("");
			$("#inputTaskEndDate").addClass("is-invalid");
		}
		if($('#inputTaskStartDate').val() != "" && !($(this).val() >= $('#inputTaskStartDate').val())){ 
			$("#task-end-date-before-start-date").modal("show");
			end_date.setDate("");
			$("#inputTaskStartDate").addClass("is-invalid");
		}
	}
});
