import "../FileSaver.js/src/FileSaver.js";

function buildTableServices(data, columns) {
    if(data.length <=0 ){ 
        return 0;
    }
    var body = [];
    var col_qty = {text: 'Qty', fontSize: 12, bold:true};
    var col_description = {text: 'Name', fontSize: 12, bold:true};
    var col_unit_price = {text: 'Price', fontSize: 12, bold:true};
    var col_amount = {text: 'Amount', fontSize: 12, bold:true};
    var styled_columns = [col_qty, col_description, col_unit_price, col_amount];
    body.push(styled_columns);

    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });
    return body;
}

function makeTableServices(data, columns) {
    if(data.length <= 0 ){
        return "";
    }
    return {
        table: {
            heights: 25,
            widths: [50, 285, 70, 75],
            headerRows: 1,
            body: buildTableServices(data, columns)
        },
        margin: [0,110,0,0],

    };
}


function buildTableStock(data, columns) {

    var body = [];
    if(data.length <= 0 ){
        return 0;
    }
    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });
    return body;
}

function makeTableStock(data, columns) {
    if(data.length <= 0 ){
        return "";
    }
    return {
        table: {
            heights: 25,
            widths: [50, 285, 70, 75],
            headerRows: 1,
            body: buildTableStock(data, columns)
        },
        margin: [0,-1,0,0],

    };
}

const form = document.getElementById('invoice_form');
$('a.export').click(function() {

    var invoice_id = $(this).closest('tr').attr('data-q_id');
    var current_invoice = invoices.filter(function(invoice) {
        return invoice.invoice_id == invoice_id;
    });

    const invoice_name = current_invoice[0].invoice_name;
    const invoice_date = current_invoice[0].invoice_date;
    const invoice_valid_for = current_invoice[0].invoice_valid_for;
    const vat = current_invoice[0].vat;
    const discount = current_invoice[0].discount;
    const customer_name = current_invoice[0].customer_name;
    const customer_address = current_invoice[0].customer_address;
    var cityzip = ordcity + ", " + ordzip;

    var subTotal = 0;

    var tableDataServices = [];
    var tableDataStock = [];
    var currentPage = 0;

    current_invoice[0].invoice_services.forEach(function(service) {
        tableDataServices.push({
            "qty": service.service_quantity,
            "description": service.service_name,
            "unit-price": service.service_price,
            "amount": parseFloat(service.service_price) * parseInt(service.service_quantity),
        });
    });

    current_invoice[0].invoice_stock.forEach(function(stock) {
        tableDataStock.push({
            "qty": stock.stock_quantity,
            "name": stock.stock_name,
            "unit-price": stock.stock_price,
            "amount": parseFloat(stock.stock_price) * parseInt(stock.stock_quantity),
        });
    });
   
    var subTotal = 0; 
    tableDataServices.forEach(function(row) {
        subTotal += parseFloat(row.amount);
    });
    tableDataStock.forEach(function(row) {
        subTotal += parseFloat(row.amount);
    });

    var discAmount = subTotal * parseFloat(current_invoice[0].invoice_discount)/100;

    var vatAmount = (subTotal - discAmount) * parseFloat(current_invoice[0].invoice_vat)/100;

    var total = (subTotal - discAmount + vatAmount).toFixed(2);

    var docDefinition = {
        content: [
            {
                columns: [
                    {
                        width: 450,
                        text: 'Ordinatio Gardening',
                        style: 'header',
                        fontSize: 24,
                        bold: true,
                    },
                    {
                        width: 100,
                        text: 'Invoice',
                        style: 'header',
                        fontSize: 24,
                        bold: true,
                    },
                ],
            },
            { text: ordaddress, margin: [1,10,0,0] },
            { text: cityzip, margin: [1,0,0,0] },
            {
                columns: [
                    {
                        width: 300,
                        text: 'Bill to:',
                        fontSize: 15,
                        bold: true,
                    },
                    {
                        width: 80,
                        text: 'Invoice Date',
                        fontSize: 15,
                        bold: true,
                    },
                    {
                        text: invoice_date,
                        fontSize: 12,
                        margin: [20,3,0,0],
                    },
                ],
                margin: [0,80,0,0],
            },
            {
                columns: [
                    {
                        text: customer_name.toString(),
                        fontSize: 12,
                    },
                ],
                margin: [0,8,0,0],
            },
            {
                columns: [
                    {
                        text: customer_address.toString(),
                        fontSize: 12,
                    },
                ],
            },
            makeTableServices(tableDataServices, ['qty', 'description', 'unit-price', 'amount']),
            makeTableStock(tableDataStock, ['qty', 'name', 'unit-price', 'amount']),        
   
            { 
                table :{ 
                    heights: 25,
                    widths: [70, 75],
                    body:[
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Subtotal',
                            },
                            { 
                                text: subTotal,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Discount '+ current_invoice[0].invoice_discount + '%',
                            },
                            { 
                                text: discAmount,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Vat '+ current_invoice[0].invoice_vat + '%',
                            },
                            { 
                                text: vatAmount,
                            }
                        ],
                        [ 
                            { 
                                border: true,
                                bold: true,
                                fontSize: 10,
                                text: 'Total',
                            },
                            { 
                                text: '€' + total,
                            }
                        ],
                    ],
                },
                margin: [353,-1,0,0],
            },
            {
                bold: true,
                fontSize: 15,
                margin: [0,155,0,0],
                text: 'Terms and conditions',
            },
            {
                margin: [0,10,0,0],
                fontSize: 12,
                text: 'Payment is due within ' + invoice_valid_for + ' days',
            },
            {
                fontSize: 12,
                text: 'Please make checks payable to ' + "Ordinatio Gardening",
            },

        ]
    };
    pdfMake.createPdf(docDefinition).open();
});