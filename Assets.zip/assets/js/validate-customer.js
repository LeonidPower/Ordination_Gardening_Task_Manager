$('#inputFirstName').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /\d/; // Regular expression pattern to match any digit
    
    if (numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\d/g, '')); // Remove any digit characters
    }
    if ($(this).val().length > 15) {
        $(this).val($(this).val().slice(0, 15)); // Truncate input to 10 characters
    }
})

$('#inputLastName').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /\d/; // Regular expression pattern to match any digit
    
    if (numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\d/g, '')); // Remove any digit characters
    }
    if ($(this).val().length > 25) {
        $(this).val($(this).val().slice(0, 25)); // Truncate input to 10 characters
    }
})

$('#inputCompanyName').on('input', function() {
    if ($(this).val().length > 20) {
        $(this).val($(this).val().slice(0, 20)); // Truncate input to 10 characters
    }
})

$('#inputPhoneNumber').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /^\d+$/;
    if (!numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\D/g, '')); // Remove non-digit characters
    }
    if ($(this).val().length > 10) {
        $(this).val($(this).val().slice(0, 10)); // Truncate input to 10 characters
    }
})

$('#inputAddress').on('input', function() {
    if ($(this).val().length > 50) {
        $(this).val($(this).val().slice(0, 50)); // Truncate input to 10 characters
    }
})
