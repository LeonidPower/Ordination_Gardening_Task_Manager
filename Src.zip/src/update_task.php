<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    if (isset($_POST['project']) && isset($_POST['assignee']) && isset($_POST['task-name']) && isset($_POST['task-start-date']) && isset($_POST['task-end-date']) && isset($_POST['task_id_edit']))
    {
        $task_id = validate($_POST['task_id_edit']);
        $project_id = validate($_POST['project']);
        $task_name = validate($_POST['task-name']);
        $task_end_date = validate($_POST['task-end-date']);
        $task_start_date = validate($_POST['task-start-date']);

        $assignee  = $_POST['assignee'];

        $task_status = validate($_POST['task_status']) == 'on' ? 1 : 0;

        $task_description = isset($_POST['description']) ? validate($_POST['description']) : "";

        $i = 0 ;
        $assignees_id_array = array();
        $assignees_array = array();

    }
    else{
        header("Location: task.php?error=Some mandatory fields are empty "); //fix this later
        exit();
    }

    if(empty($project_id)){ 
        header("Location: task.php?error=Project cannot be empty");
        exit();
    }else if(empty($task_name)){ 
        header("Location: task.php?error=Task name cannot be empty");
        exit();
    }else if(empty($task_start_date)){
        header("Location: task.php?error=Task start date cannot be empty");
        exit();
    }else if(empty($task_end_date)){
        header("Location: task.php?error=Task end date cannot be empty");
        exit();
    }else if(empty($assignee)){
        header("Location: task.php?error=Assignee cannot be empty");
        exit();
    }else{
        while(!empty($assignee[$i])){
            array_push($assignees_array , validate($assignee[$i]));
            $i++;
        }
        //check the dates 
        $sql_get_project = "SELECT start_date, end_date FROM project WHERE project_id = ?";
        $stmt = $conn->prepare($sql_get_project);
        $stmt->bind_param("i", $project_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $row = $result->fetch_assoc();
        $project_start_date = $row['start_date'];
        $project_end_date = $row['end_date'];
        
        if ($project_start_date > $task_start_date && $project_end_date < $task_end_date) {
            header("Location: task.php?error=Task dates are not within the project dates");
            exit();
        }
        
        if ($task_start_date > $task_end_date || $task_end_date < $task_start_date) {
            header("Location: task.php?error=Task dates are not valid");
            exit();
        }
        
        $assignees_array = implode("','", $assignees_array);
        
        $sql_find_assignees = "SELECT user_id FROM user WHERE hash IN (?)";
        $stmt = $conn->prepare($sql_find_assignees);
        $stmt->bind_param("s", $assignees_array);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                array_push($assignees_id_array, $row['user_id']);
            }
        } else {
            header("Location: task.php?error=Assignee/s don't exist");
            exit();
        }
        
        $sql_update_task = "UPDATE task SET name = ?, start_date_time = ?, end_date_time = ?, description = ?, project_id = ?, status = ? WHERE task_id = ?";
        $stmt = $conn->prepare($sql_update_task);
        $stmt->bind_param("sssssii", $task_name, $task_start_date, $task_end_date, $task_description, $project_id, $task_status, $task_id);
        $stmt->execute();
        
        $sql_delete_assignee = "DELETE FROM task_assignees WHERE task_id = ?";
        $stmt = $conn->prepare($sql_delete_assignee);
        $stmt->bind_param("i", $task_id);
        $stmt->execute();
        
        $sql_insert_assignees = "INSERT INTO task_assignees (task_id, assignee_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql_insert_assignees);
        $stmt->bind_param("ii", $task_id, $as_id);
        
        foreach ($assignees_id_array as $as_id) {
            $stmt->execute();
        }
        
    
        header("Location: task.php?success=Task updated successfully");
        exit();
    }
?>