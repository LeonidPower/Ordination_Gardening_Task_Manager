<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['first_name', 'last_name', 'email'];
    
    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);

        $company_name = isset($_POST['company_name']) ? validate($_POST['company_name']) : "";
        $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";
        $address = isset($_POST['address']) ? validate($_POST['address']) : "";
    }
    else{
        include "../admin/customer_form.php";
        exit();
    }

    
    $errorMessages = [];

    if(empty($firstname)){ 
        $errorMessages[] = "Firstname";
    }
    if(empty($lastname)){ 
        $errorMessages[] = "Lastname";
    }
    if(empty($email)){ 
        $errorMessages[] = "Email";
    }

    if (!empty($errorMessages)) {
        $errorMessage = implode(", ", $errorMessages) . " is empty";
        header("Location:  customer_form_intermediate.php?error=$errorMessage");
        exit();
    }
    else{

        $sql = "SELECT * FROM customer WHERE email=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            $sql = "INSERT INTO customer (name, surname, email, phone, company, address) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $firstname, $lastname, $email, $phone, $company_name, $address);
            $stmt->execute();

            $new_customer_id = $stmt->insert_id;
            
            $customer_hash = md5($new_customer_id);
            $sql_insert_hash = "UPDATE customer SET hash=? WHERE customer_id=?";
            $stmt = $conn->prepare($sql_insert_hash);
            $stmt->bind_param("si", $customer_hash, $new_customer_id);
            $stmt->execute();
            header("Location: customer.php?success=New customer created");
        }
        else{ 
            header("Location: customer_form_intermediate.php?error=email is already used");
            exit();
        }
    }
?>