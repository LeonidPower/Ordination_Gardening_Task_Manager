
var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

var month_text = document.getElementById("month-name");
var year_text = document.getElementById("year");

const container = document.getElementById('calendar');
const calendar = new tui.Calendar(container, 
{
  defaultView: 'month',
  isReadOnly: true,
  template: {
    titlePlaceholder() {
      return 'Title';
    },
  },
  timezone: {
    zones: [
      {
        timezoneName: 'Europe/Nicosia',
        displayLabel: 'Cyprus',
      },
    ],
  },
  calendars: [
    {
      id: 'cal1',
      name: 'Schedule',
      backgroundColor: '#03bd9e',
    },
  ],
});
calendar.setOptions({
  useDetailPopup: true,
});
calendar.setTheme({
  month: {
    dayName: {
        backgroundColor: '#dee2e6',
    },
  },
});

year_text.innerHTML = calendar.getDate().getFullYear();
month_text.innerHTML = months[calendar.getDate().getMonth()];

var projects_id_json = JSON.parse(projects_id);
var projects_name_json = JSON.parse(projects_name);
var projects_start_json = JSON.parse(projects_start_date);
var projects_end_json = JSON.parse(projects_end_date);
var projects_status_json = JSON.parse(projects_status);

var project_supervisor_json = JSON.parse(project_supervisors);


var task_id_json = JSON.parse(tasks_id);
var task_name_json = JSON.parse(tasks_name);
var task_start_json = JSON.parse(tasks_start_date);
var task_end_json = JSON.parse(tasks_end_date);
var task_status_json = JSON.parse(tasks_status);
var task_project_id_json = JSON.parse(task_project_name);

var task_assignees_json = JSON.parse(task_assignees);

var red = 90;
var green = 70;
var blue = 50;
var color = `rgb(${red}, ${green}, ${blue})`;
//convert this 03bd9e to rgb

for (var i = 0; i < projects_id_json.length; i++) {
  calendar.createEvents([
    {
      id: 'event'+i,
      calendarId: 'cal1',
      isReadOnly: true,
      state:null,
      attendees: project_supervisor_json[projects_id_json[i]],
      backgroundColor: color,
      title: 'Start of Project: ' + projects_name_json[i],
      start: projects_start_json[i]+'T09:00:00',
      end: projects_start_json[i]+'T09:00:00',
    },
  ]);
  calendar.createEvents([
    {
      id: 'event'+i,
      calendarId: 'cal1',
      isReadOnly: true,
      state:null,
      backgroundColor: color,
      title: 'End of Project: ' + projects_name_json[i],
      start: projects_end_json[i]+'T09:00:00',
      end: projects_end_json[i]+'T09:00:00',
    },
  ]);
  red +=100;  green +=100;  blue +=100;
  color = `rgb(3, ${green}, ${blue})`;

  if(red > 255){
    red = 90;
  }
 if(green > 255){
    green = 70;
  }
  if(blue > 255){
    blue = 50;
  }
}

for (var i = 0; i < task_id_json.length; i++) {
    if(task_status_json[i] == "1"){
      calendar.createEvents([
      {
        id: 'event1',
        calendarId: 'cal1',
        isReadOnly: true,
        state:null,
        attendees : task_assignees_json[task_id_json[i]],
        backgroundColor: color,
        title: 'Start of Task: ' + task_name_json[i] + " in Project: " + task_project_id_json[i],
        start: task_start_json[i],
        end: task_end_json[i],
      },
    ]);
  }
}

var month_number = calendar.getDate().getMonth();
var year_number = calendar.getDate().getFullYear();

var month_nav = document.getElementById("month-nav");

var next_month = document.getElementById("next-month");
var previous_month = document.getElementById("previous-month");
var next_year = document.getElementById("next-year");
var previous_year = document.getElementById("previous-year");

var next_week = document.getElementById("next-week");
var previous_week = document.getElementById("previous-week");

var next_day = document.getElementById("next-day");
var previous_day = document.getElementById("previous-day");

var month = document.getElementById("month");
var week = document.getElementById("week");
var day = document.getElementById("day");


next_week.style.display = "none";
previous_week.style.display = "none";
next_day.style.display = "none";
previous_day.style.display = "none";


previous_month.addEventListener("click", e => {
  if(month_number == 0){
    month_number = 11;
    year_number--;
    year_text.innerHTML = year_number;
  }else if(month_number>0 && month_number<12){
    month_number--;
  }

  month_text.innerHTML = months[month_number];
  calendar.prev();
});

next_month.addEventListener("click", e => {
  if(month_number == 11){
    month_number = 0;
    year_number++;
    year_text.innerHTML = year_number;
  }else if(month_number<11 && month_number>=0){
    month_number++;
  }
  month_text.innerHTML = months[month_number];
  calendar.next();
});

previous_year.addEventListener("click", e => {
  calendar.move(-12);
  year_number--;
  year_text.innerHTML = year_number;
});

next_year.addEventListener("click", e => {
  calendar.move(12);
  year_number++;
  year_text.innerHTML = year_number;
});



next_day.addEventListener("click", e => {
  calendar.next();
});
previous_day.addEventListener("click", e => {
  calendar.prev();
});

next_week.addEventListener("click", e => {
  calendar.next();
});
previous_week.addEventListener("click", e => {
  calendar.prev();
});


month.addEventListener("click", e => {
  calendar.changeView('month');

  next_month.style.display = "block";
  previous_month.style.display = "block";
  next_year.style.display = "block";
  previous_year.style.display = "block";

  next_week.style.display = "none";
  previous_week.style.display = "none";

  next_day.style.display = "none";
  previous_day.style.display = "none";
  
});

week.addEventListener("click", e => {
  calendar.changeView('week');

  next_month.style.display = "none";
  previous_month.style.display = "none";
  next_year.style.display = "none";
  previous_year.style.display = "none";

  next_day.style.display = "none";
  previous_day.style.display = "none";

  next_week.style.display = "block";
  previous_week.style.display = "block";


});



day.addEventListener("click", e => {
  calendar.changeView('day');

  next_month.style.display = "none";
  previous_month.style.display = "none";
  next_year.style.display = "none";
  previous_year.style.display = "none";

  next_week.style.display = "none";
  previous_week.style.display = "none";

  next_day.style.display = "block";
  previous_day.style.display = "block";

});
