<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

if (isset($_POST['customer-options']))
{
    $cust_opt = validate($_POST['customer-options']);
    if ($cust_opt === 'Existing Customer')
    {
        if (isset($_POST['customer']))
        {
            $customer = validate($_POST['customer']);

            $can_proceed = true;
            $create_new_customer = false;
        }
        
    }
    elseif ($cust_opt === 'New Customer')
    {
        if (isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['email']) && isset($_POST['phone']))
        {
            $customer_name = validate($_POST['name']);
            $customer_surname = validate($_POST['surname']);
            $customer_email = validate($_POST['email']);
            $customer_phone = validate($_POST['phone']);

            $can_proceed = true;
            $create_new_customer = true;

        }
        $customer_company = isset($_POST['company_name']) ? validate($_POST['company_name']) : "";
        $customer_address = isset($_POST['address']) ? validate($_POST['address']) : "";
    }
    else
    {
        header("Location: invoice_form_intermediate.php?error=Customer option empty");
        exit();
    }

    if ($can_proceed)
    {
        if ($create_new_customer)
        {
            $sql_insert_customer = "INSERT INTO customer (name, surname, email, phone, company, address) 
                        VALUES ('$customer_name', '$customer_surname', '$customer_email', '$customer_phone', '$customer_company', '$customer_address');";
            $result = mysqli_query($conn, $sql_insert_customer);
            $new_customer_id = mysqli_insert_id($conn);
            
            $customer_hash = md5($new_customer_id);
            $sql_insert_hash = "UPDATE customer SET hash='$customer_hash' WHERE customer_id = '$new_customer_id';";
            $result = mysqli_query($conn, $sql_insert_hash);

        }
        //Here we can also check the result value if its 1 then the customer has been created else abort.
        if (isset($_POST['invoice-name']) && isset($_POST['invoice-date']) && isset($_POST['invoice-total']) && isset($_POST['invoice-valid-for']) && isset($_POST['invoice-vat']) && isset($_POST['invoice-discount']))
        {
            $i_name = validate($_POST['invoice-name']);
            $i_date = validate($_POST['invoice-date']);
            $i_total = validate($_POST['invoice-total']);
            $i_vat = validate($_POST['invoice-vat']);
            $i_discount = validate($_POST['invoice-discount']);
            $i_valid_for = validate($_POST['invoice-valid-for']);

            $table_data = json_decode($_POST['table_data'], true);

            if (isset($table_data['service_data']['services'][0]['name']) && isset($table_data['service_data']['services'][0]['quantity']) && isset($table_data['service_data']['services'][0]['price']) && isset($table_data['stock_data']['stock'][0]['item_id']) && isset($table_data['stock_data']['stock'][0]['quantity']))
            {

                $services_len = count($table_data['service_data']['services']);
                $stock_len = count($table_data['stock_data']['stock']);

                if($create_new_customer){ 
                    $sql_create_invoice = "INSERT INTO invoice (customer_id,name,status,date,total_price,vat,discount,valid_for) 
                                        VALUES ('$new_customer_id', '$q_name',1 ,'$q_date','$q_total','$q_vat', '$q_discount', '$q_valid_for');";
                    $result = mysqli_query($conn, $sql_create_invoice);
                }
                else{ 
                    $sql = "SELECT customer_id FROM customer WHERE hash='$customer'";
                    $result = mysqli_query($conn, $sql);
    
                    if (mysqli_num_rows($result) > 0)
                    {
                        while ($row = mysqli_fetch_assoc($result)){
                            $customer_id = $row['customer_id'];
                        }
                    }
                    $sql_create_invoice = "INSERT INTO invoice (customer_id, name, status, date, total_price, vat, discount, valid_for) 
                                        VALUES ('$customer_id', '$i_name',1 ,'$i_date','$i_total', '$i_vat', '$i_discount', '$i_valid_for');";
                    $result = mysqli_query($conn, $sql_create_invoice);
                }
                
                $invoice_id = mysqli_insert_id($conn);


                for ($i = 0;$i < $services_len;$i++)
                {
                    $s_name = validate($table_data['service_data']['services'][$i]['name']);
                    $s_desc = validate($table_data['service_data']['services'][$i]['description']);
                    $s_quant = validate($table_data['service_data']['services'][$i]['quantity']);
                    $s_price = validate($table_data['service_data']['services'][$i]['price']);

                    echo $s_name;

                    $sql_insert_service = "INSERT INTO invoice_services (invoice_id, name, description, quantity, price) 
                                        VALUES ('$invoice_id', '$s_name', '$s_desc', '$s_quant', '$s_price');";
                    $service_result = mysqli_query($conn, $sql_insert_service);
                }

                for ($j = 0; $j < $stock_len; $j++)
                {

                    $i_id = validate($table_data['stock_data']['stock'][$j]['item_id']);
                    $i_quant = validate($table_data['stock_data']['stock'][$j]['quantity']);

                    $sql_insert_qstock = "INSERT INTO invoice_stock (invoice_id, stock_item_id, quantity) 
                                        VALUES ('$invoice_id', '$i_id', '$i_quant');";
                    $service_result = mysqli_query($conn, $sql_insert_qstock);
                }
                
                header("Location: invoice.php?success=Invoice created successfully");
                exit();
            }
            else
            {
                header("Location: invoice_form_intermediate.php?error=ServiceStock fields incomplete");
                exit();
            }
        }
        else
        {
            header("Location: invoice_form_intermediate.php?error=Invoice fields incomplete");
            exit();
        }
    }
    else
    {
        header("Location: invoice_form_intermediate.php?error=Customer field not set");
        exit();
    }
}
else
{
    header("Location: invoice_form_intermediate.php?error=Customer option empty");
    exit();
}


?>
