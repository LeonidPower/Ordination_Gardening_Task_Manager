<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['hash_edit'])){   
        
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);
        $hash = validate($_POST['hash_edit']);

        $admin = isset($_POST['admin']) ? true : false;
        $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";
        $address = isset($_POST['address']) ? validate($_POST['address']) : "";
        $position = isset($_POST['position']) ? validate($_POST['position']) : null;
    
    }
    else{
        include "../admin/user.php";
        exit();
    }    

    if(empty($hash)){ 
        header("Location: user.php?error=Empty fields found");
        exit();
      }
    if(empty($firstname)){ 
      header("Location: user.php?error=Firstname is empty");
      exit();
    }
    elseif(empty($lastname)){ 
        header("Location: user.php?error=Lastname is empty");
        exit();
    }
    elseif(empty($email)){ 
        header("Location: user.php?error=Email is empty");
        exit();
    }
    else{
        $sql_get_position_id = "SELECT position_id FROM position WHERE name = ? LIMIT 1;";
        $stmt = $conn->prepare($sql_get_position_id);
        $stmt->bind_param("s", $position);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $row = $result->fetch_assoc();
        $position_id = $row['position_id'];
        
        $sql = "SELECT * FROM user WHERE email = ? AND hash != ?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $hash);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            $sql = "UPDATE user 
                    SET name = ?, surname = ?, phone = ?, address = ?, email = ?, position_id_users = ?, is_admin = ?
                    WHERE hash = ?;";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssis", $firstname, $lastname, $phone, $address, $email, $position_id, $admin, $hash);
            $stmt->execute();
        
            header("Location: user.php?success=User data updated");
        } else {
            header("Location: user.php?error=Email is already used");
            exit();
        }
    }
?>