<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

        $services_data = $_POST['services_data']; 
        $services_json = json_decode(($services_data) , true);

        if(isset($services_json['quote_id']))
        {
            if(empty($services_json['quote_id'])){ 
                header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Quote not selected");
                exit();
            }

            $quote_id = validate($services_json['quote_id']);
            $services = $services_json['services'];
            
            if (isset($services[0]['name']) && isset($services[0]['quantity'])&& isset($services[0]['price'])) // We need atleast one services and the first one is mandatory
            {
                echo "here";
                if(empty($services[0]['name']))
                {
                    header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Name field empty");
                    exit();
                }else if(empty($services[0]['quantity']))
                {
                    header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Quantity field is empty");
                    exit();

                }else if(empty($services[0]['price']))
                {
                    header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Price field is empty");
                    exit();
                }
                
                $services_len = count($services);
                $sql_delete_services = "DELETE FROM quote_services WHERE quote_id = ?;";
                $stmt_delete = $conn->prepare($sql_delete_services);

                $stmt_delete->bind_param("i", $quote_id);
                $stmt_delete->execute();

                for ($i = 0;$i <$services_len;$i++)
                {
                    $item_name = validate($services[$i]['name']);
                    $item_desc = validate($services[$i]['description']);
                    $item_quant = validate($services[$i]['quantity']);
                    $item_price = validate($services[$i]['price']);

                    $sql_insert_service = "INSERT INTO quote_services (quote_id, name, description, quantity, price) 
                           VALUES (?, ?, ?, ?, ?);";
                    $stmt_insert = $conn->prepare($sql_insert_service);

                    // Bind parameters
                    $stmt_insert->bind_param("issss", $quote_id, $item_name, $item_desc, $item_quant, $item_price);

                    $stmt_insert->execute();
                }
                header("Location: edit_i_tables_intermediate.php?id=$quote_id?success=Services updated successfully");
                exit();
            }
            else
            {
                header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Some mandatory fields are not set");
                exit();
            }
        }
        else
        {
            header("Location: edit_i_tables_intermediate.php?id=$quote_id?error=Quote ID not set");
            exit();
        }
?>
