<?php    
    require 'check_login.php';
    require_once '../commons/dashboard.php';
    exit();
?>