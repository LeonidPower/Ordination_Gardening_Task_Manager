<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="../assets/css/tasks.css" rel="stylesheet" />
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />

        <script src="../assets/js/scripts.js"></script>

        <title>Tasks - Ordinatio Manager</title>
    </head>
    <?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">    
                <h1 class="inline"><i class="bi bi-check-all"></i>Tasks</h1>
                <?php 
                    if (isset($_GET['error'])){
                    echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                        <button class="close-btn mb-1">&times;</button>
                    </div>';
                    }
                    elseif (isset($_GET['success'])){
                        echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';
                    }
                ?>
                <div class="table-size-1 mt-4">
                <div class="row d-flex justify-items-center">
                    <div class="col-md-3">
                        <div class="form-check">
                            <input class="form-check-input" id="filter_by_status_active" name="filter_status_active" type="checkbox" value="1" id="flexCheckDefault">
                            <label class="form-check-label" for="flexCheckDefault">
                                Show Active Tasks
                            </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-check">
                            <input class="form-check-input" id="filter_by_status_finished" name="filter_status_finished" type="checkbox" value="1" id="flexCheckDefault">
                            <label class="form-check-label" for="flexCheckDefault">
                                Show Finished Tasks
                            </label>
                        </div>
                    </div>
                </div>
                <p></p>
                    <table id="tasks-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <?php if ($_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2' || $_SESSION['is_admin'] ==='1' ){
                                   echo '<th>Select</th>';
                                } ?>
                                <th>ID</th>
                                <th>Task Name</th>
                                <th>Start Day & Time</th>
                                <th>End Day & Time</th>
                                <th>Project</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <script>
                                const assignees = new Map() ; 
                                var assignees_arr = []; 

                            </script>
                            <?php 
                                require '../src/fetch_tasks.php'; 
                                
                                foreach ($tasks as $t){
                                    echo"<script>
                                    </script>";

                                    echo "<tr data-t_id='$t->task_id' data-t_name='$t->task_name' data-t_description='$t->task_description' data-t_s_d='$t->task_start_date' 
                                          data-t_e_d='$t->task_end_date' data-t_status='$t->task_status'  data-t_project='$t->task_project_id'>";
                                    if ($_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2' || $_SESSION['is_admin'] ==='1' ){
                                      echo "<td style='text-align: center;width:40px;'><input class='mt-1 form-check-input' name='task_select' type='radio' style='height:20px;width:20px'></td>";
                                    }
                                    echo "<td>" . htmlspecialchars($t->task_id) . "</td>";
                                    echo "<td>" . htmlspecialchars($t->task_name) . "</td>";
                                    echo "<td>" . htmlspecialchars($t->task_start_date) . "</td>";
                                    echo "<td>" . htmlspecialchars($t->task_end_date) . "</td>";
                                    echo "<td>" . htmlspecialchars($t->task_project_name) . "</td>";

                                    if($t->task_end_date >= strtotime(date("Y-m-d H:i:s")) && !($t->task_status)){
                                        echo "<td class='d-flex justify-content-center'><p hidden>1</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #1dff1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></i></td>";
                                    }
                                    else{ 
                                        echo "<td class='d-flex justify-content-center'><p hidden>0</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #ff1d1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></td>";
                                    }
                                    foreach($t->task_assignees as $as){
                                        $as = htmlspecialchars($as);
                                        echo "<script>assignees_arr.push('$as');</script>";
                                    }
                                    
                                    echo "<script>assignees.set('$t->task_id', assignees_arr);</script>";
                                    echo "<script>assignees_arr = [];</script>";

                                    echo "</tr>";
                                }
                                
                            ?>
                        </tbody>
                    </table>
                    <?php if ($_SESSION['position']['create_tasks'] === '1' || $_SESSION['position']['create_tasks'] === '2' || $_SESSION['is_admin'] ==='1' ){ ?>
                    <button id="edit_task_btn" type="button" class="btn btn-primary btns" data-bs-toggle="modal" data-bs-target="#edit_task" disabled>
                        Edit
                    </button>
                    <button type="submit" id="delete_task_btn" class="btn btn-danger btns ms-2" data-bs-toggle="modal" data-bs-target="#delete-task-modal" disabled>Delete</button>
                    <div id="delete-task-modal" class="modal fade" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                    <h4 class="modal-title"><i class="bi bi-trash-fill"></i> Delete Task</h4>
                                <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="../src/delete_task.php" method="post" id="register_form" novalidate>
                                <div class="modal-body">
                                <p class="h5">
                                    <input name="id_del" id="inputID_del" required hidden/>
                                    Are you sure you want to delete this task?
                                </p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-danger btns">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="edit_task" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content" style="padding: 15px;">
                                <div class="modal-header" >
                                    <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-check-all"></i> Edit Task</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form id="register_form" method="POST" action="update_task.php" novalidate>
                                <input name="task_id_edit" id="inputID_edit" required hidden/>
                                    <div class='ms-3 mt-3 me-3 mb-3'>
                                       <div class="row mb-1">
                                          <div class="col-md-6">
                                             <div class="form-floating mb-1 mbmd-0"> 
                                                <script>
                                                    const project_dates = new Map();
                                                 </script>                 
                                                <?php
                                                    require_once '../src/db_connect.php';
                                                    require_once '../src/objects.php';
                                                   
                                                    $sql_customer = "SELECT * FROM project";
                                                    $stmt = $conn->prepare($sql_customer);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();

                                                    $customer_info = array();
                                                    $i = 0;
                                                   
                                                    if ($result->num_rows > 0) {
         
                                                      echo '    <p>Project<span class="required-field"> *</span></p>
                                                                <select style="width:100%;" id="select-project-edit" name="project" autocomplete="off" placeholder="Select Project" required>
                                                                <option value="" selected disabled>Select Project</option>';
                                                            
                                                            while($row = $result->fetch_assoc()){
                                                               $start_date = $row['start_date'];
                                                               $end_date = $row['end_date'];
                                                               $project_id = $row['project_id'];
                                                               
                                                               echo "<script>
                                                                    var p_start_date='$start_date';
                                                                    var p_end_date='$end_date';
                                                                    
                                                                    project_dates.set($project_id, [p_start_date, p_end_date]);
                                                                </script>";

                                                               echo "<option data-p_start_date='$start_date' data-p_end_date='$end_date' value='$project_id'>" . $row['name'] . " (" . $start_date ." to " . $end_date .")" . "</option>";
                                                               $i++;
                                                            }
                                                      echo '</select>';      
                                                   }  
                                                   ?>
                                             </div>
                                          </div>
                                          <div class="col-md-6">
                                             <div class="form-floating mb-3 mbmd-0">
                                                <?php
                                                   require_once '../src/db_connect.php';
                                                   require_once '../src/objects.php';
                                                   require_once '../src/check_login.php';
                                                   
                                                    $sql_user = "SELECT user.name AS u_name, user.surname AS u_surname, user.hash AS u_hash FROM user";
                                                    $stmt = $conn->prepare($sql_user);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();      
                                                   
                                                   if (mysqli_num_rows($result) > 0) {
                                                         echo ' <p>Assignees<span class="required-field"> *</span></p>
                                                                <select style="width:100%" class="form-control h-100" id="select-assignees" name="assignee[]" multiple autocomplete="off" placeholder="Assignee/s" multiple required>';
                                                         
                                                            while($row = $result->fetch_assoc()){
                                                               $u_hash = $row['u_hash'];
         
                                                               if($_SESSION['position']['create_tasks'] == 1){
                                                                  if($_SESSION['user_hash'] == $u_hash){
                                                                     echo "<option value='$u_hash'>" . $row['u_name'] .' '. $row['u_surname'] . "</option>";
                                                                  }
                                                               }else{ 
                                                                  echo "<option value='$u_hash'>" . $row['u_name'] .' '. $row['u_surname'] . "</option>";
                                                               }
                                                            }
                                                      echo '</select>';      
                                                   
                                                   } 
                                                   ?>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="row mb-3">
                                          <div class="col-md-6">
                                             <div class="form-floating mb-3 mb-md-0">
                                                <input class="form-control" name="task-name" id="inputTaskName" type="text" placeholder="Task Name" required/>
                                                <label for="inputTaskName">Task Name<span class="required-field"> *</span></label>
                                             </div>
                                          </div>
                                          <div class="col-md-3">
                                             <div class="form-floating">
                                                <input class="form-control" name="task-start-date" id="inputTaskStartDate" placeholder="Start Date & Time" required>
                                                <label for="inputTaskStartDate">Start Date<span class="required-field"> *</span></label>
                                             </div>
                                          </div>
                                          <div class="col-md-3">
                                             <div class="form-floating">
                                                <input class="form-control" name="task-end-date" id="inputTaskEndDate" placeholder="End Date & Time" required>
                                                <label for="inputProjectEndDate">End Date<span class="required-field"> *</span></label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="row mb-3">
                                        <div class="col-md-6">
                                            <div class="form-check">
                                                <input name="task_status" class="form-check-input" type="checkbox" id="inputStatus" style="height:30px; width:30px;">
                                                <label class="form-check-label ms-2 mt-2" for="inputStatus">Finished</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6 d-flex justify-content-end">
                                            <a class="mb-3 mt-2" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" title="Start and End date of the task" data-bs-content="The start and end dates of a task should be within the range of the project's start and end dates">
                                                <i class="bi bi-info-circle-fill fa-lg"></i>
                                            </a>
                                        </div>
                                    </div>
                                       <div class="row mb-3">
                                          <div class="form-group mb-3">
                                             <textarea class="form-control" name="description" id="inputDescription" placeholder="Description" rows="7"></textarea>
                                          </div>
                                       </div>
                                       <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary btns">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                   <?php } ?>
                </div>
            </div>
        </main>
        <?php include '../commons/date_error_modals.html'; ?>
    </div>
<!-- --------------------------------------- End --------------------------------------- -->

        <script src="../assets/datatables/datatables.js"></script>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>


        <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

        <script src="../assets/js/task.js"></script>
        <script src="../assets/js/validate-tasks.js"></script>
    </body>
</html>
