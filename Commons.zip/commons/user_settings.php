<!DOCTYPE html>
<html lang="en">
    <?php include '../commons/base.php' ?>
    <head>
        <link href="../assets/css/user_settings.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
        <title>User Settings - Ordinatio Garden Industry</title>
    </head>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class=""><i class="bi bi-gear-wide"></i> Settings</h1>
                <div class="row ms-3 mt-3">
                    <div class="col-md-7">
                        <?php 
                            if (isset($_GET['error'])){
                                echo '<div class="p-error mb-2"><span>' . $_GET['error'] . '</span>
                                    <button class="close-btn">&times;</button>
                                </div>';
                            }
                            elseif (isset($_GET['success'])){
                                echo '<div class="p-success mb-2"><span>' . $_GET['success'] . '</span>
                                    <button class="close-btn">&times;</button>
                                </div>';
                            }
                        ?>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Change information
                                </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <form method="POST" action="change_information.php">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="first_name" id="inputFirstName" type="text" placeholder="Enter your first name" required/>
                                                        <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="last_name" id="inputLastName" type="text" placeholder="Enter your last name" required/>
                                                        <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <input class="form-control" name="phone" id="inputPhoneNumber" type="tel" placeholder="Phone Number"/>
                                                        <label for="inputPhoneNumber">Phone Number</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                        <label for="inputAddress">Address</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-4 mb-0 d-flex justify-content-end">
                                                <button class="btn btn-primary btn-block" type="submit" id="register_button">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Change email
                                </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <form method="POST" action="change_email.php">
                                            <div class="form-floating mb-3">
                                                <p class="form-control" name="email" id="displayEmail"></p>
                                                <label for="displayEmail">Current Email</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" required/>
                                                <label for="inputEmail">New Email Address <span class="required-field">*</span></label>
                                            </div>
                                            <div class="mt-4 mb-0 d-flex justify-content-end">
                                                <button class="btn btn-primary btn-block" type="submit" id="register_button">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Change password
                                </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <form method="POST" action="change_password.php">
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="old_pass" id="inputPassword" type="password" placeholder="Create a password" required/>
                                                        <label for="inputPassword">Old Password <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="new_pass" type="password" placeholder="Create a password" required/>
                                                        <label for="inputPassword">New Password <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" name="pass_confirm" type="password" placeholder="Confirm password" required/>
                                                        <label for="inputPasswordConfirm">Confirm Password <span class="required-field">*</span></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-end">
                                                <button class="btn btn-primary btn-block" type="submit" id="register_button">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
        <script>
            const first_name = "<?php echo $_SESSION['name'] ?>";
            const last_name = "<?php echo $_SESSION['surname'] ?>";
            const phone = "<?php echo $_SESSION['phone'] ?>";
            const address = "<?php echo $_SESSION['address'] ?>";
            const email = "<?php echo $_SESSION['email'] ?>";

        </script>
        <script src="../assets/js/user_settings.js"></script>
    </body>
</html>