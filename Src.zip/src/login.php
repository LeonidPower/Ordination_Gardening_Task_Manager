<?php
    session_start();

    require "db_connect.php";
    require "mixins.php";
    
    if (isset($_SESSION['loggedin'])) {
        header("Location: dashboard.php");
        exit();
    }        

    if (isset($_POST['email']) && isset($_POST['pass'])) {

        $email = validate($_POST['email']);
        $password = md5(validate($_POST['pass']));
        
    }else{ 
        include  "../commons/login.html";
        exit();
    }

    if (empty($email)) {
        header("Location: login.php?error=Email is required");
        exit();

    }else if(empty($password)){
        header("Location: login.php?error=Password is required");
        exit();
    }
    else{   
            $sql = "SELECT user.password AS u_password, user.email AS u_email, user.hash AS u_hash,
                            user.user_id AS u_id, user.name AS u_name, user.surname AS u_surname, user.email AS u_email, user.phone AS u_phone, 
                            user.address AS u_address, user.is_admin AS u_is_admin, position.name AS p_name, position_atributes.view_tasks AS v_t, 
                            position_atributes.view_projects AS v_p, position_atributes.view_users AS v_u, position_atributes.view_invoices AS v_i,
                            position_atributes.view_quotes AS v_q, position_atributes.view_customers AS v_c, position_atributes.view_stock AS v_s, 
                            position_atributes.create_tasks AS c_t,position_atributes.create_projects AS c_p, position_atributes.create_users AS c_u,
                            position_atributes.create_quotes AS c_q, position_atributes.create_invoices AS c_i, position_atributes.create_customers AS c_c, 
                            position_atributes.create_stock AS c_s, position_atributes.super_admin AS s_a
                            FROM user
                            JOIN position ON position.position_id = user.position_id_users
                            JOIN position_atributes ON position_atributes.position_id = position.position_id
                            WHERE user.email='$email' AND user.password='$password';";

            $result = mysqli_query($conn, $sql);

           

            if (mysqli_num_rows($result) === 1) {

                $row = mysqli_fetch_assoc($result);
                if ($row['u_email'] === $email && $row['u_password'] === $password) {

                    $_SESSION['loggedin'] = True;
                    $_SESSION['name'] = $row['u_name'];
                    $_SESSION['surname'] = $row['u_surname'];
                    $_SESSION['email'] = $row['u_email'];
                    $_SESSION['phone'] = $row['u_phone'];
                    $_SESSION['address'] = $row['u_address'];
                    $_SESSION['is_admin'] = $row['u_is_admin'];
                    $_SESSION['user_id'] = $row['u_id'];
                    $_SESSION['user_hash'] = $row['u_hash'];
                    $_SESSION['password'] = $row['u_password'];
                    $_SESSION['position'] = array('name' => $row['p_name'] , 'view_tasks' => $row['v_t'] , 'view_projects' => $row['v_p'],
                                                    'view_tasks' => $row['v_t'] , 'view_users' => $row['v_u'], 'view_invoices' => $row['v_i'], 
                                                    'view_quotes' => $row['v_q'] , 'view_customers' => $row['v_c'], 'view_stock' => $row['v_s'],
                                                    'create_tasks' => $row['c_t'] , 'create_projects' => $row['c_p'], 'create_users' => $row['c_u'] , 
                                                    'create_quotes' => $row['c_q'] , 'create_invoices' => $row['c_i'], 'create_customers' => $row['c_c'],
                                                    'create_stock' => $row['c_s']);

                    
                    header("Location: dashboard.php");
                    exit();
                }else{

                    header("Location:login.php?error=Incorect email or password");
                    exit();
                }
            }else{
                header("Location: login.php?error=Incorect email or password");
                exit();
            }
        }   
?>
