var projects_table = $('#projects-table').DataTable();

const table = document.getElementById("projects-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_project_btn').removeAttr('disabled');
            $('#delete_project_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_project_btn').prop('disabled');
            $('#edit_project_btn').prop('disabled')
        }

    })
});

$('#edit_project_btn').click(function(){
    if (checkedRow) {

        const row = $(checkedRow);
        const Id = row.attr('data-p_id');
        const p_name = row.attr('data-p_name');
        const p_address = row.attr('data-p_address');
        const p_num = row.attr('data-p_num');
        const p_city = row.attr('data-p_city');
        const p_post = row.attr('data-p_post');
        const p_cust = row.attr('data-p_customer');
        const p_s_date = row.attr('data-p_start_date');
        const p_e_date = row.attr('data-p_end_date');
        const p_status = row.find("td:nth-child(8)").attr('data-p_status');
        const p_description = row.attr('data-p_description');

        $("#inputID_edit").val(Id);
        $("#inputProjectName").val(p_name);
        $("#inputAddress").val(p_address);
        $("#inputCity").val(p_city);
        $("#inputNumber").val(p_num);
        $("#inputPost").val(p_post);
        $("#inputProjectStartDate").val(p_s_date);
        $("#inputProjectEndDate").val(p_e_date);      
        $("#inputDescription").val(p_description);

        if(p_status == 1){ 
            $("#inputStatus").prop('checked' ,true);

        }else{ 
            $("#inputStatus").prop('checked' ,false);
        }  
        customer_select.setValue(p_cust);
        
        var supervisors = [];
        row.find("td:nth-child(9) a").each(function(){
            supervisors.push($(this).attr('data-p_supervisor'));
        })
        
        $("#select-supervisor").children('option').each(function(){ 
            if(supervisors.includes($(this).val())){
                $(this).attr("selected" , true);
            }
            else{ 
                $(this).attr("selected" , false);
            }
        });   
    }
})

$('#delete_project_btn').click(()=>{ 
    const row = $(checkedRow);
    const Id = row.attr('data-p_id');

    $("#inputID_del").val(Id);
})

var customer_select = new TomSelect('#select-customer-data',{
    create: false,
    allowEmptyOption: false,
    sortField: {
        field: 'text',
        direction: 'asc'
    }
});

$('.customers').click(function(){

        const c_name = $(this).attr('data-c_name');
        const c_surname = $(this).attr('data-c_surname');
        const c_email = $(this).attr('data-c_email');
        const c_phone= $(this).attr('data-c_phone');
        const c_company= $(this).attr('data-c_company');
        const c_address = $(this).attr('data-c_address');
    
        $("#cname").html("<span style='font-weight: bold;'> Name: </span>"+c_name);
        $("#csurname").html("<span style='font-weight: bold;'>Surname: </span>"+c_surname);
        $("#cemail").html("<span style='font-weight: bold;'>Email: </span>"+c_email);
        $("#cphone").html("<span style='font-weight: bold;'>Phone Number: </span>"+c_phone);
        $("#ccompany").html("<span style='font-weight: bold;'>Company: </span>"+c_company);
        $("#caddress").html("<span style='font-weight: bold;'>Address </span>"+c_address);    
});

$('#filter_by_status_active').on('click', function() {
    var radioValue = $("input[name='filter_status_active']:checked").val();
    if(radioValue){
        $('#filter_by_status_finished').prop('disabled', true);
        projects_table.columns( 7 )
        .search('1')
        .draw();
    }else{
        $('#filter_by_status_finished').prop('disabled', false);
        projects_table.columns( 7 )
        .search('')
        .draw();
    }
});

$('#filter_by_status_finished').on('click', function() {
    var radioValue = $("input[name='filter_status_finished']:checked").val();
    if(radioValue){
        $('#filter_by_status_active').prop('disabled', true);
        projects_table.columns( 7 )
        .search('0')
        .draw();
    }else{
        $('#filter_by_status_active').prop('disabled', false);
        projects_table.columns( 7 )
        .search('')
        .draw();
    }
}); 