<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['email'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $email = validate($_POST['email']);
        $hash = $_SESSION['user_hash'];
    }
    else{
        include "../commons/user_settings.php";
        exit();
    }
    
    $errorMessages = [];

    if (empty($email)) {
        $errorMessages[] = "Email";
    }
    if (empty($hash)) {
        header("Location: ../commons/user_settings.php?error=Session error please login again");
        exit();
    }

    if (!empty($errorMessages)) {
        $errorMessage = implode(", ", $errorMessages) . " is empty";
        header("Location: ../admin/manage_employees.php?error=$errorMessage");
        exit();
    }else{ 
        try{ 
            $sql = "SELECT * FROM user WHERE email=? AND hash!=? ;";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $email , $hash);
            $stmt->execute();
            $result = $stmt->get_result();

            if (!mysqli_num_rows($result)) { 
                $sql= "UPDATE user SET email=? WHERE hash=?;";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $email , $hash);
                $stmt->execute();

                require 'fetch_new_session.php';
                header("Location: user_settings.php?success=Email changed");
                exit();
            }
            else{ 
                header("Location: user_settings.php?error=Email is already used");
                exit();
            }
        }
        catch(Exception $e){
            header("Location: user_settings.php?error=Email is already used");
            exit();
        }    
    }
?>