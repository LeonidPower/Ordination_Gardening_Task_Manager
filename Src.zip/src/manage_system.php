<?php
    require 'check_login.php';
    if($_SESSION['is_admin'] === '1'){ 
        require_once '../admin/manage_system.php';
    }
    else{ 
        header('Location: dashboard.php');
    }
    exit();
?>