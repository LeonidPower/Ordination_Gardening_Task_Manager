<?php
    require 'check_login.php';

    if($_SESSION['position']['create_quotes'] === '0' && !$_SESSION['is_admin'] === '1'){ 
        header('Location: dashboard.php');
        exit();
    }else{
        require_once 'fetch_quote.php';
        require_once '../admin/edit_quote_services.php';
        exit();
    }
?>