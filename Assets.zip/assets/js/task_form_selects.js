// //Tom Selects
new TomSelect('#select-project',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});

new TomSelect('#select-assignees',{
	create: false,
	maxItems: 10,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});