<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['id_del'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $id = validate($_POST['id_del']);
    }
    else{
        include "../commons/task.php";
        exit();
    }

    if(empty($id)){
        header("Location: ../src/task.php?error=Task not found");
        exit();
    }else{ 
        $sql= "DELETE FROM task WHERE task_id=?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        header("Location: ../src/task.php?success=Task deleted");
    }

    $conn->close();

?>