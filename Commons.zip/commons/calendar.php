<!DOCTYPE html>
<html lang="en">
    <?php include 'base.php' ?>
    <head>
        <link href="../assets/css/calendar.css" rel="stylesheet" />
        <!-- <link rel="stylesheet" type="text/css" href="../assets/tui-calendar/tui-calendar.css" />
        <link rel="stylesheet" type="text/css" href="../assets/tui-calendar/tui-date-picker.css" />
        <link rel="stylesheet" type="text/css" href="../assets/tui-calendar/tui-time-picker.css" /> -->

        <link rel="stylesheet" href="https://uicdn.toast.com/calendar/latest/toastui-calendar.min.css" />
        <script src="https://uicdn.toast.com/calendar/latest/toastui-calendar.min.js"></script>
        <title>Calendar - Ordinatio Garden Industry</title>
        
    </head>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <?php
                //get quotes for this month
                require "db_connect.php";
                //$query = "SELECT * FROM project";
                //$result = mysqli_query($conn, $query);

                $query = "SELECT * FROM project";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $result = $stmt->get_result();

                $project_supervisors = [];

                while ($row = mysqli_fetch_assoc($result)){
                    $current_project_id = $row['project_id'];

                    $projects_id[] = $row['project_id'];
                    $projects_name[] = $row['name'];
                    $projects_start_date[] = $row['start_date'];
                    $projects_end_date[] = $row['end_date'];
                    $projects_status[] = $row['status'];

                    //$get_supervisors = "SELECT user.name AS su_name FROM project_supervisors JOIN user ON project_supervisors.user_id = user.user_id WHERE project_id ='$row[project_id]'";
                    //$supervisors_responce = mysqli_query($conn, $get_supervisors);

                    $get_supervisors = "SELECT user.name AS su_name 
                    FROM project_supervisors 
                    JOIN user ON project_supervisors.user_id = user.user_id 
                    WHERE project_id = ?";
                    $stmt = $conn->prepare($get_supervisors);
                    $stmt->bind_param("s", $row['project_id']);
                    $stmt->execute();
                    $supervisors_responce = $stmt->get_result();

                    while ($row = mysqli_fetch_assoc($supervisors_responce)){
                        $supervisors_name[] = $row['su_name'];
                    }

                    $project_supervisors[$current_project_id] = $supervisors_name;
                    $supervisors_name = [];
                }
                
                //$query = "SELECT task.task_id AS t_id, task.name AS t_name, task.start_date_time AS t_start_date, 
                //task.end_date_time AS t_end_date, task.status AS t_status, project.name AS p_name FROM task
                // project ON task.project_id = project.project_id";
                //$result = mysqli_query($conn, $query);

                $query = "SELECT task.task_id AS t_id, task.name AS t_name, task.start_date_time AS t_start_date, 
                task.end_date_time AS t_end_date, task.status AS t_status, project.name AS p_name 
                FROM task
                JOIN project ON task.project_id = project.project_id";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $result = $stmt->get_result();

                $task_assignees = [];
                while ($row = mysqli_fetch_assoc($result)){

                    $current_task_id = $row['t_id'];
                    $tasks_id[] = $row['t_id'];
                    $tasks_name[] = $row['t_name'];
                    $tasks_start_date[] = $row['t_start_date'];
                    $tasks_end_date[] = $row['t_end_date'];
                    $tasks_status[] = $row['t_status'];
                    $task_project_name[] = $row['p_name'];

                    //$get_assignees = "SELECT user.name AS as_name FROM task_assignees JOIN user ON task_assignees.assignee_id = user.user_id WHERE task_id ='$current_task_id'";
                    //$assignees_responce = mysqli_query($conn, $get_assignees);

                    $get_assignees = "SELECT user.name AS as_name 
                    FROM task_assignees 
                    JOIN user ON task_assignees.assignee_id = user.user_id 
                    WHERE task_id = ?";
                    $stmt = $conn->prepare($get_assignees);
                    $stmt->bind_param("s", $current_task_id);
                    $stmt->execute();
                    $assignees_response = $stmt->get_result();


                    while ($row = $assignees_response->fetch_assoc()){
                        $assignees_name[] = $row['as_name'];
                    }
                    
                    $task_assignees[$current_task_id] = $assignees_name;
                    $assignees_name = [];
                }
            ?>
            <script>
                var projects_id = '<?php echo json_encode($projects_id); ?>';
                var projects_name = '<?php echo json_encode($projects_name); ?>';
                var projects_start_date = '<?php echo json_encode($projects_start_date); ?>';
                var projects_end_date = '<?php echo json_encode($projects_end_date); ?>';
                var projects_status = '<?php echo json_encode($projects_status); ?>';
                var project_supervisors = '<?php echo json_encode($project_supervisors); ?>';

                var tasks_id = '<?php echo json_encode($tasks_id); ?>';
                var tasks_name = '<?php echo json_encode($tasks_name); ?>';
                var tasks_start_date = '<?php echo json_encode($tasks_start_date); ?>';
                var tasks_end_date = '<?php echo json_encode($tasks_end_date); ?>';
                var tasks_status = '<?php echo json_encode($tasks_status); ?>';
                var task_project_name = '<?php echo json_encode($task_project_name); ?>';

                var task_assignees = '<?php echo json_encode($task_assignees); ?>';

            </script>
            <h1 class="mt-4 ms-2">Calendar</h1>
            <div>
                <p class="text-center h3" id="month-name"></p>
                <p class="text-center h5" id="year"></p>
            </div>
            <div id="month-nav" class="d-flex flex-row">
                <button class="mt-2 ms-3 calendar-btns" id="previous-month"><i class="fa-solid fa-angle-left fa-xl"></i>Previous Month</button>
                <button class="mt-2 ms-3 calendar-btns" id="next-month">Next Month<i class="fa-solid fa-angle-right fa-xl"></i></button>
                <button class="mt-2 ms-3 calendar-btns" id="previous-year"><i class="fa-solid fa-angles-left fa-xl"></i>Previous Year</button>
                <button class="mt-2 ms-3 calendar-btns" id="next-year">Next Year<i class="fa-solid fa-angles-right fa-xl"></i></button>
            </div>
            <div id="week-nav" class="d-flex flex-row">
                <button class="mt-2 ms-3 calendar-btns" id="previous-week"><i class="fa-solid fa-angle-left fa-xl"></i>Previous Week</button>
                <button class="mt-2 ms-3 calendar-btns" id="next-week">Next Week<i class="fa-solid fa-angle-right fa-xl"></i></button>
            </div>
            <div id="day-nav" class="d-flex flex-row">
                <button class="mt-2 ms-3 calendar-btns" id="previous-day"><i class="fa-solid fa-angle-left fa-xl"></i>Previous Day</button>
                <button class="mt-2 ms-3 calendar-btns" id="next-day">Next Day<i class="fa-solid fa-angle-right fa-xl"></i></button>
            </div>

            <div class="d-flex flex-row-reverse">
                <button class="mt-2 ms-3 calendar-nav" id="month">View Month</button>
                <button class="mt-2 ms-3 calendar-nav" id="week">View Week</button>
                <button class="mt-2 ms-3 calendar-nav" id="day">View Day</button>         
            </div>

            <div class="mt-3 ms-3 me-3 mb-4 border border-2" id="calendar" style="height: 600px;"></div>
        </main>
    </div>
    <!-- <script src="../assets/tui-calendar/tui-code-snippet.min.js"></script>
    <script src="../assets/tui-calendar/tui-date-picker.min.js"></script>
    <script src="../assets/tui-calendar/tui-time-picker.min.js"></script>
    <script src="../assets/tui-calendar/tui-calendar.js"></script> -->
    <script src="../assets/js/calendar.js" type="module"></script>

    </body>
</html>