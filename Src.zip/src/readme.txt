Change the password in the  db_connect.php

Create 1 new sql table in database

1st table
------------------------
CREATE TABLE pwdReset (
pwdResetId int(11) PRIMARY KEY AUTO_INCREMENT NOT NULL,
pwdResetEmail TEXT NOT NULL,
pwd ResetSelector TEXT NOT NULL,
pwdResetToken LONGTEXT NOT NULL,
pwdResetExpires TEXT NOT NULL
);

Add a new record in your user table like:
Id 			7
Name 			Iacovos
surName 		Kontopyrgos
Password		1234
Email 		iacovos.kontopyrgos.ac@gmail.com
.....

Use a valid email cause a link will be sent later

Then run http://www.localhost/commons/login.html

insert a your email: ex. iacovos.kontopyrgos.ac@gmail.com (same as the record)

Then check for an email in your inbox, check in spam just in case

It should look like this:

Reset your password for Ordinatio
Mailer <iacovos.kontopyrgos.ac@outlook.com>
The link to reset your password is below. If you did not make this request, you can ignore this email
Here is your password reset link:
www.localhost/forgot_password_test/create_new_password.php?selector=9b6585551a1a8944&validator=377a9d27f98815ac2577a3e738e695cd1d3be0e7fe01cf480f63c78f54f0e1a5

Then press the link. It should redirect you to a new page

afterwards insert the new password in the two fields and press reset password

if everything went well the record in your database should be updated.

lastly you will be redirected to the login page where you can try your new password

