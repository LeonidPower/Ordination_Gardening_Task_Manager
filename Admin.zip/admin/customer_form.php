<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Customers - Ordinatio Manager</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <script src="../assets/js/scripts.js"></script>
</head>
<link rel="icon" type="image/png" href="../assets/img/title.svg">

<body class="bg-primary">
    <main>
        <div class="container">
            <div class="row justify-content-center mt-5">
                <div class="col-lg-7">
                    <div class="card shadow-lg border-0 rounded-lg">
                        <div class="card-header">
                            <a href="customer.php"><i
                                    class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                            <p class="text-center font-weight-light display-5 d-block">Add Customer</p>
                            <div class="text-center me-1 mt-1">
                                <img class="float-end" src="../assets/img/ordinatio_manager.svg"
                                    alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                            </div>
                        </div>
                        <div class="card-body">
                            <form id="customer_form" method="POST" action="customer_form.php">
                                <?php 
                                    if (isset($_GET['error'])){
                                        echo '<div class="p-error mb-2"><span>' . $_GET['error'] . '</span>
                                            <button class="close-btn">&times;</button>
                                        </div>';
                                    }
                                    elseif (isset($_GET['success'])){
                                        echo '<div class="p-success mb-2"><span>' . $_GET['success'] . '</span>
                                            <button class="close-btn">&times;</button>
                                        </div>';
                                    }
                                ?>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mb-md-0">
                                            <input class="form-control" name="first_name" id="inputFirstName"
                                                type="text" placeholder="Enter your first name" required />
                                            <label for="inputFirstName">First Name<span class="required-field"> *</span></label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input class="form-control" name="last_name" id="inputLastName" type="text"
                                                placeholder="Enter your last name" required />
                                            <label for="inputLastName">Last Name<span class="required-field"> *</span></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input class="form-control" name="company_name" id="inputCompanyName"
                                                type="text" placeholder="Enter company name" />
                                            <label for="inputLastName">Company Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating mb-3 mbmd-0">
                                            <input class="form-control" name="phone" id="inputPhoneNumber" type="tel"
                                                placeholder="Phone Number" />
                                            <label for="inputPhoneNumber">Phone Number</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-floating mb-3 mbmd-0">
                                    <input class="form-control" name="email" id="inputEmail" type="email"
                                        placeholder="name@example.com" required />
                                    <label for="inputEmail">Email Address<span class="required-field"> *</span></label>
                                </div>
                                <div class="form-floating mb-3 mbmd-0">
                                    <input class="form-control" name="address" id="inputAddress" type="text"
                                        placeholder="Address" />
                                    <label for="inputAddress">Address</label>
                                </div>
                                <div class="mt-4 mb-0">
                                    <button class="btn btn-primary btn-block" type="submit"
                                        id="register_button">Add</button>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer text-center py-3">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/validate-form-customer.js"></script>
</body>
</html>