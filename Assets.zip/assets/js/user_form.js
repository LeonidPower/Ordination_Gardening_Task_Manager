new TomSelect('#select-position',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});
console.log("here");
const inputFirstName = document.getElementById('inputFirstName');
const inputLastName = document.getElementById('inputLastName');
const inputEmail = document.getElementById('inputEmail');
const inputPassword = document.getElementById('inputPassword');
const inputPasswordConfirm = document.getElementById('inputPasswordConfirm');
const form = document.querySelector('form');

inputFirstName.addEventListener('input', (event) => {
  event.preventDefault();  // this prevents the form from submitting 
  if (inputFirstName.value == "") {
    inputFirstName.style.borderColor = "red";
    inputFirstName.setCustomValidity("The field cannot be blank");
  } else {
    inputFirstName.setCustomValidity('');
    inputFirstName.style.borderColor = "";
  }
});

inputFirstName.addEventListener('blur', (event) => {
  if (inputFirstName.value == "") {
    inputFirstName.style.borderColor = "red";
  } else {
    inputFirstName.style.borderColor = "";
  }
});

inputLastName.addEventListener('input', (event) => {
  event.preventDefault(); // this prevents the form from submitting 
  if (inputLastName.value == "") {
    inputLastName.style.borderColor = "red";
    inputLastName.setCustomValidity("The field cannot be blank");
  } else {
    inputLastName.setCustomValidity('');
    inputLastName.style.borderColor = "";
  }
});

inputLastName.addEventListener('blur', (event) => {
  if (inputLastName.value == "") {
    inputLastName.style.borderColor = "red";
  } else {
    inputLastName.style.borderColor = "";
  }
});

inputEmail.addEventListener('input', (event) => {
  event.preventDefault(); // this prevents the form from submitting 
  if (inputEmail.value == "") {
    inputEmail.style.borderColor = "red";
    inputEmail.setCustomValidity("The field cannot be blank");
  } else {
    inputEmail.setCustomValidity('');
    inputEmail.style.borderColor = "";
  }
});

inputEmail.addEventListener('blur', (event) => {
  if (inputEmail.value == "") {
    inputEmail.style.borderColor = "red";
  } else {
    inputEmail.style.borderColor = "";
  }
});

inputPassword.addEventListener('input', (event) => {
  event.preventDefault(); // this prevents the form from submitting 
  if (inputPassword.value == "") {
    inputPassword.style.borderColor = "red";
    inputPassword.setCustomValidity("The field cannot be blank");
  } else {
    inputPassword.setCustomValidity('');
    inputPassword.style.borderColor = "";
  }
});

inputPassword.addEventListener('blur', (event) => {
  if (inputPassword.value == "") {
    inputPassword.style.borderColor = "red";
  } else {
    inputPassword.style.borderColor = "";
  }
});

inputPasswordConfirm.addEventListener('input', (event) => {
  event.preventDefault(); // this prevents the form from submitting 
  if (inputPassword.value !== inputPasswordConfirm.value) {
    inputPasswordConfirm.setCustomValidity("Passwords do not match");
    inputPassword.style.borderColor = "red";
    inputPasswordConfirm.style.borderColor = "red";
  } else if (inputPassword.value === '' && inputPasswordConfirm.value === '') {
    inputPasswordConfirm.setCustomValidity('');
    inputPassword.style.borderColor = "";
    inputPasswordConfirm.style.borderColor = "";
  } else {
    inputPasswordConfirm.setCustomValidity('');
    inputPassword.style.borderColor = "";
    inputPasswordConfirm.style.borderColor = "";
  }
});

inputPasswordConfirm.addEventListener('blur', (event) => {
  event.preventDefault();
  if (inputPasswordConfirm.value == "") {
    inputPasswordConfirm.style.borderColor = "red";
    inputPasswordConfirm.setCustomValidity("The field cannot be blank");
  } else {
    inputPasswordConfirm.setCustomValidity('');
    document.getElementById('inputPasswordConfirm').style.borderColor = "";
  }
});