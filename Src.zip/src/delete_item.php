<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['product_id_delete'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $product_id = validate($_POST['product_id_delete']);
    }
    else{
        include "../admin/stock.php";
        exit();
    }

    if(empty($product_id)){
        header("Location: ../src/stock.php?error=Product not found");
    }else{ 
        $sql = "DELETE FROM stock WHERE item_id =?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        header("Location: ../src/stock.php?success=Item deleted");
    }

    $conn->close();
?> 