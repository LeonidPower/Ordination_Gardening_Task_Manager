const table = document.getElementById("quotes-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_quote_btn').removeAttr('disabled');
            $('#delete_quote_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_quote_btn').prop('disabled');
            $('#edit_quote_btn').prop('disabled')
        }
    })
});


$('#edit_quote_btn').click(()=>{

    if (checkedRow) {

        var row = checkedRow;
        var quote_id = $(row).attr('data-q_id');

        var current_quote = quotes.filter(function(quote) {
            return quote.quote_id == quote_id;
        });

        const quote_name = current_quote[0].quote_name;
        const quote_status = current_quote[0].quote_status;
        const quote_date = current_quote[0].quote_date;
        const vat = current_quote[0].quote_vat;

        const discount = current_quote[0].quote_discount;
        const quote_valid_for = current_quote[0].quote_valid_for;

        const customer_hash = current_quote[0].customer;


        var calculate_services = 0 ; 
        current_quote[0].quote_services.forEach(service => {
            calculate_services  = calculate_services + parseInt(service.service_quantity) * parseFloat(service.service_price);
        });

        var calculate_stock = 0 ; 
        current_quote[0].quote_stock.forEach(stock_item => {
            calculate_stock  = calculate_stock + parseInt(stock_item.stock_quantity) * parseFloat(stock_item.stock_price);
        });

        var discount_amount = parseFloat(current_quote[0].quote_discount);
        var vat_amount = parseFloat(current_quote[0].quote_vat);

        var total = calculate_total(calculate_services, calculate_stock, discount_amount, vat_amount); 

        $('#inputID').val(quote_id);
        $('#inputServicesTotal').val(calculate_services);
        $('#inputStockTotal').val(calculate_stock);
        $('#edit_tables').attr('href', 'edit_q_tables_intermediate.php?id=' + quote_id);        
        $("#inputQuoteName").val(quote_name);
        $("#inputQuoteDate").val(quote_date);
        $("inputQuoteStatus").val(quote_status);
        $("#inputQuoteVat").val(vat);
        $("#inputQuoteDiscount").val(discount);
        $("#inputQuoteValidFor").val(quote_valid_for);
        $('#inputQuoteTotal').val(total);
        $("#quoteTotal").html('Total: €' + total);

        customer_select.setValue(customer_hash);
    }

});

function calculate_total(services, stock, discount, vat){ 
    total = 0 ; 
    subtotal = services + stock;

    discount_amount = subtotal * discount/100;

    vat_amount = (subtotal - discount_amount) * vat/100;

    total = (subtotal - discount_amount + vat_amount).toFixed(2);

    return total;
}
$('#delete_quote_btn').click(()=>{ 
    var row = checkedRow;
    var quote_id = $(row).attr('data-q_id');
    $("#inputID_del").val(quote_id);
});

$('#inputQuoteVat').change(()=>{
    var total_combined = 0 ; 
    var total = $("#quoteTotal");

    var discount = $("#inputQuoteDiscount").val();
    var vat = $("#inputQuoteVat").val();

    var services_total = parseFloat($('#inputServicesTotal').val());
    var stock_total = parseFloat($('#inputStockTotal').val());

    var total_combined = calculate_total(services = services_total, stock = stock_total, discount = discount, vat = vat);
    $('#inputQuoteTotal').val(total_combined);
    total.html('Total: €' + total_combined);
}); 

$('#inputQuoteDiscount').change(()=>{

    var total_combined = 0 ; 
    var total = $("#quoteTotal");

    var discount = $("#inputQuoteDiscount").val();
    var vat = $("#inputQuoteVat").val();

    var services_total = parseFloat($('#inputServicesTotal').val());
    var stock_total = parseFloat($('#inputStockTotal').val());

    var total_combined = calculate_total(services = services_total, stock = stock_total, discount = discount, vat = vat);
    $('#inputQuoteTotal').val(total_combined);
    total.html('Total: €' + total_combined);
});

var customer_select = new TomSelect("#select-customer",{
    persist: true,
    createOnBlur: true,
    create: false,
    searchField: 'title',
});