<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    $requiredFields = ['hash_del'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $hash = validate($_POST['hash_del']);
    }
    else {
        include "../admin/user.php";
        exit();
    }

    if(empty($hash)){
        header("Location: user.php?error=User not found");
        exit();
    }else{
        $sql= "DELETE FROM user WHERE hash=?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $hash);
        $stmt->execute();
        header("Location: user.php?success=User deleted");
    }

    $conn->close();
?>