<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';


    $requiredFields = ['id_del'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $id = validate($_POST['id_del']);
    }
    else{
        include "../admin/quote.php";
        exit();
    }

    if(empty($id)){
        header("Location: quote.php?error=Quote was not found");
        exit();
    }else{
        $sql= "DELETE FROM quote WHERE quote_id=?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $hash);
        $stmt->execute();

        header("Location: customer.php?success=Quote deleted");
    }
    $conn->close();
?>