
$('#inputProjectName').on('input', function() {
    if ($(this).val().length > 25) {
        $(this).val($(this).val().slice(0, 25)); // Truncate input to 10 characters
    }
})

$('#inputAddress').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /\d/; // Regular expression pattern to match any digit
    
    if (numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\d/g, '')); // Remove any digit characters
    }
    if ($(this).val().length > 30) {
        $(this).val($(this).val().slice(0, 30)); // Truncate input to 30 characters
    }
})

$('#inputCity').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /\d/; // Regular expression pattern to match any digit
    
    if (numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\d/g, '')); // Remove any digit characters
    }
    if ($(this).val().length > 15) {
        $(this).val($(this).val().slice(0, 15)); // Truncate input to 15 characters
    }
})

$('#inputNumber').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /^\d+$/;
    if (!numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\D/g, '')); // Remove non-digit characters
    }
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 6 characters
    }
})

$('#inputPost').on('input', function() {
    var inputValue = $(this).val();
    var numberPattern = /^\d+$/;
    if (!numberPattern.test(inputValue)) {
        $(this).val(inputValue.replace(/\D/g, '')); // Remove non-digit characters
    }
    if ($(this).val().length > 6) {
        $(this).val($(this).val().slice(0, 6)); // Truncate input to 10 characters
    }
})

$('#inputDescription').on('input', function() {
    if ($(this).val().length > 500) {
        $(this).val($(this).val().slice(0, 500)); // Truncate input to 10 characters
    }
})
