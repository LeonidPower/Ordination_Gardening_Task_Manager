<?php
    require "fetch_projects.php";
?>