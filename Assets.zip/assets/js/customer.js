const table = document.getElementById("customers-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_customer_btn').removeAttr('disabled');
            $('#delete_customer_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_customer_btn').prop('disabled');
            $('#edit_customer_btn').prop('disabled')
        }

    })
});

$('#edit_customer_btn').click(()=>{ 
    if (checkedRow) {

        const row = $(checkedRow);
        const c_hash = row.attr('data-c_hash');
        const c_name = row.attr('data-c_name');
        const c_surname = row.attr('data-c_surname');
        const c_email = row.attr('data-c_email');
        const c_phone = row.attr('data-c_phone');
        const c_address = row.attr('data-c_address');
        const c_company = row.attr('data-c_company');

        $("#hashID_edit").val(c_hash);
        $("#inputFirstName").val(c_name);
        $("#inputLastName").val(c_surname);
        $("#inputEmail").val(c_email);
        $("#inputPhoneNumber").val(c_phone);
        $("#inputAddress").val(c_address);
        $("#inputCompanyName").val(c_company);

    }
});

$('#delete_customer_btn').click(()=>{ 
    const row = $(checkedRow);
    const c_hash = row.attr('data-c_hash');
    $("#hashID_del").val(c_hash);

});