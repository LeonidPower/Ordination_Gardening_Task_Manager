<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
        <title>System - Ordinatio Manager</title>
    </head>
    <?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-1">    
                <h1 class="inline"><i class="fa-solid fa-sliders"></i> Manage System</h1>
                <div class="mt-5 ms-5">
                  <form  class='border border-2 mb-3'action="set_store_information.php" method="POST">
                    <div class="row ms-2">
                      <p class="h3 mb-5 mt-4">Set Store Information</p>
                      <div class="col-md-6">
                         <p class="h5 mb-4">Store Address</p>
                         <div class="form-floating  ms-2 mb-3">
                           <input class="form-control" name="store_address" id="inputAddress" type="text" placeholder="Store Address" required/>
                           <label for="inputAddress">Address</label>
                         </div>
                      </div>
                      <div class="col-md-3">
                        <p class="h5 mb-4">City</p>
                        <div class="form-floating mb-3">
                          <input class="form-control" name="store_city" id="inputCity" type="text" placeholder="City"/>
                          <label for="inputCity">City</label>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <p class="h5 mb-4">Zip</p>
                        <div class="form-floating mb-3">
                          <input class="form-control" name="store_zip" id="inputZip" type="text" placeholder="Zip"/>
                          <label for="inputZip">Zip</label>
                        </div>
                      </div>
                    </div>
                    <div class="row ms-2">
                      <div class="col-md-3">
                        <p class="h5 mb-4">Payble to</p>
                        <div class="form-floating ms-2 mb-3">
                          <input class="form-control" name="store_payble_to" id="inputPaybleTo" type="text" placeholder="Payble To" required/>
                          <label for="inputPaybleTo">Payble to</label>
                        </div>
                      </div>
                    </div>
                    <div class="mt-5 ms-4 mb-3">
                      <button class="btn btn-primary btn-block" type="submit" id="create_position_button" style="width: auto;">Submit</button>
                    </div>
                    <?php
                      include 'db_connect.php';

                      $sql = "SELECT * FROM settings";
                      $stmt = $conn->prepare($sql);
                      $stmt->execute();
                      $result = $stmt->get_result();
                      $row = $result->fetch_assoc();
                      

                      $address = $row['address'];
                      $city = $row['city'];
                      $zip = $row['zip'];
                      $payable_to = $row['payableto'];

                    ?>
                    <script>
                      var address = "<?php echo $address; ?>";
                      var city = "<?php echo $city; ?>";
                      var zip = "<?php echo $zip; ?>";
                      var payble_to = "<?php echo $payable_to; ?>";
                    </script>
                  </form>

                    <form action="manage_system_form.php" method="POST">
                      <?php 
                        if (isset($_GET['error'])){
                          echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                              <button class="close-btn mb-1">&times;</button>
                          </div>';
                        }
                        elseif (isset($_GET['success'])){
                            echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                  <button class="close-btn mb-1">&times;</button>
                            </div>';
                        }
                      ?>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                             <p class="h3 mb-5">Create a new position</p>
                             <p class="h5 mb-4">Position Name</p>
                             <div class="form-floating ms-3 mb-3">
                               <input class="form-control" name="position_name" id="inputPositionName" type="text" placeholder="Positon Name" required/>
                               <label for="inputPositionName">Position</label>
                             </div>
                           </div>
                           <p class="h4 mt-4 ms-4">Admin/Manager Permissions</p>
                            <div class="mb-2 ms-4">
                                 <input class="form-check-input" type="checkbox" id="AdminUser"> 
                                 <input type="hidden" name="admin_hidden" id="AdminUserHidden">  

                                 <label for="AdminUser" class="form-label h5 radio-inline">Admin&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                            </div>
                            <div class="mb-2 ms-4">
                                 <input class="form-check-input" type="checkbox" id="ProjectManager"> 
                                 <input type="hidden" name="project_manager_hidden" id="ProjectManagerHidden">   
                                 <label for="ProjectManager" class="form-label h5 radio-inline">Project Manager&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                            </div>
                        </div>
                      </div>
                        <div class="row">
                         <div class="card card-left">
                           <div class="card-body">
                            <div class="d-flex">
                              <h4 class="mt-4">Create Permissions</h4>
                              <a class="ms-auto mt-1" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-html="true" title="Permission Ranges" data-bs-content="<p>1 - Cannot create any tasks</p><p>2 - Can create tasks assigned on to them</p><p>3 - Can create tasks for everyone</p>"><i class="bi bi-info-circle-fill fa-lg"></i></a>
                            </div>
                             <div class="col-md-9 mt-4 ms-4">
                               <div class="form-check mb-3">
                                 <label for="CreateTasksRange" class="form-label h5 d-block">Tasks</label> 
                                 <input type="range" class="form-range w-90" value="0" min="0" max="2" id="CreateTasksRange" list="values">
                                 <input type="hidden" id="CreateTasksRangeHidden" name="create_tasks_range_hidden">
                                 <datalist id="values">
                                    <option value="0" label="1"></option>
                                    <option value="1" label="2"></option>
                                    <option value="2" label="3"></option>
                                 </datalist>
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_projects" id="CreateProjects" value='1'>
                                 <input type="hidden" name="create_projects_hidden" id="CreateProjectsHidden">  
                                 <label for="CreateProjects" class="form-label h5 radio-inline">Projects</label> 
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_users" id="CreateUsers">
                                 <input type="hidden" name="create_users_hidden" id="CreateUsersHidden">  
                                 <label for="CreateUsers" class="form-label h5 radio-inline">System Users&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_invoices" id="CreateInvoices">
                                 <input type="hidden" name="create_invoices_hidden" id="CreateInvoicesHidden">  
                                 <label for="CreateInvoices" class="form-label h5 radio-inline">Invoices&nbsp;&nbsp;&nbsp;&nbsp;</label>
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_quotes" id="CreateQuotes">
                                 <input type="hidden" name="create_quotes_hidden" id="CreateQuotesHidden">  
                                 <label for="CreateQuotes" class="form-label h5 radio-inline">Quotes&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_customers" id="CreateCustomers">
                                  <input type="hidden" name="create_customers_hidden" id="CreateCustomersHidden">
                                 <label for="CreateCustomers" class="form-label h5 radio-inline">Customers&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                               </div>
                               <div class="mb-3 ms-4">
                                 <input class="form-check-input" type="checkbox" name="create_stock" id="CreateStock">
                                 <input type="hidden" name="create_stock_hidden" id="CreateStockHidden">  
                                 <label for="CreateStock" class="form-label h5 radio-inline">Stock&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                               </div>
                             </div>
                           </div>
                         </div>
                         <div class="card card-right">
                          <div class="card-body" >
                            <div class="d-flex">
                              <h4 class="mt-4">View Permissions</h4>
                              <a class="ms-auto mt-1" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-html="true" title="Permission Ranges" data-bs-content="<p>1 - Cannot view any projects/tasks</p><p>2 - Can view projects/tasks assigned on to them</p><p>3 - Can view all projects/taks</p>"><i class="bi bi-info-circle-fill fa-lg"></i></a>
                            </div>
                            <div class="col-md-9 mt-4 ms-4"> 
                              <div class="form-check mb-3">
                                <label for="ViewProjectsRange" class="form-label h5 d-block">Projects</label> 
                                <input type="range" class="form-range w-90" value="0" min="0" max="2" name="view_projects_range" id="ViewProjectsRange" list="values">
                                <input type="hidden" id="ViewProjectsRangeHidden" name="view_projects_range_hidden">
                                <datalist id="values" style="grid-auto-flow: column;">
                                   <option value="0" label="1"></option>
                                   <option value="1" label="2"></option>
                                   <option value="2" label="3"></option>
                                </datalist>
                              </div>
                              <div class="form-check mb-3">
                                <label for="ViewTasksRange" class="form-label h5 d-block">Tasks</label> 
                                <input type="range" class="form-range w-90" value="0" min="0" max="2" name="view_tasks_range" id="ViewTasksRange" list="values">
                                <input type="hidden" id="ViewTasksRangeHidden" name="view_tasks_range_hidden">
                                <datalist id="values">
                                   <option value="0" label="1"></option>
                                   <option value="1" label="2"></option>
                                   <option value="2" label="3"></option>
                                </datalist>
                              </div>
                                <div class="mb-3">
                                   <input class="form-check-input" type="checkbox" name="view_users" id="ViewUsers">  
                                    <input type="hidden" name="view_users_hidden" id="ViewUsersHidden">
                                  <label for="ViewUsers" class="form-label h5 radio-inline">System Users&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                </div>
                                <div class="mb-3">
                                   <input class="form-check-input" type="checkbox" name="view_invoices" id="ViewInvoices">
                                   <input type="hidden" name="view_invoices_hidden" id="ViewInvoicesHidden">  
                                   <label for="ViewInvoices" class="form-label h5 radio-inline">Invoices&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                </div>
                                <div class="mb-3">
                                   <input class="form-check-input" type="checkbox" name="view_quotes" id="ViewQuotes">
                                    <input type="hidden" name="view_quotes_hidden" id="ViewQuotesHidden">
                                  <label for="ViewQuotes" class="form-label h5 radio-inline">Quotes&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                </div>
                                <div class="mb-3">
                                   <input class="form-check-input" type="checkbox" name="view_customers" id="ViewCustomers">
                                     <input type="hidden" name="view_customers_hidden" id="ViewCustomersHidden">  
                                   <label for="ViewCustomers" class="form-label h5 radio-inline">Customers&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                </div>
                                <div class="mb-3">
                                   <input class="form-check-input" type="checkbox" name="view_stock" id="ViewStock">
                                   <input type="hidden" name="view_stock_hidden" id="ViewStockHidden">  
                                   <label for="ViewStock" class="form-label h5 radio-inline">Stock&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="mt-5 ms-6 mb-0">
                            <button class="btn btn-primary btn-block" type="submit" id="create_position_button" style="width: auto;">Create Position</button>
                        </div>
                        <br><br><br>
                    </form>
                </div>
            </div>
        </main>
    </div>
<!-- --------------------------------------- End --------------------------------------- -->
        <script src="../assets/datatables/datatables.js"></script>
        <script src="../assets/js/manage_system.js"></script>
        <script>
            $(document).ready(function () {
            $('#users-table').DataTable();
            });
        </script>
    </body>
</html>