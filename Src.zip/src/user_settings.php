<?php
    require 'check_login.php';
    require_once '../commons/user_settings.php';
    exit();
?>