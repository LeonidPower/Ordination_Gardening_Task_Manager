$('#inputHeight').on('change', function() {
    if($(this).val() != '' && $('#inputWidth') != '' && $('#inputSize') != ''){
        console.log('here1');
        $(this).prop('required', true);
        $('#inputWidth').prop('required', true);
        $('#inputSize').prop('required', true);
    }else if(!$(this).val() && !$('#inputWidth').val() && !$('#inputSize').val()){
        $(this).removeAttr('required');
        $('#inputWidth').removeAttr('required');
        $('#inputSize').removeAttr('required');
    } 
});

$('#inputWidth').on('change', function() {
    if($(this).val() != '' && $('#inputHeight') != '' && $('#inputSize') != ''){
        console.log('here1');
        $(this).prop('required', true);
        $('#inputHeight').prop('required', true);
        $('#inputSize').prop('required', true);
    }else if(!$(this).val() && !$('#inputHeight').val() && !$('#inputSize').val()){
        $(this).removeAttr('required');
        $('#inputHeight').removeAttr('required');
        $('#inputSize').removeAttr('required');
    } 
});

$('#inputSize').on('change', function() {
    if($(this).val() != '' && $('#inputHeight') != '' && $('#inputWidth') != ''){
        console.log('here1');
        $(this).prop('required', true);
        $('#inputHeight').prop('required', true);
        $('#inputWidth').prop('required', true);
    }else if(!$(this).val() && !$('#inputHeight').val() && !$('#inputWidth').val()){
        $(this).removeAttr('required');
        $('#inputHeight').removeAttr('required');
        $('#inputWidth').removeAttr('required');
    } 
});
