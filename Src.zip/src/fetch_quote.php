<?php
    require "db_connect.php";
    require "objects.php";

    $requiredFields = ['id'];

    if (count(array_intersect($requiredFields, array_keys($_GET))) === count($requiredFields)) {
        $quote_id = $_GET['id'];
    }

    if(empty($quote_id)) {
        header("Location: ../src/quote.php?error=Quote not found");
        exit();
    }else{
    
        $query = "SELECT customer.hash AS hash, customer.name AS c_name, customer.surname AS c_surname, customer.address AS c_add, quote.total_price,
                quote.name, quote.date, quote.status, quote.vat, quote.valid_for, quote.discount
            FROM quote
            JOIN customer ON customer.customer_id = quote.customer_id 
            WHERE quote.quote_id=? LIMIT 1;";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $quote_id);
        $stmt->execute();

        $result = $stmt->get_result();

        $quotes = array();
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            $quote = new Objects\Quote($quote_id, $row['name'], $row['status'], $row['date'], $row['total_price'], $row['vat'], $row['discount'], $row['valid_for'], $row['hash']);
            $quote->get_customer_name($row['c_name'], $row['c_surname']);
            $quote->get_customer_address($row['c_add']);
            array_push($quotes, $quote);

            $query2 = "SELECT * FROM quote_services WHERE quote_id=?;";

            $stmt = $conn->prepare($query2);
            $stmt->bind_param("i", $quote_id);
            $stmt->execute();
            $result2 = $stmt->get_result();

            if (mysqli_num_rows($result2) > 0) {
                while($row2 = mysqli_fetch_assoc($result2)){
                    $service = new Objects\Service($row2['service_id'], $row2['name'], $row2['description'], $row2['quantity'], $row2['volume'], $row2['price']);
                    $quote->add_service($service);
                }
            }

            $query3 = "SELECT quote_stock.stock_item_id AS s_id, quote_stock.quantity AS s_quantity, stock.price AS s_price, stock.name AS s_name, stock.volume AS s_volume, stock.width AS s_width, stock.height AS s_height, stock.size AS s_size
                FROM quote_stock
                JOIN stock ON stock.item_id = quote_stock.stock_item_id
                WHERE quote_stock.quote_id=?;";

            $stmt = $conn->prepare($query3);
            $stmt->bind_param("i", $quote_id);
            $stmt->execute();
            $result3 = $stmt->get_result();

            if(mysqli_num_rows($result3) > 0){
                while($row3 = mysqli_fetch_assoc($result3)){
                    $stock = new Objects\Stock($row3['s_id'], $row3['s_name'], $row3['s_quantity'], $row3['s_volume'], $row3['s_width'], $row3['s_height'], $row3['s_size'], $row3['s_price']);
                    $quote->add_stock($stock);
                }
            }
        }
        $quote_json = json_encode($quotes); 

    }
    $conn->close();
?>