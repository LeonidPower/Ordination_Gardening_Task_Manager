<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add to Stock - Ordinatio Manager</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
    <script src="../assets/js/scripts.js"></script>        
</head>
<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <a href="../src/stock.php"><i
                                            class="mt-3 fa-solid fa-circle-chevron-left fa-2xl"></i></a>
                                    <h3 class="text-center font-weight-light display-5 d-block">Add Stock</h3>
                                    <div class="text-center me-1 mt-1">
                                        <img class="float-end" src="../assets/img/ordinatio_manager.svg" alt="Logo of the company" style="width: 150px; height: 100px; margin-top: -40pt;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form id="stock_form" method="POST" enctype="multipart/form-data"action="stock_form.php">
                                        <?php 
                                            if (isset($_GET['error'])){
                                            echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                                                <button class="close-btn mb-1">&times;</button>
                                            </div>';
                                            }
                                            elseif (isset($_GET['success'])){
                                                echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                                                    <button class="close-btn mb-1">&times;</button>
                                                </div>';
                                            }
                                        ?>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="product_name"
                                                        id="inputProductName" type="text"
                                                        placeholder="Enter product name" required />
                                                    <label for="inputProductName">Product Name<span class="required-field"> *</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-floating">
                                                    <input class="form-control" name="height" id="inputHeight" type="number" min="0" placeholder="Enter product height" />
                                                    <label for="inputHeight">Height</label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-floating">
                                                    <input class="form-control" name="width" id="inputWidth" type="number" min="0" placeholder="Enter product width" />
                                                    <label for="inputWidth">Width</label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-floating">
                                                    <input class="form-control" name="size" id="inputSize" type="number" min="0" placeholder="Enter product size" />
                                                    <label for="inputSize">Size</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="quantity" id="inputQuantity"
                                                        type="number" placeholder="Enter product quantity" min="1"value="1" required />
                                                    <label for="inputQuantity">Quantity<span class="required-field"> *</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="volume" id="inputVolume"
                                                        type="number" placeholder="Enter product Volume" min="0.0" value="0.0" />
                                                    <label for="inputVolume">Volume</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="price" id="inputPrice"
                                                        type="number" step="any" placeholder="Enter product price" min="0.0" value="0.0" required style="text-align: right;" />
                                                    <label for="inputPrice">Price in <span class="required-field"> *</span><br>€</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6" style="margin-top: -5px;">
                                                <label class="form-label" for="image"></label>
                                                <input type="file" class="form-control" id="image" name="image" accept=".jpeg, .jpg, .png" />
                                            </div>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <button class="btn btn-primary btn-block" type="submit" id="stock_button">Add ittem</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/validate-form-stock.js"></script>
    <script src="../assets/js/stock_form.js"></script>
</body>

</html>