<!DOCTYPE html>
<html lang="en">
    <?php include 'base.php' ?>
    <head>
        <link href="../assets/css/dashboard.css" rel="stylesheet" />
        <title>Dashboard - Ordinatio Garden Industry</title>
    </head>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class="">Dashboard</h1>
                <div class="row">
                    <div class="col-xl-3">
                        <div class="card mb-4">
                                <canvas id="num_of_my_tasks"></canvas>
                            <?php 
                                require_once '../src/db_connect.php';

                                $sql = "SELECT COUNT(*) FROM task WHERE status = '1' AND task_id IN (SELECT assignee_id FROM task_assignees WHERE  assignee_id='{$_SESSION['user_id']}')";
                                $result = mysqli_query($conn, $sql);
                                $my_tasks_done=mysqli_fetch_row($result);

                                $sql = "SELECT COUNT(*)  FROM task WHERE status = '0' ";
                                $result = mysqli_query($conn, $sql);
                                $my_tasks_pending=mysqli_fetch_row($result);

                            ?>
                        </div>
                    </div>
                    <!-- <?php
                    require_once '../src/db_connect.php';
                    
                    if($_SESSION['is_admin'] === '1'){

                        $sql = "SELECT COUNT(*) FROM task WHERE status = '1';";
                        $result = mysqli_query($conn, $sql);
                        $tasks_done=mysqli_fetch_row($result);

                        $sql = "SELECT COUNT(*)  FROM task WHERE status = '0' ";
                        $result = mysqli_query($conn, $sql);
                        $tasks_pending=mysqli_fetch_row($result);

                        echo "
                            <div class='col-xl-4'>
                                <div class='card mb-4' style='margin-left: 20rem;'>
                                    <canvas id='num_tasks'></canvas>
                                </div>
                            </div>
                        ";
                    }
                    ?> -->
                    <div class="col-xl-5">
                        <div class="card mb-4">
                            <canvas id="tasks_track"></canvas>
                        </div>
                    </div>
                </div>
                <?php
                    require_once '../src/fetch_projects.php'; 
                    
                    if($_SESSION['position']['view_projects'] == '2'){
                        echo "
                            <div class='card mb-4' style='width: 80rem;'>
                                <div class='card-header mb-3'>
                                    <i class='fas fa-table me-1'></i>
                                    My Projects
                                </div>
                                <div class='row px-2'>";
                                foreach ($projects as $p){
                                    foreach ($p->project_supervisors as $s){
                                        if($s->supervisor_id == $_SESSION['user_id']){
                                            $p_name = htmlspecialchars($p->project_name);
                                            $p_add = htmlspecialchars($p->project_address) . " " . htmlspecialchars($p->project_number) . " " . htmlspecialchars($p->project_city) . " " . htmlspecialchars($p->project_post);
                                            $p_s_date = htmlspecialchars(date('Y-m-d',$p->project_start_date));
                                            $p_e_date = htmlspecialchars(date('Y-m-d',$p->project_end_date));
                                            $c_name = htmlspecialchars($p->customer->customer_name);
                                            $c_phone = htmlspecialchars($p->customer->customer_phone);
                                           
                                        echo"<div class='col-md-4 mb-2'>
                                            <a class='project-card' value=''data-bs-target='#project_modal' data-bs-toggle='modal'
                                            data-p_name='$p_name'
                                            data-p_add='$p->project_address' 
                                            data-p_s_date='" . date("Y-m-d", $p->project_start_date) . "'
                                            data-p_e_date='" . date("Y-m-d", $p->project_end_date) . "'
                                            data-c_name='$c_name'
                                            data-c_phone='$c_phone'
                                            >
                                            <div class='card border-success' style='max-width: 40rem'>
                                                <div class='card-header'> $p->project_name </div>
                                                <div class='card-body'>
                                                <p class='card-title display-9 d'>Customer: " . htmlspecialchars($p->customer->customer_name) . " " . htmlspecialchars($p->customer->customer_surname) . "</p>";
                                           
                                        echo"<p class='card-text'></p>
                                            </div>
                                            </div>
                                        </a>
                                            </div>
                                        ";
                                            }
                                    }
                                }
                        echo"
                                </div>        
                            </div>
                            ";
                    }  
                ?>
            </div>
            <div id="project_modal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><i class="bi bi-view-stacked inline"></i> Project Details</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <div id="project-details">
                        <p id="pname"></p>
                        <p id="location"></p>
                        <p id="startday"></p>
                        <p id="endday"></p>
                        <p id="customer"></p>
                        <p id="cphone"></p>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
        </main>
    </div>
    <script src="../assets/js/chart.js"></script>
    <script>
        var tasks_done = '<?php echo $my_tasks_done[0]; ?>';
        var tasks_pending = '<?php echo $my_tasks_pending[0]; ?>';

        var chart_my_tasks = $('#num_of_my_tasks')
        var pie_my_tasks = new Chart(chart_my_tasks, {
            type: 'pie',
            data: {
            labels: ['Blue: Active Tasks', 'Red: Completed Tasks'],
            datasets: [{
                label: '# of my Tasks',
                data: [tasks_done, tasks_pending],
                borderWidth: 1
            }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: 'My tasks'
                    }
                },
            }
        });
        const data = {
            labels: ['May 11', 'May 12', 'May 13', 'May 14', 'May 15', 'May 16'],
            datasets: [
                {
                label: 'Tasks',
                data: [3,2,5,4,1,2],
                pointStyle: 'circle',
                pointRadius: 10,
                pointHoverRadius: 15
                }
            ]
        };
        var tasks_track = $('#tasks_track');
        var line_tasks_track = new Chart(tasks_track, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                plugins: {
                title: {
                    display: true,
                    text: (ctx) => 'Tasks Done daily',
                }
                }
            }});

        line_tasks_track.canvas.parentNode.style.height = '400px';
        line_tasks_track.canvas.parentNode.style.width = '850px';
        pie_my_tasks.canvas.parentNode.style.height = '400px';
        pie_my_tasks.canvas.parentNode.style.width = '400px';

    </script>
        <!-- <script>
            var tasks_done = '<?php echo $tasks_done[0]; ?>';
            var tasks_pending = '<?php echo $tasks_pending[0]; ?>';
    
            var chart_total_tasks = $('#num_tasks')
            var pie_total_tasks = new Chart(chart_total_tasks, {
                type: 'pie',
                data: {
                labels: ['Blue: Active Tasks', 'Red: Completed Tasks'],
                datasets: [{
                    label: '# of my Tasks',
                    data: [tasks_done, tasks_pending],
                    borderWidth: 1
                }]
                },
                options: {
                    plugins: {
                        title: {
                            display: true,
                            text: 'Total tasks'
                        }
                    },
                }
            });
            pie_total_tasks.canvas.parentNode.style.height = '400px';
            pie_total_tasks.canvas.parentNode.style.width = '400px';
        </script> -->
    <script src="../assets/js/dashboard.js"></script>
    </body>
</html>