$('#inputFirstName').val(first_name);
$('#inputLastName').val(last_name);
$('#inputPhone').val(phone);
$('#inputAddress').val(address);
$('#displayEmail').html(email);