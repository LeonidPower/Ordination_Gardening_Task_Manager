<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

        $stock_data = $_POST['stock_data']; 
        $stock_json = json_decode(($stock_data) , true);

        if(isset($stock_json['invoice_id']))
        {
            if(empty($stock_json['invoice_id'])){ 
                header("Location: edit_i_tables_intermediate.php?id=$invoice_id?error=Invoice not selected");
                exit();
            }

            $invoice_id = validate($stock_json['invoice_id']);
            $stock = $stock_json['stock'];

            if (isset($stock[0]['item_id']) && isset($stock[0]['quantity'])) // We need atleast one services and the first one is mandatory
            {
                if(empty($stock[0]['item_id']))
                {
                    header("Location: edit_i_tables_intermediate.php?id=$invoice_id?error=Item ID field empty");
                    exit();
                }else if(empty($stock[0]['quantity']))
                {
                    header("Location: edit_i_tables_intermediate.php?id=$invoice_id?error=Quantity field is empty");
                    exit();

                }

                
                $stock_len = count($stock);
                $sql_delete_services = "DELETE FROM invoice_stock WHERE invoice_id=?;";
                
                $stmt = $conn->prepare($sql_delete_services);
                $stmt->bind_param("i", $invoice_id);
                $stmt->execute();

                for ($i = 0;$i <$stock_len;$i++)
                {
                    $item_id = validate($stock[$i]['item_id']);
                    $item_quant = validate($stock[$i]['quantity']);

                    $sql_insert_service = "INSERT INTO invoice_stock (invoice_id, stock_item_id, quantity) 
                                        VALUES (?, ?, ?);";

                    $stmt = $conn->prepare($sql_insert_service);
                    $stmt->bind_param("iii", $invoice_id, $item_id, $item_quant);
                    $stmt->execute();
            
                }
                header("Location: edit_i_tables_intermediate.php?id=$invoice_id?success=Stock updated");
                exit();
            }
            else
            {
                header("Location: edit_i_tables_intermediate.php?id=$invoice_id?error=No stock to update");
                exit();
            }
        }
        else
        {
            header("Location: edit_i_tables_intermediate.ph?id=$invoice_idp?error=Invoice ID not set");
            exit();
        }
?>
