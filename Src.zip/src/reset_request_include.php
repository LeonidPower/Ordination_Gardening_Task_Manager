<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'db_connect.php';

$mail = new PHPMailer(true);

if(isset($_POST['reset-request-submit'])){

    $selector = bin2hex(random_bytes(8));
    $token = bin2hex(random_bytes(32));

    $url = "www.localhost/src/reset_password_form.php?selector=" . $selector . "&validator=" . $token;
    
    $expires = date("U") + 1800;

    $userEmail = $_POST["email"];

    $sql_find_user="SELECT email FROM user WHERE email='$userEmail'";
    $result = mysqli_query($conn, $sql_find_user); 

    if(mysqli_num_rows($result) === 1){
    
        $sql='DELETE FROM resetpassword WHERE Email=?';
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            header('Location: ../commons/reset_password_error.php'); // change this to the according error (internal server error) later
            exit();
        } else{
            mysqli_stmt_bind_param($stmt, "s", $userEmail);
            mysqli_stmt_execute($stmt);
        }

        $sql = "INSERT INTO resetpassword (Email,Selector,Token,Expires) VALUES (?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            header('Location: ../commons/reset_password_error.php'); // change this to the according error (internal server error) later
            exit();
        } else{
            $hashedToken = password_hash($token, PASSWORD_DEFAULT);
            mysqli_stmt_bind_param($stmt, "ssss", $userEmail, $selector, $token, $expires);
            mysqli_stmt_execute($stmt);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);

        $subject = 'Reset your password for Ordinatio';
        $message = '<p>The link to reset your password is below. If you did not make this request, you can ignore this email </p>';
        $message .='<p>Here is your password reset link: </br>';                                                                        
        $message .= '<a href="' . $url . '"> ' . $url . '</a></p>';

        try {

            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                    //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.office365.com';                   //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'ordinatio.gardening@outlook.com';   //SMTP username
            $mail->Password   = '.XN16iFB';                             //SMTP password
            $mail->SMTPSecure = 'tls';                                  //Enable implicit TLS encryption
            $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        
            $mail->setFrom('ordinatio.gardening@outlook.com', 'Mailer');
            $mail->addAddress($userEmail, 'User');     //Add a recipient
            $mail->addReplyTo('ordinatio.gardening@outlook.com', 'Information');
        
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->send();

            header('Location: ../commons/reset_password_link_alert.php');

        } catch (Exception $e) {
            header('Location: ../commons/reset_password_error.php');
        }
    }
    else{ 
        header('Location: ../commons/reset_password_link_alert.php'); //We send this message for security reasons
    }
}
else{
    header('Location: ../commons/reset_password_error.php');
}

?>