<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

    $requiredFields = ['invoice-id', 'invoice-name', 'invoice-date', 'invoice-vat', 'customer', 'invoice-total'];

    if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {
        $invoice_id    =   validate($_POST['invoice-id']);
        $q_name      =   validate($_POST['invoice-name']);
        $q_date      =   validate($_POST['invoice-date']);
        $q_vat       =   validate($_POST['invoice-vat']);
        $q_customer  =   validate($_POST['customer']);
        $q_total     =   validate($_POST['invoice-total']);
        
        $q_valid_for =   validate($_POST['invoice-valid-for']);

        $q_status    =   empty($_POST['invoice-status']) ? 1 : 0;
        $q_discount  =   validate($_POST['invoice-discount']);
    }
    else {
        include "../admin/invoice.php";
        exit();
    }
    
    $errorMessages = [];

    if(empty($invoice_id)) {
        $errorMessages[] = "Invoice ID";
    }
    
    if (empty($q_name)) {
        $errorMessages[] = "Name";
    }
    
    if(empty($q_date)) {
        $errorMessages[] = "Date";
    }
    
    if(empty($q_vat)) {
        $errorMessages[] = "VAT";
    }
    
    if(empty($q_customer)) {
        $errorMessages[] = "Customer";
    }

    if(empty($q_total)) {
        $errorMessages[] = "Total";
    }

    if (!empty($errorMessages)) {
        echo "here";
        $errorMessage = implode(", ", $errorMessages) . " is empty";
        header("Location: ../src/invoice.php?error=$errorMessage");
        exit();
    }else{

        $sql_get_customer_id = "SELECT customer_id FROM customer WHERE hash=?;";

        $stmt = $conn->prepare($sql_get_customer_id);
        $stmt->bind_param("s", $q_customer);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        $row = mysqli_fetch_assoc($result);

        $q_customer = $row['customer_id'];

        $sql_update_invoice = "UPDATE
                                invoice
                            SET
                                customer_id = ?,
                                NAME = ?,
                                status = ?,
                                date = ?,
                                total_price = ?,
                                vat = ?,
                                discount = ?,
                                valid_for = ?
                            WHERE
                                invoice_id = ?;";

        $stmt = $conn->prepare($sql_update_invoice);
        $stmt->bind_param("isissddsi", $q_customer, $q_name, $q_status, $q_date, $q_total, $q_vat, $q_discount, $q_valid_for, $invoice_id);
        $stmt->execute();

        header("Location: invoice.php?success=Invoice updated successfully");
        
    }    
?>
