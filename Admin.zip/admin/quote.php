<!DOCTYPE html>
<html lang="en">

<head>
    <link href="../assets/css/quote.css" rel="stylesheet" />
    <link href="../assets/css/quote_form.css" rel="stylesheet" />
    <link href="../assets/datatables/datatables.css" rel="stylesheet" />
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
    <script src="../assets/js/scripts.js"></script>

    <title>Quotes - Ordinatio Manager</title>
</head>
<?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class="inline"><i class="fas fa-book-open fa-fw me-1 inline"></i>Quotes</h1>
                <?php 
                    if (isset($_GET['error'])){
                    echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                        <button class="close-btn mb-1">&times;</button>
                    </div>';
                    }
                    elseif (isset($_GET['success'])){
                        echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';
                    }
                ?>
                <?php
                    require_once '../src/db_connect.php';

                    $sql = "SELECT address, city, zip, payableto FROM settings";
                    $result = mysqli_query($conn, $sql);


                    $row = mysqli_fetch_assoc($result);
                    $c_ordaddress = isset($row['address']) ? $row['address'] : '';
                    $c_payableto = isset($row['payableto']) ? $row['payableto'] : '';
                    $c_ordcity = isset($row['city']) ? $row['city'] : '';
                    $c_ordzip = isset($row['zip']) ? $row['zip'] : '';


                    echo " <script> var ordaddress = '$c_ordaddress';</script> ";
                    echo " <script> var payableto = '$c_payableto';</script> ";
                    echo " <script> var ordcity = '$c_ordcity';</script> ";
                    echo " <script> var ordzip = '$c_ordzip';</script> ";

                ?>
                <?php require_once 'fetch_quotes.php'; ?>
                <div class="table-size-1 mt-4">
                    <table id="quotes-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <?php if ($_SESSION['position']['create_quotes'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                    echo '<th>Select</th>';
                                } ?>
                                <th>ID</th>
                                <th>Quote Name</th>
                                <th>Customer Full Name</th>
                                <th>Day of creation</th>
                                <th>Status</th>
                                <th>Export</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            foreach ($quotes as $quote) {
                                echo "<tr data-q_id='$quote->quote_id'>";
                                
                                if ($_SESSION['position']['create_quotes'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                    echo "<td style='text-align: center;width:40px;'><input class='mt-1 form-check-input' name='quote_select' type='radio' style='height:20px;width:20px'></td>";
                                }
                                echo "<td>" . $quote->quote_id . "</td>";
                                echo "<td>" . $quote->quote_name .  "</td>";
                                echo "<td>" . $quote->customer_name . "</td>";
                                echo "<td>" . $quote->quote_date . "</td>";
                               
                                if($quote->quote_status == 0){
                                    echo "<td><p hidden>0</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #ff1d1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></i></td>";
                                }else{
                                    echo "<td><p hidden>1</p><i class='fa-solid fa-circle fa-2xl fa-border ms-2-5' style='color: #1dff1d;--fa-border-radius:25px;--fa-border-padding:0px;--fa-border-color:#878787'></i></td>";
                                }
                                echo "<td class=''><a class='d-flex justify-content-center export'><i class='fa-solid fa-download fa-xl'></i></a></td>";
                            
                                echo "</tr>";
                            }
                        ?>
                        </tbody>
                    </table>
                    <script>
                        var quotes = '<?php echo $quotes_json; ?>';
                        quotes = JSON.parse(quotes);
                    </script>
                    <?php if ($_SESSION['position']['create_quotes'] === '1' || $_SESSION['is_admin'] ==='1' ){ ?>
                    <button id="edit_quote_btn" type="button" class="btn btn-primary btns" data-bs-toggle="modal"data-bs-target="#edit_quote" disabled>
                        Edit
                    </button>
                    <form class="d-inline ms-2" id="register_form" method="POST" action="../src/delete_quote.php" novalidate>
                        <input name="id_del" id="inputID_del" required hidden />
                        <button id="delete_quote_btn" type="submit" class="btn btn-danger btns" disabled>
                            Delete
                        </button>
                    </form>
                    <div class="modal fade" id="edit_quote" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content" style="padding: 30px;">
                                <div class="modal-header">
                                    <h4 class="modal-title">
                                        <div class="sb-nav-link-icon inline"><i class="fas fa-book-open"></i> Edit Quote
                                        </div>
                                    </h4>
                                    <button id="btn-x-close" type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form id="register_form" method="POST" action="update_quote.php" novalidate>
                                    <?php 
                                        if (isset($_GET['error'])){
                                            echo '<p class="p-error">' . $_GET['error'] . '</p>';
                                        }
                                    ?>
                                    <br>
                                    <div id="customers">
                                        <div class="form-floating mb-3 mbmd-0">
                                            <?php
                                                require_once '../src/db_connect.php';

                                                $sql = "SELECT name, surname, email, phone, address, hash FROM customer;";
                                                $result = mysqli_query($conn, $sql);
                                                $i = 0; 
            
                                                if (mysqli_num_rows($result) > 0) {
                                                    echo '<div class="d-flex">
                                                            <select class="form-floating d-inline" style="width: 32%;" id="select-customer" name="customer" autocomplete="off" placeholder="Customer">
                                                            <option disabled selected value></option>';
                                                        
                                                        while($row = mysqli_fetch_assoc($result)){

                                                            $hash = $row['hash'];
                                                            $name = $row['name'];
                                                            $surname = $row['surname'];

                                                            echo '<option value="' . $hash . '" name="hash' .  '">' . $name ." " . $surname . '</option>';
                                                            $i++;
                                                        }

                                                    echo '</select><span class="required-field">&nbsp;&nbsp;*</span>
                                                        </div>';      
                                                }
                                                else{ 
                                                    echo '<select class="form-floating" style="width: 32%;" id="select-customer" name="customer" autocomplete="off" placeholder="No customers" required>
                                                            <option disabled selected value></option>
                                                        </select>';
                                                }
                                                
                                                $conn->close();
                                            ?>
                                        </div>
                                      </div>                                      
                                      <div class="row mb-3">
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input class="form-control" name="quote-name" id="inputQuoteName"
                                                    type="text" placeholder="Title" required>
                                                <label for="inputQuoteName">Quote Name<span class="required-field"> *</span></label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input class="form-control" name="quote-date" id="inputQuoteDate"
                                                    type="date" placeholder="Date" required>
                                                <label for="inputQuoteName">Date<span class="required-field"> *</span></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input class="form-control" name="quote-valid-for" id="inputIsValidFor"
                                                    type="number" placeholder="Valid For:" value="14" min="0" required>
                                                <div class="input-icon input-icon-right">
                                                    <i>days</i>
                                                </div>
                                                <label for="inputIsValidFor">Valid For<span class="required-field"> *</span></label>
                                            </div>
                                        </div>
                                    </div> 
                                    <br>                                     
                                    <div class="row mb-3">
                                        <div class="col-md-3">
                                            <div class="d-flex inline">
                                                <a id="edit_tables" href="../src/edit_q_tables_intermediate.php" class="btn btn-primary btn-block" type="button" style="margin-bottom: 10px; margin-bottom: 30px; width:fit-content;">Edit Services/Stock</a>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-check">
                                                <label class="form-check-label ms-2 mt-2" for="inputStatus">Closed</label>
                                                <input name="quote_status" class="form-check-input" type="checkbox" id="inputQuoteStatus" style="height:30px; width:30px;">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2 mt-3">
                                        <div class="col-md-3 align-self-center">
                                            <div class="form-floating">
                                                <input class="form-control" name="quote-vat" id="inputQuoteVat" type="number" min="0" value="0" placeholder="VAT" required>
                                                <label for="inputQuoteVat">Vat<span class="required-field"> *</span></label>
                                            </div>
                                        </div>
                                        <div class="col-md-3 align-self-center">
                                            <div class="form-floating">
                                                <input class="form-control" name="quote-discount" id="inputQuoteDiscount" type="number" min="0" value="0" placeholder="Discount" required>
                                                <label for="inputQuoteDiscount">Discount<span class="required-field"> *</span></label>
                                            </div>
                                        </div>
                                        <input class="form-control" id="inputServicesTotal" hidden>
                                        <input class="form-control" id="inputStockTotal" hidden>
                                        <div class="col-md-6 d-flex align-items-center justify-content-end">
                                            <div class="form-floating">
                                                <p id='quoteTotal' class="h5 mb-0"> Total: <i>€</i>0</p>
                                                <input name="quote-total" id="inputQuoteTotal" type="hidden" required>
                                                </div>
                                            </div>
                                        </div>                                    
                                    <br>
                                    <input name="quote-id" id="inputID" required hidden />
                                    <div class="modal-footer">
                                        <button id="btn-close" type="button" class="btn btn-secondary btns"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary btns">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
        </main>
    </div>
    <!-- --------------------------------------- End --------------------------------------- -->
    <script src="../assets/datatables/datatables.js"></script>
    <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
    <script src="../assets/js/quote.js"></script>
    <script>
        $(document).ready(function () {
            $('#quotes-table').DataTable();
        });
    </script>
    <script type="module" src="../assets/js/export_existing_quote.js"></script>
</body>

</html>