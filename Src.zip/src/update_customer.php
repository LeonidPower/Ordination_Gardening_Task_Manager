<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['hash_edit'])){   
        
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);
        $hash= validate($_POST['hash_edit']);

        $company_name = isset($_POST['company_name']) ? validate($_POST['company_name']) : "";
        $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";
        $address = isset($_POST['address']) ? validate($_POST['address']) : "";
    }
    else{
        include "../admin/customer.php";
        exit();
    }

    if(empty($hash)){ 
        header("Location: customer.php?error=Empty fields found");
        exit();
      }
    else if(empty($firstname)){ 
      header("Location: customer.php?error=Firstname is empty");
      exit();
    }
    elseif(empty($lastname)){ 
        header("Location: customer.php?error=Lastname is empty");
        exit();
    }
    elseif(empty($email)){ 
        header("Location: customer.php?error=email is empty");
        exit();
    }
    else{
        $sql = "SELECT * FROM customer WHERE email = ? AND hash != ?;";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $hash);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0)
        {
            $sql = "UPDATE customer 
            SET name = ?, surname = ?, email = ?, phone = ?, company = ?, address = ? 
            WHERE hash = ?;";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $firstname, $lastname, $email, $phone, $company_name, $address, $hash);
            $stmt->execute();
                header("Location: customer.php?success=Customer updated");
        }
        else{ 
            header("Location: customer.php?error=email is already used");
            exit();
        }
    }
?>