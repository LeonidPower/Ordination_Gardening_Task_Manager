$('#inputTaskName').on('input', function() {
    if ($(this).val().length > 25) {
        $(this).val($(this).val().slice(0, 25)); // Truncate input to 10 characters
    }
})

$('#inputDescription').on('input', function() {
    if ($(this).val().length > 500) {
        $(this).val($(this).val().slice(0, 500)); // Truncate input to 10 characters
    }
})
