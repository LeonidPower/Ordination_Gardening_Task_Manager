<?php
    require "db_connect.php";
    require "objects.php";

    $query = "SELECT customer.hash AS hash, customer.name AS c_name, customer.surname AS c_surname, customer.address AS c_add, quote.total_price,
        quote.quote_id, quote.name, quote.date, quote.status, quote.vat, quote.valid_for, quote.discount
        FROM quote
        JOIN customer ON customer.customer_id = quote.customer_id;";
    
    $result = mysqli_query($conn, $query);
    $quotes = array();

    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)){

            $quote_id = $row['quote_id'];

            $quote = new Objects\Quote($row['quote_id'], $row['name'], $row['status'], $row['date'], $row['total_price'], $row['vat'], $row['discount'], $row['valid_for'], $row['hash']);
            $quote->get_customer_name($row['c_name'], $row['c_surname']);
            $quote->get_customer_address($row['c_add']);
            array_push($quotes, $quote);

            $query2 = "SELECT * FROM quote_services WHERE quote_id=?;";

            $stmt = $conn->prepare($query2);
            $stmt->bind_param("i", $quote_id);
            $stmt->execute();
            $result2 = $stmt->get_result();

            if (mysqli_num_rows($result2) > 0) {
                while($row2 = mysqli_fetch_assoc($result2)){

                    $service = new Objects\Service($row2['service_id'], $row2['name'], $row2['description'], $row2['quantity'], $row2['volume'], $row2['price']);
                    $quote->add_service($service);
                }
            }

            $query3 = "SELECT * FROM quote_stock WHERE quote_id=?;";
            
            $stmt = $conn->prepare($query3);
            $stmt->bind_param("i", $quote_id);
            $stmt->execute();
            $result3 = $stmt->get_result();

            if(mysqli_num_rows($result3) > 0){
                while($row3 = mysqli_fetch_assoc($result3)){

                    $item_id = $row3['stock_item_id'];

                    $query4 = "SELECT * FROM stock WHERE item_id = '$item_id';";
                    $result4 = mysqli_query($conn, $query4);

                    while($row4 = mysqli_fetch_assoc($result4)){

                        $stock = new Objects\Stock($item_id, $row4['name'], $row3['quantity'], $row4['volume'], $row4['width'], $row4['height'], $row4['size'], $row4['price']);
                        $quote->add_stock($stock);
                    }
                }
            }            
        }
    }
    $quotes_json = json_encode($quotes);
?>