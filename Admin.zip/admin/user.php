<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="../assets/css/user.css" rel="stylesheet" />
        <link href="../assets/datatables/datatables.css" rel="stylesheet" />
        <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
        <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
        <script src="../assets/js/scripts.js"></script>
        <title>Users - Ordinatio Garden Industry</title>
    </head>
    <?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->
<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">    
                <h1 class="inline"><i class="fas fa-user fa-fw me-1 inline"></i>Users</h1>
                <?php 
                    if (isset($_GET['error'])){
                        echo '<div class="p-error"><span>' . $_GET['error'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';
                    }
                    elseif (isset($_GET['success'])){
                        echo '<div class="p-success"><span>' . $_GET['success'] . '</span>
                            <button class="close-btn mb-1">&times;</button>
                        </div>';

                    }
                ?>
                <div class="table-size-1 mt-4">
                    <table id="users-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <?php if ($_SESSION['position']['create_users'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                    echo '<th>Select</th>';
                                } ?>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Position</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            require "db_connect.php";
                            
                            $query = "SELECT user.user_id as u_id, user.name AS u_name, user.surname AS u_surname, user.email AS u_email, user.phone as u_phone, 
                            user.address as u_address, user.is_admin as u_is_admin, user.hash as u_hash, position.name as p_name, position.position_id as p_id
                            FROM user
                            JOIN position ON position.position_id = user.position_id_users;";
                            $result = mysqli_query($conn, $query);
                    
                            if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)){
                                    $hash = $row['u_hash']; $id = $row['u_id']; $name = $row['u_name']; 
                                    $surname = $row['u_surname']; $email = $row['u_email']; $phone = $row['u_phone']; 
                                    $address = $row['u_address']; $position = $row['p_name']; $is_admin = $row['u_is_admin'];

                                    echo "<tr data-u_hash='$hash' data-u_name='$name' data-u_surname='$surname'
                                            data-u_email='$email' data-u_phone='$phone' data-u_address='$address'
                                            data-u_position='$position' data-u_is_admin='$is_admin'>";
                                    if ($_SESSION['position']['create_users'] === '1' || $_SESSION['is_admin'] ==='1' ){
                                        echo "<td style='text-align: center;width:40px;'><input class='mt-1 form-check-input' name='user_select' id='user_select' type='radio' style='height:20px;width:20px'></td>";
                                    }
                                    echo "<td>" . htmlspecialchars($row['u_id']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['u_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['u_surname']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['u_email']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['u_phone']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['u_address']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['p_name']) . "</td>";
                                    if($is_admin){
                                        echo "<td> <i class='fa-solid fa-user-tie fa-2xl ms-3 d-block '></i><p class='fw-bold text-center' style='margin-bottom:0px;'>Admin</p></td>";

                                    } else {
                                        echo "<td><i class='fa-solid fa-user fa-2xl ms-3 d-block'></i><p class='fw-bold text-center' style='margin-bottom:0px;'>User</p></td>";
                                    }
                                    echo "</tr>";
                                }
                            }
                        ?>
                        </tbody>
                    </table>
                    <?php if ($_SESSION['position']['create_users'] === '1' || $_SESSION['is_admin'] ==='1' ){ ?>
                    <button  id="edit_user_btn" type="button" class="btn btn-primary btns" data-bs-toggle="modal" data-bs-target="#edit_user" disabled>Edit</button>
                    <button type="submit" id="delete_user_btn" class="btn btn-danger btns ms-2" data-bs-toggle="modal" data-bs-target="#delete-user-modal" disabled>Delete</button>
                    <div id="delete-user-modal" class="modal fade" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                    <h4 class="modal-title"><i class="bi bi-trash-fill"></i> Delete User</h4>
                                <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form class="d-inline ms-2" id="register_form" method="POST" action="../src/delete_user.php">
                                <div class="modal-body">
                                <p class="h5">
                                    <input name="hash_del" id="hashID_del" required hidden/>
                                    Are you sure you want to delete this user?
                                </p>
                                <p class="h5">Deleting a user will permanently remove their account and associated data.</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btns" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-danger btns">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="edit_user" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="width:100%">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h4 class="modal-title" id="exampleModalLabel"><i class="bi bi-person-fill"></i> Edit User</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form id="register_form" method="POST" action="update_user.php" novalidate>
                                    <div class="modal-body">
                                        <input name="hash_edit" id="hashID_edit" hidden required/>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="first_name" id="inputFirstName" type="text" placeholder="Enter your first name" required/>
                                                    <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="last_name" id="inputLastName" type="text" placeholder="Enter your last name" required/>
                                                    <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" onblur="validateEmail()" required/>
                                            <label for="inputEmail">Email Address <span class="required-field">*</span></label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="phone" id="inputPhoneNumber" type="tel" placeholder="Phone Number"/>
                                                    <label for="inputPhoneNumber">Phone Number</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address"/>
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <?php
                                                        require_once '../src/db_connect.php';
                                                        $sql = "SELECT name FROM position;";
                                                        $result = mysqli_query($conn, $sql);
                                                        
                                                        if (mysqli_num_rows($result) > 0) {
                                                            echo '<select id="select-position" name="position" autocomplete="off" placeholder="Position">
                                                                    <option disabled selected value></option>';
                                                                
                                                                while($row = mysqli_fetch_assoc($result)){
                                                                    echo '<option value="' . $row['name']  .  '">' . $row['name'] . '</option>';                                                                 
                                                                }
                                                            echo '</select>';
                                                        } 

                                                    ?>
                                                </div>
                                            </div>
                                            <?php 
                                                if ($_SESSION['is_admin']){ 
                                                    echo '<div class="col-md-6">
                                                            <div class="form-check mb-3">
                                                                <input class="form-check-input" name="admin" id="inputIsAdmin" type="checkbox" value="0">
                                                                <label class="form-check-label" for="inputIsAdmin">Administrator account</label>
                                                            </div>
                                                        </div>';
                                                }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </main>
    </div>
<!-- --------------------------------------- End --------------------------------------- -->
        <script src="../assets/datatables/datatables.js"></script>
        <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
        <script src="../assets/js/user.js"></script>
        <script>
            $(document).ready(function () {
            $('#users-table').DataTable();
            });
        </script>
        <script src="../assets/js/validate-users.js"></script>
    </body>
</html>